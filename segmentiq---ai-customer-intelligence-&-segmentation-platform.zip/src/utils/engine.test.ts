import test from 'node:test';
import assert from 'node:assert/strict';
import {
  standardScale,
  runKMeans,
  runHierarchical,
  runDBSCAN,
  runGMM,
  calculateSilhouetteScore,
  calculateDaviesBouldinIndex,
  calculateCalinskiHarabaszScore,
  calculateElbowCurve,
  calculatePCA,
} from './mlAlgorithms.ts';
import {
  computeQuintiles,
  classifyRFMSegment,
  runRFMAnalysis,
} from './rfmAnalysis.ts';
import {
  predictCustomerChurn,
  runChurnAnalysis,
} from './churnPrediction.ts';
import {
  evaluateProductCycleStatus,
} from './seasonalCycleAnalysis.ts';
import {
  parseCSV,
  exportToCSV,
} from './datasets.ts';

test('ML Algorithms: Standard Scaler normalizes to mean ~0 and stdDev ~1', () => {
  const data = [
    [10, 100],
    [20, 200],
    [30, 300],
  ];
  const { scaled, means } = standardScale(data);
  assert.equal(means[0], 20);
  assert.equal(means[1], 200);
  assert.equal(scaled.length, 3);
  assert.ok(Math.abs(scaled[1][0]) < 1e-5); // center value scaled to 0
});

test('ML Algorithms: K-Means partitions well-separated synthetic clusters correctly', () => {
  // Cluster A around (0,0) and Cluster B around (100, 100)
  const data = [
    [1, 2], [2, 1], [0, 1], [1, 1],
    [99, 101], [100, 100], [102, 99], [101, 100],
  ];
  const { assignments, centroids, inertia } = runKMeans(data, 2, 20, 42);
  assert.equal(assignments.length, 8);
  assert.equal(centroids.length, 2);
  assert.ok(inertia >= 0);

  // First 4 points must belong to the same cluster
  assert.equal(assignments[0], assignments[1]);
  assert.equal(assignments[0], assignments[2]);
  assert.equal(assignments[0], assignments[3]);

  // Last 4 points must belong to the other cluster
  assert.equal(assignments[4], assignments[5]);
  assert.equal(assignments[4], assignments[6]);
  assert.notEqual(assignments[0], assignments[4]);
});

test('ML Algorithms: Hierarchical & DBSCAN & GMM produce valid assignments', () => {
  const data = [
    [1, 2], [2, 1], [1, 1],
    [50, 50], [51, 52], [52, 50],
  ];
  const hier = runHierarchical(data, 2);
  assert.equal(hier.assignments.length, 6);
  assert.equal(hier.assignments[0], hier.assignments[1]);
  assert.notEqual(hier.assignments[0], hier.assignments[3]);

  const dbscan = runDBSCAN(data, 5, 2);
  assert.equal(dbscan.assignments.length, 6);

  const gmm = runGMM(data, 2, 10);
  assert.equal(gmm.assignments.length, 6);
});

test('ML Evaluation: Silhouette, Davies-Bouldin, and Calinski-Harabasz compute successfully', () => {
  const data = [
    [1, 1], [2, 1], [1, 2],
    [50, 50], [51, 50], [50, 51],
  ];
  const assignments = [0, 0, 0, 1, 1, 1];
  const sil = calculateSilhouetteScore(data, assignments);
  assert.ok(sil > 0.8, `Expected high silhouette score for separated clusters, got ${sil}`);

  const dbi = calculateDaviesBouldinIndex(data, assignments);
  assert.ok(dbi >= 0, `DBI must be non-negative, got ${dbi}`);

  const ch = calculateCalinskiHarabaszScore(data, assignments);
  assert.ok(ch > 0, `Calinski Harabasz score must be positive, got ${ch}`);

  const pca = calculatePCA(data, 2);
  assert.equal(pca.length, 6);
  assert.equal(pca[0].length, 2);

  const elbow = calculateElbowCurve(data, 3);
  assert.ok(elbow.length >= 2);
});

test('RFM Analysis: Computes quintiles and classifies Champions and At-Risk', () => {
  const quintiles = computeQuintiles([10, 20, 30, 40, 50], false);
  assert.deepEqual(quintiles, [1, 2, 3, 4, 5]);

  const recencyQuintiles = computeQuintiles([10, 20, 30, 40, 50], true);
  assert.deepEqual(recencyQuintiles, [5, 4, 3, 2, 1]); // lowest days gets highest score

  const championClass = classifyRFMSegment(5, 5, 5);
  assert.equal(championClass.segment, 'Champions');

  const atRiskClass = classifyRFMSegment(1, 2, 2);
  assert.equal(atRiskClass.segment, 'At-Risk Customers');
});

test('RFM Analysis: Full pipeline runs on customer records', () => {
  const sampleCustomers = [
    { customerId: 'C1', recencyDays: 5, orderFrequency: 25, totalMonetary: 60000 },
    { customerId: 'C2', recencyDays: 120, orderFrequency: 2, totalMonetary: 3000 },
    { customerId: 'C3', recencyDays: 30, orderFrequency: 8, totalMonetary: 15000 },
    { customerId: 'C4', recencyDays: 15, orderFrequency: 18, totalMonetary: 45000 },
    { customerId: 'C5', recencyDays: 200, orderFrequency: 1, totalMonetary: 1200 },
  ];

  const result = runRFMAnalysis(sampleCustomers);
  assert.equal(result.scoredCustomers.length, 5);
  assert.ok(result.segmentSummaries.length > 0);
  assert.ok(result.overallAvgMonetary > 0);
});

test('Predictive Churn Engine: Accurately classifies high risk vs safe customers', () => {
  const safeCustomer = predictCustomerChurn(10, 15, 50000, 0, 90);
  assert.equal(safeCustomer.riskTier, 'Safe / Healthy');
  assert.ok(safeCustomer.churnProbability < 40);

  const criticalCustomer = predictCustomerChurn(180, 1, 1000, 3, 20);
  assert.equal(criticalCustomer.riskTier, 'Critical Risk');
  assert.ok(criticalCustomer.churnProbability >= 75);
  assert.ok(criticalCustomer.riskDrivers.length > 0);

  const churnResult = runChurnAnalysis([
    { customerId: '1', recencyDays: 10, orderFrequency: 12, totalSpend: 25000 },
    { customerId: '2', recencyDays: 150, orderFrequency: 1, totalSpend: 1500 },
  ]);
  assert.equal(churnResult.profiles.length, 2);
  assert.ok(churnResult.metrics.criticalRiskCount >= 1 || churnResult.metrics.highRiskCount >= 1);
});

test('Seasonal Brand Cycles: Samsung and Consumer Tech product cycle upgrade window', () => {
  const cycleInfo = evaluateProductCycleStatus('Samsung', 22, 60000, 85);
  assert.equal(cycleInfo.lifecycleStatus, 'Upgrade Due Now');
  assert.ok(cycleInfo.upgradeReadinessScore >= 80);
  assert.ok(cycleInfo.dynamicPriceOffer.length > 0);
});

test('CSV Parser and Exporter: Parses structured CSV with quotes and escapes', () => {
  const csv = `CustomerID,Name,Income\nC1,"Doe, John",50000\nC2,Jane,75000`;
  const parsed = parseCSV(csv);
  assert.equal(parsed.length, 2);
  assert.equal(parsed[0].CustomerID, 'C1');
  assert.equal(parsed[0].Name, 'Doe, John');
  assert.equal(parsed[0].Income, 50000);

  const exported = exportToCSV(parsed);
  assert.ok(exported.includes('CustomerID,Name,Income'));
  assert.ok(exported.includes('"Doe, John"'));
});
