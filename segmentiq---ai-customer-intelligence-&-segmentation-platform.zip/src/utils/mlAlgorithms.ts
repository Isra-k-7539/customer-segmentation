/**
 * Machine Learning Clustering & Dimensionality Reduction Algorithms
 * Implemented with pure TypeScript for transparent, reproducible in-browser and server-side computation.
 */

export interface DataPoint {
  id: string | number;
  features: number[];
  metadata?: Record<string, any>;
}

export interface ClusterResult {
  clusterId: number;
  label: string;
  centroid: number[];
  memberCount: number;
  percentage: number;
  memberIndices: number[];
  featureAverages: number[];
}

export interface ClusteringModelOutput {
  algorithm: 'kmeans' | 'hierarchical' | 'dbscan' | 'gmm';
  clusters: ClusterResult[];
  assignments: number[]; // cluster index for each data point
  silhouetteScore: number;
  daviesBouldinIndex: number;
  calinskiHarabaszScore: number;
  inertia?: number;
  pcaCoordinates: { x: number; y: number; z: number; cluster: number; id: string | number }[];
  featureNames: string[];
  normalizedCentroids: number[][];
}

// ----------------------------------------------------------------------
// 1. Feature Preprocessing (Standard Scaler: zero mean, unit variance)
// ----------------------------------------------------------------------
export function standardScale(matrix: number[][]): {
  scaled: number[][];
  means: number[];
  stdDevs: number[];
} {
  const numRows = matrix.length;
  if (numRows === 0) return { scaled: [], means: [], stdDevs: [] };
  const numCols = matrix[0].length;

  const means: number[] = new Array(numCols).fill(0);
  const stdDevs: number[] = new Array(numCols).fill(0);

  // Compute means
  for (let j = 0; j < numCols; j++) {
    let sum = 0;
    for (let i = 0; i < numRows; i++) {
      sum += matrix[i][j];
    }
    means[j] = sum / numRows;
  }

  // Compute std deviations
  for (let j = 0; j < numCols; j++) {
    let sumSq = 0;
    for (let i = 0; i < numRows; i++) {
      const diff = matrix[i][j] - means[j];
      sumSq += diff * diff;
    }
    stdDevs[j] = Math.sqrt(sumSq / numRows) || 1e-6; // prevent div by zero
  }

  // Scale data
  const scaled: number[][] = matrix.map((row) =>
    row.map((val, j) => (val - means[j]) / stdDevs[j])
  );

  return { scaled, means, stdDevs };
}

// Euclidean distance squared
export function distanceSq(a: number[], b: number[]): number {
  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    const diff = a[i] - b[i];
    sum += diff * diff;
  }
  return sum;
}

// Euclidean distance
export function distance(a: number[], b: number[]): number {
  return Math.sqrt(distanceSq(a, b));
}

// ----------------------------------------------------------------------
// 2. K-Means Clustering (with K-Means++ initialization)
// ----------------------------------------------------------------------
export function runKMeans(
  data: number[][],
  k: number,
  maxIterations: number = 100,
  seed: number = 42
): {
  assignments: number[];
  centroids: number[][];
  inertia: number;
} {
  const n = data.length;
  if (n === 0 || k <= 0) return { assignments: [], centroids: [], inertia: 0 };
  const dim = data[0].length;
  const effectiveK = Math.min(k, n);

  // Simple pseudo-random generator for reproducibility
  let rngSeed = seed;
  const pseudoRandom = () => {
    rngSeed = (rngSeed * 9301 + 49297) % 233280;
    return rngSeed / 233280;
  };

  // K-Means++ Initialization
  const centroids: number[][] = [];
  const firstIdx = Math.floor(pseudoRandom() * n);
  centroids.push([...data[firstIdx]]);

  for (let c = 1; c < effectiveK; c++) {
    const dists: number[] = new Array(n);
    let sumDistSq = 0;

    for (let i = 0; i < n; i++) {
      let minDist = Infinity;
      for (let j = 0; j < centroids.length; j++) {
        const d = distanceSq(data[i], centroids[j]);
        if (d < minDist) minDist = d;
      }
      dists[i] = minDist;
      sumDistSq += minDist;
    }

    let target = pseudoRandom() * sumDistSq;
    let selected = 0;
    for (let i = 0; i < n; i++) {
      target -= dists[i];
      if (target <= 0) {
        selected = i;
        break;
      }
    }
    centroids.push([...data[selected]]);
  }

  // Iterations
  let assignments: number[] = new Array(n).fill(0);
  let changed = true;
  let iter = 0;

  while (changed && iter < maxIterations) {
    changed = false;
    iter++;

    // Assign points to nearest centroid
    for (let i = 0; i < n; i++) {
      let minD = Infinity;
      let bestCluster = 0;
      for (let c = 0; c < effectiveK; c++) {
        const d = distanceSq(data[i], centroids[c]);
        if (d < minD) {
          minD = d;
          bestCluster = c;
        }
      }
      if (assignments[i] !== bestCluster) {
        assignments[i] = bestCluster;
        changed = true;
      }
    }

    // Recompute centroids
    const counts = new Array(effectiveK).fill(0);
    const newCentroids: number[][] = Array.from({ length: effectiveK }, () =>
      new Array(dim).fill(0)
    );

    for (let i = 0; i < n; i++) {
      const c = assignments[i];
      counts[c]++;
      for (let d = 0; d < dim; d++) {
        newCentroids[c][d] += data[i][d];
      }
    }

    for (let c = 0; c < effectiveK; c++) {
      if (counts[c] > 0) {
        for (let d = 0; d < dim; d++) {
          centroids[c][d] = newCentroids[c][d] / counts[c];
        }
      }
    }
  }

  // Calculate inertia (within-cluster sum of squares)
  let inertia = 0;
  for (let i = 0; i < n; i++) {
    inertia += distanceSq(data[i], centroids[assignments[i]]);
  }

  return { assignments, centroids, inertia };
}

// ----------------------------------------------------------------------
// 3. Hierarchical / Agglomerative Clustering
// ----------------------------------------------------------------------
export function runHierarchical(
  data: number[][],
  k: number,
  linkage: 'average' | 'complete' | 'single' = 'average'
): { assignments: number[] } {
  const n = data.length;
  if (n <= k) {
    return { assignments: data.map((_, i) => i % k) };
  }

  // Start with each point in its own cluster
  const clusters: number[][] = data.map((_, i) => [i]);

  // Precompute pairwise distances
  const distMatrix: number[][] = Array.from({ length: n }, () => new Array(n).fill(0));
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      const d = distance(data[i], data[j]);
      distMatrix[i][j] = d;
      distMatrix[j][i] = d;
    }
  }

  const getClusterDist = (c1: number[], c2: number[]): number => {
    let result = linkage === 'complete' ? -Infinity : linkage === 'single' ? Infinity : 0;
    let count = 0;

    for (const i of c1) {
      for (const j of c2) {
        const d = distMatrix[i][j];
        if (linkage === 'complete') {
          if (d > result) result = d;
        } else if (linkage === 'single') {
          if (d < result) result = d;
        } else {
          result += d;
          count++;
        }
      }
    }
    return linkage === 'average' ? (count > 0 ? result / count : 0) : result;
  };

  // Merge until k clusters remain
  while (clusters.length > k) {
    let minDist = Infinity;
    let bestI = 0;
    let bestJ = 1;

    for (let i = 0; i < clusters.length; i++) {
      for (let j = i + 1; j < clusters.length; j++) {
        const d = getClusterDist(clusters[i], clusters[j]);
        if (d < minDist) {
          minDist = d;
          bestI = i;
          bestJ = j;
        }
      }
    }

    // Merge bestJ into bestI and remove bestJ
    clusters[bestI] = [...clusters[bestI], ...clusters[bestJ]];
    clusters.splice(bestJ, 1);
  }

  const assignments = new Array(n).fill(0);
  clusters.forEach((clusterIndices, clusterId) => {
    clusterIndices.forEach((idx) => {
      assignments[idx] = clusterId;
    });
  });

  return { assignments };
}

// ----------------------------------------------------------------------
// 4. DBSCAN (Density-Based Spatial Clustering of Applications with Noise)
// ----------------------------------------------------------------------
export function runDBSCAN(
  data: number[][],
  eps: number = 0.8,
  minPts: number = 4
): { assignments: number[]; noiseCount: number } {
  const n = data.length;
  const assignments = new Array(n).fill(-2); // -2: unvisited, -1: noise, >= 0: cluster
  let currentCluster = 0;

  const regionQuery = (pointIdx: number): number[] => {
    const neighbors: number[] = [];
    for (let i = 0; i < n; i++) {
      if (distance(data[pointIdx], data[i]) <= eps) {
        neighbors.push(i);
      }
    }
    return neighbors;
  };

  for (let i = 0; i < n; i++) {
    if (assignments[i] !== -2) continue; // already visited

    const neighbors = regionQuery(i);
    if (neighbors.length < minPts) {
      assignments[i] = -1; // marked as noise
    } else {
      assignments[i] = currentCluster;
      const seedQueue = [...neighbors];

      let qIdx = 0;
      while (qIdx < seedQueue.length) {
        const qPoint = seedQueue[qIdx];
        qIdx++;

        if (assignments[qPoint] === -1) {
          assignments[qPoint] = currentCluster; // noise converted to border
        }

        if (assignments[qPoint] !== -2) continue; // already processed

        assignments[qPoint] = currentCluster;
        const qNeighbors = regionQuery(qPoint);
        if (qNeighbors.length >= minPts) {
          for (const nb of qNeighbors) {
            if (!seedQueue.includes(nb)) {
              seedQueue.push(nb);
            }
          }
        }
      }

      currentCluster++;
    }
  }

  // Remap noise (-1) to either outlier label or separate cluster
  let noiseCount = 0;
  for (let i = 0; i < n; i++) {
    if (assignments[i] === -1) {
      noiseCount++;
    }
  }

  return { assignments, noiseCount };
}

// ----------------------------------------------------------------------
// 5. Gaussian Mixture Model (Simplified Diagonal GMM / Soft Clustering)
// ----------------------------------------------------------------------
export function runGMM(
  data: number[][],
  k: number,
  maxIterations: number = 30
): {
  assignments: number[];
  responsibilities: number[][];
} {
  const n = data.length;
  if (n === 0) return { assignments: [], responsibilities: [] };
  const dim = data[0].length;

  // Initialize with k-means first for stable starting components
  const initKMeans = runKMeans(data, k, 20);
  const assignments = [...initKMeans.assignments];

  // Priors
  const weights = new Array(k).fill(1 / k);
  // Means
  const means: number[][] = Array.from({ length: k }, (_, c) => {
    const pts = data.filter((_, i) => assignments[i] === c);
    if (pts.length === 0) return [...data[Math.floor(Math.random() * n)]];
    const mean = new Array(dim).fill(0);
    for (const p of pts) {
      for (let d = 0; d < dim; d++) mean[d] += p[d];
    }
    return mean.map((v) => v / pts.length);
  });

  // Variances (diagonal covariance)
  const variances: number[][] = Array.from({ length: k }, () =>
    new Array(dim).fill(1.0)
  );

  let responsibilities: number[][] = Array.from({ length: n }, () =>
    new Array(k).fill(1 / k)
  );

  // EM Loop
  for (let iter = 0; iter < maxIterations; iter++) {
    // E-Step: calculate responsibilities
    for (let i = 0; i < n; i++) {
      let sumProb = 0;
      for (let c = 0; c < k; c++) {
        let logProb = 0;
        for (let d = 0; d < dim; d++) {
          const diff = data[i][d] - means[c][d];
          const varD = Math.max(variances[c][d], 1e-4);
          logProb -= (diff * diff) / (2 * varD);
          logProb -= 0.5 * Math.log(2 * Math.PI * varD);
        }
        const prob = Math.exp(Math.max(logProb, -50)) * weights[c];
        responsibilities[i][c] = prob;
        sumProb += prob;
      }

      if (sumProb > 0) {
        for (let c = 0; c < k; c++) {
          responsibilities[i][c] /= sumProb;
        }
      } else {
        responsibilities[i].fill(1 / k);
      }
    }

    // M-Step: update parameters
    for (let c = 0; c < k; c++) {
      let totalResp = 0;
      for (let i = 0; i < n; i++) {
        totalResp += responsibilities[i][c];
      }
      weights[c] = totalResp / n;

      if (totalResp > 1e-6) {
        // Update mean
        for (let d = 0; d < dim; d++) {
          let sumVal = 0;
          for (let i = 0; i < n; i++) {
            sumVal += responsibilities[i][c] * data[i][d];
          }
          means[c][d] = sumVal / totalResp;
        }

        // Update variance
        for (let d = 0; d < dim; d++) {
          let sumSq = 0;
          for (let i = 0; i < n; i++) {
            const diff = data[i][d] - means[c][d];
            sumSq += responsibilities[i][c] * diff * diff;
          }
          variances[c][d] = Math.max(sumSq / totalResp, 1e-4);
        }
      }
    }
  }

  // Hard assignments from argmax responsibilities
  const finalAssignments = responsibilities.map((resps) => {
    let maxR = -1;
    let bestC = 0;
    for (let c = 0; c < k; c++) {
      if (resps[c] > maxR) {
        maxR = resps[c];
        bestC = c;
      }
    }
    return bestC;
  });

  return { assignments: finalAssignments, responsibilities };
}

// ----------------------------------------------------------------------
// 6. Evaluation Metrics: Silhouette, Davies-Bouldin, Calinski-Harabasz
// ----------------------------------------------------------------------
export function calculateSilhouetteScore(
  data: number[][],
  assignments: number[]
): number {
  const n = data.length;
  if (n <= 1) return 0;

  const clusterMap = new Map<number, number[]>();
  assignments.forEach((clusterId, i) => {
    if (!clusterMap.has(clusterId)) clusterMap.set(clusterId, []);
    clusterMap.get(clusterId)!.push(i);
  });

  const uniqueClusters = Array.from(clusterMap.keys()).filter((c) => c >= 0);
  if (uniqueClusters.length <= 1) return 0;

  let totalSilhouette = 0;
  let validPoints = 0;

  for (let i = 0; i < n; i++) {
    const myCluster = assignments[i];
    if (myCluster < 0) continue; // skip noise

    const myClusterMembers = clusterMap.get(myCluster)!;

    // a(i): mean intra-cluster distance
    let a_i = 0;
    if (myClusterMembers.length > 1) {
      let sumDist = 0;
      for (const idx of myClusterMembers) {
        if (idx !== i) {
          sumDist += distance(data[i], data[idx]);
        }
      }
      a_i = sumDist / (myClusterMembers.length - 1);
    }

    // b(i): mean nearest-cluster distance
    let b_i = Infinity;
    for (const otherCluster of uniqueClusters) {
      if (otherCluster === myCluster) continue;
      const otherMembers = clusterMap.get(otherCluster)!;
      if (otherMembers.length === 0) continue;

      let sumDist = 0;
      for (const idx of otherMembers) {
        sumDist += distance(data[i], data[idx]);
      }
      const avgDist = sumDist / otherMembers.length;
      if (avgDist < b_i) {
        b_i = avgDist;
      }
    }

    const s_i =
      Math.max(a_i, b_i) > 0 ? (b_i - a_i) / Math.max(a_i, b_i) : 0;
    totalSilhouette += s_i;
    validPoints++;
  }

  return validPoints > 0 ? Number((totalSilhouette / validPoints).toFixed(4)) : 0;
}

export function calculateDaviesBouldinIndex(
  data: number[][],
  assignments: number[]
): number {
  const clusterMap = new Map<number, number[]>();
  assignments.forEach((clusterId, i) => {
    if (clusterId >= 0) {
      if (!clusterMap.has(clusterId)) clusterMap.set(clusterId, []);
      clusterMap.get(clusterId)!.push(i);
    }
  });

  const clusters = Array.from(clusterMap.keys());
  const k = clusters.length;
  if (k <= 1) return 0;
  const dim = data[0].length;

  // Calculate centroids & intra-cluster dispersion (S_i)
  const centroids: number[][] = [];
  const dispersions: number[] = [];

  for (const c of clusters) {
    const members = clusterMap.get(c)!;
    const centroid = new Array(dim).fill(0);
    for (const idx of members) {
      for (let d = 0; d < dim; d++) {
        centroid[d] += data[idx][d];
      }
    }
    for (let d = 0; d < dim; d++) {
      centroid[d] /= members.length;
    }
    centroids.push(centroid);

    let sumDist = 0;
    for (const idx of members) {
      sumDist += distance(data[idx], centroid);
    }
    dispersions.push(sumDist / members.length);
  }

  // Calculate DB index
  let dbSum = 0;
  for (let i = 0; i < k; i++) {
    let maxR = -Infinity;
    for (let j = 0; j < k; j++) {
      if (i === j) continue;
      const d_ij = distance(centroids[i], centroids[j]);
      if (d_ij > 0) {
        const R_ij = (dispersions[i] + dispersions[j]) / d_ij;
        if (R_ij > maxR) maxR = R_ij;
      }
    }
    dbSum += maxR > 0 ? maxR : 0;
  }

  return Number((dbSum / k).toFixed(4));
}

export function calculateCalinskiHarabaszScore(
  data: number[][],
  assignments: number[]
): number {
  const n = data.length;
  const clusterMap = new Map<number, number[]>();
  assignments.forEach((c, i) => {
    if (c >= 0) {
      if (!clusterMap.has(c)) clusterMap.set(c, []);
      clusterMap.get(c)!.push(i);
    }
  });

  const k = clusterMap.size;
  if (k <= 1 || n <= k) return 0;
  const dim = data[0].length;

  // Overall dataset centroid
  const overallCentroid = new Array(dim).fill(0);
  for (let i = 0; i < n; i++) {
    for (let d = 0; d < dim; d++) {
      overallCentroid[d] += data[i][d];
    }
  }
  for (let d = 0; d < dim; d++) {
    overallCentroid[d] /= n;
  }

  // Between-cluster dispersion (SSB) and Within-cluster dispersion (SSW)
  let ssb = 0;
  let ssw = 0;

  for (const [, members] of clusterMap.entries()) {
    const clusterCentroid = new Array(dim).fill(0);
    for (const idx of members) {
      for (let d = 0; d < dim; d++) {
        clusterCentroid[d] += data[idx][d];
      }
    }
    for (let d = 0; d < dim; d++) {
      clusterCentroid[d] /= members.length;
    }

    // Add to SSB
    ssb += members.length * distanceSq(clusterCentroid, overallCentroid);

    // Add to SSW
    for (const idx of members) {
      ssw += distanceSq(data[idx], clusterCentroid);
    }
  }

  if (ssw === 0) return 0;
  const score = (ssb / (k - 1)) / (ssw / (n - k));
  return Number(score.toFixed(2));
}

// ----------------------------------------------------------------------
// 7. Dimensionality Reduction: PCA 2D/3D Projection
// ----------------------------------------------------------------------
export function calculatePCA(
  data: number[][],
  components: number = 3
): number[][] {
  const n = data.length;
  if (n === 0) return [];
  const dim = data[0].length;

  // Center data
  const means = new Array(dim).fill(0);
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < dim; j++) {
      means[j] += data[i][j];
    }
  }
  for (let j = 0; j < dim; j++) {
    means[j] /= n;
  }

  const centered: number[][] = data.map((row) =>
    row.map((val, j) => val - means[j])
  );

  // Compute covariance matrix
  const cov: number[][] = Array.from({ length: dim }, () => new Array(dim).fill(0));
  for (let i = 0; i < dim; i++) {
    for (let j = 0; j < dim; j++) {
      let sum = 0;
      for (let k = 0; k < n; k++) {
        sum += centered[k][i] * centered[k][j];
      }
      cov[i][j] = sum / (n - 1 || 1);
    }
  }

  // Power iteration for dominant eigenvectors
  const eigenvectors: number[][] = [];
  const covCopy = cov.map((row) => [...row]);

  for (let comp = 0; comp < Math.min(components, dim); comp++) {
    let vec: number[] = new Array(dim).fill(0).map((_, i) => (i === comp ? 1 : 0.1));
    // Normalize
    let norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0)) || 1;
    vec = vec.map((v) => v / norm);

    for (let iter = 0; iter < 40; iter++) {
      const nextVec = new Array(dim).fill(0);
      for (let i = 0; i < dim; i++) {
        for (let j = 0; j < dim; j++) {
          nextVec[i] += covCopy[i][j] * vec[j];
        }
      }
      norm = Math.sqrt(nextVec.reduce((s, v) => s + v * v, 0)) || 1e-6;
      vec = nextVec.map((v) => v / norm);
    }

    eigenvectors.push(vec);

    // Deflate covariance matrix
    const eigenvalue = vec.reduce(
      (sum, vi, i) =>
        sum +
        vi *
          vec.reduce((s, vj, j) => s + covCopy[i][j] * vj, 0),
      0
    );

    for (let i = 0; i < dim; i++) {
      for (let j = 0; j < dim; j++) {
        covCopy[i][j] -= eigenvalue * vec[i] * vec[j];
      }
    }
  }

  // Project points
  const projected: number[][] = centered.map((point) => {
    return eigenvectors.map((ev) => {
      let dot = 0;
      for (let d = 0; d < dim; d++) {
        dot += point[d] * ev[d];
      }
      return Number(dot.toFixed(4));
    });
  });

  return projected;
}

// ----------------------------------------------------------------------
// 8. Elbow Method Evaluation (k = 2 to maxK)
// ----------------------------------------------------------------------
export function calculateElbowCurve(
  data: number[][],
  maxK: number = 8
): { k: number; inertia: number; silhouette: number }[] {
  const { scaled } = standardScale(data);
  const results: { k: number; inertia: number; silhouette: number }[] = [];

  for (let k = 2; k <= Math.min(maxK, data.length - 1); k++) {
    const kmeans = runKMeans(scaled, k, 60);
    const sil = calculateSilhouetteScore(scaled, kmeans.assignments);
    results.push({
      k,
      inertia: Math.round(kmeans.inertia * 10) / 10,
      silhouette: sil,
    });
  }

  return results;
}
