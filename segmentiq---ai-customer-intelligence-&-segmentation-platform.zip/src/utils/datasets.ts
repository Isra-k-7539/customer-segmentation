/**
 * SegmentIQ Curated Benchmark & E-Commerce Datasets and Data Management Utilities
 */

export interface DatasetColumn {
  name: string;
  type: 'numeric' | 'categorical' | 'date' | 'id';
  uniqueValues: number;
  nullCount: number;
  min?: number;
  max?: number;
  mean?: number;
}

export interface DatasetMetadata {
  id: string;
  name: string;
  description: string;
  rowCount: number;
  columnCount: number;
  columns: DatasetColumn[];
  missingValueCount: number;
  duplicateCount: number;
  isDemo: boolean;
  uploadedAt: string;
  data: Record<string, any>[];
  suggestedClusteringFeatures: string[];
}

// Generate the 200 Mall Customers Benchmark Dataset
export function generateMallCustomersData(): Record<string, any>[] {
  // Mall dataset benchmark characteristics:
  // 5 natural clusters:
  // 1: Low Income, Low Spending (Sensible/Budget)
  // 2: Low Income, High Spending (Careless/Trendsetters)
  // 3: Medium Income, Medium Spending (Standard/Balanced)
  // 4: High Income, Low Spending (Target/Careful High-Earners)
  // 5: High Income, High Spending (Champions/VIP Spenders)
  const rows: Record<string, any>[] = [];

  const clustersConfig = [
    { count: 35, incMin: 15, incMax: 38, spMin: 5, spMax: 39, ageMin: 22, ageMax: 65 },
    { count: 22, incMin: 15, incMax: 39, spMin: 60, spMax: 99, ageMin: 18, ageMax: 35 },
    { count: 68, incMin: 40, incMax: 76, spMin: 40, spMax: 60, ageMin: 20, ageMax: 55 },
    { count: 35, incMin: 72, incMax: 137, spMin: 5, spMax: 40, ageMin: 32, ageMax: 59 },
    { count: 40, incMin: 75, incMax: 137, spMin: 70, spMax: 98, ageMin: 24, ageMax: 48 },
  ];

  let idCounter = 1;
  clustersConfig.forEach((cfg, cIdx) => {
    for (let i = 0; i < cfg.count; i++) {
      const gender = (idCounter + cIdx) % 2 === 0 ? 'Female' : 'Male';
      const age = Math.floor(cfg.ageMin + Math.random() * (cfg.ageMax - cfg.ageMin));
      const income = Math.floor(cfg.incMin + Math.random() * (cfg.incMax - cfg.incMin));
      const spending = Math.floor(cfg.spMin + Math.random() * (cfg.spMax - cfg.spMin));

      rows.push({
        CustomerID: `CUST-${1000 + idCounter}`,
        Gender: gender,
        Age: age,
        'Annual Income (k$)': income,
        'Spending Score (1-100)': spending,
      });
      idCounter++;
    }
  });

  return rows;
}

// Generate rich E-Commerce & Brand Affinity Dataset with Transactions & Churn Risk
export function generateEcommerceDataset(): Record<string, any>[] {
  const brands = ['Samsung', 'Apple', 'Sony', 'Dell', 'Google', 'OnePlus'];
  const categories = ['Smartphones', 'Audio & Wearables', 'Laptops & Computing', 'Smart Home & TV'];
  const firstNames = ['Aarav', 'Diya', 'Rohan', 'Ananya', 'Vikram', 'Priya', 'Kabir', 'Sneha', 'Arjun', 'Meera', 'Aditya', 'Pooja', 'Rahul', 'Neha', 'Siddharth', 'Tanvi', 'Karan', 'Riya', 'Nikhil', 'Isha'];
  const lastNames = ['Sharma', 'Patel', 'Verma', 'Kapoor', 'Iyer', 'Reddy', 'Singh', 'Gupta', 'Mehta', 'Nair', 'Chopra', 'Joshi', 'Bhat', 'Deshmukh', 'Das'];

  const rows: Record<string, any>[] = [];

  // 150 detailed customer profiles with behavioral data
  for (let i = 1; i <= 150; i++) {
    const fn = firstNames[i % firstNames.length];
    const ln = lastNames[(i * 3) % lastNames.length];
    const name = `${fn} ${ln}`;
    const email = `${fn.toLowerCase()}.${ln.toLowerCase()}${i}@example.com`;
    const gender = i % 2 === 0 ? 'Female' : 'Male';
    const age = 20 + ((i * 7) % 52);
    const brand = brands[i % brands.length];
    const category = categories[(i * 2) % categories.length];

    // Create realistic correlated behaviors:
    // Some are VIP champions (high spend, high frequency, recent order)
    // Some are At-Risk (high recency > 70 days, high previous spend)
    // Some are Budget shoppers (low spend, low frequency)
    let recencyDays = 5 + ((i * 13) % 180);
    let orderFrequency = 1 + ((i * 5) % 35);
    let annualIncome = 25000 + ((i * 4500) % 160000);
    let avgOrderValue = 1200 + ((i * 850) % 18000);
    let totalSpend = orderFrequency * avgOrderValue;
    let deviceAgeMonths = 3 + ((i * 4) % 36);
    let supportTickets = (i % 7 === 0) ? 3 : (i % 5 === 0) ? 1 : 0;
    let engagementScore = Math.max(15, Math.min(98, 100 - Math.round(recencyDays * 0.4) + orderFrequency * 2));

    rows.push({
      CustomerID: `USR-${2000 + i}`,
      CustomerName: name,
      Email: email,
      Gender: gender,
      Age: age,
      AnnualIncome: annualIncome,
      TotalSpend: totalSpend,
      OrderFrequency: orderFrequency,
      RecencyDays: recencyDays,
      AverageOrderValue: Math.round(avgOrderValue),
      FavoriteCategory: category,
      BrandAffinity: brand,
      DeviceAgeMonths: deviceAgeMonths,
      SupportTickets: supportTickets,
      EngagementScore: engagementScore,
    });
  }

  return rows;
}

export function inspectDataset(name: string, data: Record<string, any>[], isDemo: boolean = false): DatasetMetadata {
  if (!data || data.length === 0) {
    return {
      id: `ds-${Date.now()}`,
      name,
      description: 'Empty dataset',
      rowCount: 0,
      columnCount: 0,
      columns: [],
      missingValueCount: 0,
      duplicateCount: 0,
      isDemo,
      uploadedAt: new Date().toISOString(),
      data: [],
      suggestedClusteringFeatures: [],
    };
  }

  const keys = Object.keys(data[0]);
  let missingValueCount = 0;

  // Check duplicates by comparing stringified rows
  const seenRows = new Set<string>();
  let duplicateCount = 0;

  data.forEach((row) => {
    const str = JSON.stringify(row);
    if (seenRows.has(str)) {
      duplicateCount++;
    } else {
      seenRows.add(str);
    }

    keys.forEach((k) => {
      if (row[k] === null || row[k] === undefined || row[k] === '') {
        missingValueCount++;
      }
    });
  });

  const columns: DatasetColumn[] = keys.map((colName) => {
    let numCount = 0;
    let nullCount = 0;
    const uniqueVals = new Set<any>();
    let sum = 0;
    let min = Infinity;
    let max = -Infinity;

    data.forEach((row) => {
      const val = row[colName];
      if (val === null || val === undefined || val === '') {
        nullCount++;
      } else {
        uniqueVals.add(val);
        const parsed = Number(val);
        if (!isNaN(parsed) && typeof val !== 'boolean') {
          numCount++;
          sum += parsed;
          if (parsed < min) min = parsed;
          if (parsed > max) max = parsed;
        }
      }
    });

    const isNumeric = numCount > data.length * 0.7;
    const isId = colName.toLowerCase().includes('id') || colName.toLowerCase().includes('email');

    return {
      name: colName,
      type: isId ? 'id' : isNumeric ? 'numeric' : 'categorical',
      uniqueValues: uniqueVals.size,
      nullCount,
      min: isNumeric && min !== Infinity ? min : undefined,
      max: isNumeric && max !== -Infinity ? max : undefined,
      mean: isNumeric && numCount > 0 ? Number((sum / numCount).toFixed(2)) : undefined,
    };
  });

  const suggestedClusteringFeatures = columns
    .filter((c) => c.type === 'numeric' && !c.name.toLowerCase().includes('id'))
    .map((c) => c.name);

  return {
    id: `ds-${Date.now()}`,
    name,
    description: isDemo
      ? 'Curated benchmark dataset for customer segmentation and behavior modeling'
      : 'User uploaded dataset',
    rowCount: data.length,
    columnCount: keys.length,
    columns,
    missingValueCount,
    duplicateCount,
    isDemo,
    uploadedAt: new Date().toISOString(),
    data,
    suggestedClusteringFeatures,
  };
}

/**
 * Parse CSV text into array of objects
 */
export function parseCSV(csvText: string): Record<string, any>[] {
  const lines = csvText.trim().split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length < 2) return [];

  const headers = parseCSVLine(lines[0]);
  const rows: Record<string, any>[] = [];

  for (let i = 1; i < lines.length; i++) {
    const values = parseCSVLine(lines[i]);
    if (values.length === headers.length) {
      const row: Record<string, any> = {};
      headers.forEach((h, idx) => {
        const val = values[idx];
        const num = Number(val);
        row[h] = !isNaN(num) && val.trim() !== '' ? num : val;
      });
      rows.push(row);
    }
  }

  return rows;
}

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  return result;
}

/**
 * Convert data array to CSV string for downloading
 */
export function exportToCSV(data: Record<string, any>[]): string {
  if (data.length === 0) return '';
  const headers = Object.keys(data[0]);
  const rows = [headers.join(',')];

  data.forEach((row) => {
    const values = headers.map((h) => {
      const val = row[h];
      if (typeof val === 'string' && (val.includes(',') || val.includes('"') || val.includes('\n'))) {
        return `"${val.replace(/"/g, '""')}"`;
      }
      return val ?? '';
    });
    rows.push(values.join(','));
  });

  return rows.join('\n');
}
