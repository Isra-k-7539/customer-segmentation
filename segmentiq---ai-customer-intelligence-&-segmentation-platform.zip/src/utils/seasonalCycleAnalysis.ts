/**
 * Seasonal Trend & Brand Product Cycle Intelligence Engine
 * Specializes in consumer electronics / brand refresh cycles (e.g., Samsung Galaxy S-Series Q1,
 * Z-Series Fold/Flip Q3, Festive/Holiday Q4 sales) with dynamic pricing elasticity and upgrade window targeting.
 */

export interface BrandProductCycle {
  brand: string;
  series: string;
  typicalCadenceMonths: number;
  launchQuarter: 'Q1' | 'Q2' | 'Q3' | 'Q4';
  description: string;
  optimalUpgradeWindowMonths: [number, number]; // e.g. [18, 24]
  currentCyclePhase: 'Pre-Launch Teaser' | 'Launch & Flagship Full Price' | 'Mid-Cycle Promotion' | 'End-of-Cycle Clearance';
  recommendedPriceAdjustment: string;
}

export const BRAND_PRODUCT_CYCLES: Record<string, BrandProductCycle[]> = {
  Samsung: [
    {
      brand: 'Samsung',
      series: 'Galaxy S-Series Flagship',
      typicalCadenceMonths: 12,
      launchQuarter: 'Q1',
      description: 'Annual Spring Flagship release (S24, S25). Premium adopters eager for camera/AI upgrades.',
      optimalUpgradeWindowMonths: [18, 24],
      currentCyclePhase: 'Mid-Cycle Promotion',
      recommendedPriceAdjustment: 'Trade-in bonus + 12% subsidized upgrade bundle for 2+ year old device holders',
    },
    {
      brand: 'Samsung',
      series: 'Galaxy Z-Fold / Z-Flip Series',
      typicalCadenceMonths: 12,
      launchQuarter: 'Q3',
      description: 'Late Summer foldable innovation release. High-income tech enthusiasts and status buyers.',
      optimalUpgradeWindowMonths: [14, 20],
      currentCyclePhase: 'Launch & Flagship Full Price',
      recommendedPriceAdjustment: 'Zero-cost EMI & free memory upgrade tier incentives',
    },
    {
      brand: 'Samsung',
      series: 'Galaxy A-Series & Ecosystem (Watches/Buds)',
      typicalCadenceMonths: 12,
      launchQuarter: 'Q2',
      description: 'Mass-market value tier & wearable ecosystem cross-sell.',
      optimalUpgradeWindowMonths: [20, 30],
      currentCyclePhase: 'End-of-Cycle Clearance',
      recommendedPriceAdjustment: 'Dynamic discount ladder (-18% to -25%) bundled with wearable companion device',
    },
  ],
  Apple: [
    {
      brand: 'Apple',
      series: 'iPhone Pro & Standard',
      typicalCadenceMonths: 12,
      launchQuarter: 'Q3',
      description: 'Annual September flagship release. High brand loyalty, predictable trade-in curve.',
      optimalUpgradeWindowMonths: [24, 36],
      currentCyclePhase: 'Mid-Cycle Promotion',
      recommendedPriceAdjustment: 'AppleCare+ bundle subsidy & trade-in value guarantee',
    },
  ],
  GeneralElectronics: [
    {
      brand: 'Consumer Tech',
      series: 'Smart Home & Audio Gear',
      typicalCadenceMonths: 18,
      launchQuarter: 'Q4',
      description: 'Holiday gifting season and Black Friday / Diwali peak demand.',
      optimalUpgradeWindowMonths: [12, 24],
      currentCyclePhase: 'Pre-Launch Teaser',
      recommendedPriceAdjustment: 'Tiered volume pricing (Buy 2 save 20%)',
    },
  ],
};

export interface CustomerDeviceLifecycleProfile {
  customerId: string | number;
  customerName?: string;
  brandAffinity: string;
  currentDeviceAgeMonths: number;
  lifecycleStatus: 'Upgrade Due Now' | 'Approaching Window (3-6m)' | 'Recently Upgraded' | 'Extended Retention';
  upgradeReadinessScore: number; // 0-100
  dynamicPriceOffer: string;
  campaignTrigger: string;
}

/**
 * Analyzes a customer's product cycle timeline and determines dynamic pricing adjustments
 */
export function evaluateProductCycleStatus(
  brandAffinity: string = 'Samsung',
  deviceAgeMonths: number = 20,
  historicalSpend: number = 45000,
  spendingScore: number = 75
): {
  lifecycleStatus: 'Upgrade Due Now' | 'Approaching Window (3-6m)' | 'Recently Upgraded' | 'Extended Retention';
  upgradeReadinessScore: number;
  dynamicPriceOffer: string;
  campaignTrigger: string;
} {
  let readiness = 50;

  // Evaluate against standard 18-24 month upgrade window
  if (deviceAgeMonths >= 18 && deviceAgeMonths <= 28) {
    readiness = 88;
    if (spendingScore > 65) readiness += 8;
    return {
      lifecycleStatus: 'Upgrade Due Now',
      upgradeReadinessScore: Math.min(99, readiness),
      dynamicPriceOffer: 'Exclusive ₹8,000 Guaranteed Trade-In Bump + Early Bird VIP Pre-Order pass',
      campaignTrigger: `Trigger Automated Flagship Upgrade Campaign (Device age: ${deviceAgeMonths}m aligns with new product cycle)`,
    };
  } else if (deviceAgeMonths >= 12 && deviceAgeMonths < 18) {
    readiness = 65;
    return {
      lifecycleStatus: 'Approaching Window (3-6m)',
      upgradeReadinessScore: readiness,
      dynamicPriceOffer: 'Register for Next-Gen VIP Preview + 10% Accessory Credit Voucher',
      campaignTrigger: 'Ecosystem cross-sell sequence (Cases, Smartwatches, wireless charging pads)',
    };
  } else if (deviceAgeMonths < 12) {
    readiness = 20;
    return {
      lifecycleStatus: 'Recently Upgraded',
      upgradeReadinessScore: readiness,
      dynamicPriceOffer: 'Complementary Care protection plan renewal or subscription bundle',
      campaignTrigger: 'Customer satisfaction follow-up & ecosystem accessory recommendations',
    };
  } else {
    // 28+ months
    readiness = 80;
    return {
      lifecycleStatus: 'Extended Retention',
      upgradeReadinessScore: readiness,
      dynamicPriceOffer: 'Aggressive Upgrade Buyback (-25% discount on current season model with zero-down financing)',
      campaignTrigger: 'Lapsed user flagship migration campaign with high urgency pricing',
    };
  }
}
