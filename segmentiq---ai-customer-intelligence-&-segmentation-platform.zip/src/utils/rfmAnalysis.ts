/**
 * RFM (Recency, Frequency, Monetary) Customer Segmentation Engine
 * Computes quantile boundaries, scores (1-5), and business segment labels.
 */

export interface CustomerRFMInput {
  customerId: string | number;
  customerName?: string;
  recencyDays: number;
  orderFrequency: number;
  totalMonetary: number;
  lastOrderDate?: string;
  favoriteCategory?: string;
  churnRiskScore?: number;
}

export interface CustomerRFMOutput extends CustomerRFMInput {
  rScore: number;
  fScore: number;
  mScore: number;
  rfmScore: string; // e.g. "555"
  segment: RFMSegmentType;
  suggestedAction: string;
}

export type RFMSegmentType =
  | 'Champions'
  | 'Loyal Customers'
  | 'Potential Loyalists'
  | 'Recent Customers'
  | 'Promising'
  | 'Customers Needing Attention'
  | 'About to Sleep'
  | 'At-Risk Customers'
  | "Can't Lose Them"
  | 'Hibernating'
  | 'Lost Customers';

export interface RFMSegmentSummary {
  segment: RFMSegmentType;
  customerCount: number;
  percentage: number;
  avgRecencyDays: number;
  avgFrequency: number;
  avgMonetary: number;
  totalRevenue: number;
  color: string;
  recommendedStrategy: string;
}

/**
 * Calculates quintiles (1-5 scores) for given numerical values.
 * For Recency: lower days = higher score (5 is best/most recent).
 * For Frequency and Monetary: higher value = higher score (5 is best).
 */
export function computeQuintiles(values: number[], reverse: boolean = false): number[] {
  const n = values.length;
  if (n === 0) return [];

  // Pair with original index to sort and rank
  const indexed = values.map((val, idx) => ({ val, idx }));
  indexed.sort((a, b) => a.val - b.val);

  const scores = new Array(n).fill(1);

  for (let rank = 0; rank < n; rank++) {
    const origIdx = indexed[rank].idx;
    // Quintile bucket: 1, 2, 3, 4, 5
    let score = Math.floor((rank / n) * 5) + 1;
    if (score > 5) score = 5;

    // Invert score if reverse is true (Recency: lower days is better)
    if (reverse) {
      score = 6 - score;
    }
    scores[origIdx] = score;
  }

  return scores;
}

/**
 * Classifies an RFM score into standard marketing intelligence segments.
 */
export function classifyRFMSegment(r: number, f: number, m: number): {
  segment: RFMSegmentType;
  suggestedAction: string;
} {
  const fmAvg = (f + m) / 2;

  if (r >= 4 && fmAvg >= 4) {
    return {
      segment: 'Champions',
      suggestedAction: 'Reward with VIP loyalty tiers, concierge support, and early access to new product launches.',
    };
  } else if (r >= 3 && fmAvg >= 3.5) {
    return {
      segment: 'Loyal Customers',
      suggestedAction: 'Upsell higher-value products, offer subscription memberships, and request testimonials.',
    };
  } else if (r >= 4 && fmAvg >= 2) {
    return {
      segment: 'Potential Loyalists',
      suggestedAction: 'Offer bundle discounts and personalized cross-sell recommendations to increase order frequency.',
    };
  } else if (r >= 4 && fmAvg < 2) {
    return {
      segment: 'Recent Customers',
      suggestedAction: 'Engage with onboarding educational email series and welcome back incentives.',
    };
  } else if (r === 3 && fmAvg >= 3) {
    return {
      segment: 'Promising',
      suggestedAction: 'Deliver targeted coupon codes and highlight seasonal promotions.',
    };
  } else if (r === 3 && fmAvg < 3) {
    return {
      segment: 'Customers Needing Attention',
      suggestedAction: 'Send limited-time flash discount offers and reactive personalized surveys.',
    };
  } else if (r === 2 && fmAvg < 3) {
    return {
      segment: 'About to Sleep',
      suggestedAction: 'Re-engage with win-back campaigns and share trending catalog highlights.',
    };
  } else if (r <= 2 && fmAvg >= 3.5) {
    return {
      segment: "Can't Lose Them",
      suggestedAction: 'Urgent retention intervention: dedicated personal outreach, phone call, or high-value revival voucher.',
    };
  } else if (r <= 2 && fmAvg >= 2) {
    return {
      segment: 'At-Risk Customers',
      suggestedAction: 'Deploy multi-channel reactivation sequence (SMS + email) with strong 20% discount hooks.',
    };
  } else if (r === 1 && fmAvg >= 1.5) {
    return {
      segment: 'Hibernating',
      suggestedAction: 'Offer relevant product alternatives and steep clearance savings.',
    };
  } else {
    return {
      segment: 'Lost Customers',
      suggestedAction: 'Low-frequency drip campaigns or brand awareness remarketing; avoid costly ad spend.',
    };
  }
}

export const SEGMENT_COLORS: Record<RFMSegmentType, string> = {
  Champions: '#6366F1', // Indigo
  'Loyal Customers': '#06B6D4', // Cyan
  'Potential Loyalists': '#3B82F6', // Blue
  'Recent Customers': '#10B981', // Emerald
  Promising: '#8B5CF6', // Purple
  'Customers Needing Attention': '#F59E0B', // Amber
  'About to Sleep': '#FB923C', // Orange
  'At-Risk Customers': '#EF4444', // Red
  "Can't Lose Them": '#DC2626', // Deep Red
  Hibernating: '#64748B', // Slate
  'Lost Customers': '#475569', // Dark Slate
};

/**
 * Runs full RFM Pipeline on a customer list
 */
export function runRFMAnalysis(customers: CustomerRFMInput[]): {
  scoredCustomers: CustomerRFMOutput[];
  segmentSummaries: RFMSegmentSummary[];
  overallAvgRecency: number;
  overallAvgFrequency: number;
  overallAvgMonetary: number;
} {
  const n = customers.length;
  if (n === 0) {
    return {
      scoredCustomers: [],
      segmentSummaries: [],
      overallAvgRecency: 0,
      overallAvgFrequency: 0,
      overallAvgMonetary: 0,
    };
  }

  const recencies = customers.map((c) => c.recencyDays);
  const frequencies = customers.map((c) => c.orderFrequency);
  const monetaries = customers.map((c) => c.totalMonetary);

  const rScores = computeQuintiles(recencies, true); // lower recency = higher score
  const fScores = computeQuintiles(frequencies, false);
  const mScores = computeQuintiles(monetaries, false);

  const scoredCustomers: CustomerRFMOutput[] = customers.map((c, i) => {
    const r = rScores[i];
    const f = fScores[i];
    const m = mScores[i];
    const { segment, suggestedAction } = classifyRFMSegment(r, f, m);

    return {
      ...c,
      rScore: r,
      fScore: f,
      mScore: m,
      rfmScore: `${r}${f}${m}`,
      segment,
      suggestedAction,
    };
  });

  // Aggregate by segment
  const segmentMap = new Map<RFMSegmentType, CustomerRFMOutput[]>();
  for (const c of scoredCustomers) {
    if (!segmentMap.has(c.segment)) segmentMap.set(c.segment, []);
    segmentMap.get(c.segment)!.push(c);
  }

  const segmentSummaries: RFMSegmentSummary[] = Array.from(segmentMap.entries()).map(
    ([segment, members]) => {
      const count = members.length;
      const sumR = members.reduce((s, m) => s + m.recencyDays, 0);
      const sumF = members.reduce((s, m) => s + m.orderFrequency, 0);
      const sumM = members.reduce((s, m) => s + m.totalMonetary, 0);

      const sampleAction = members[0]?.suggestedAction || '';

      return {
        segment,
        customerCount: count,
        percentage: Number(((count / n) * 100).toFixed(1)),
        avgRecencyDays: Math.round(sumR / count),
        avgFrequency: Number((sumF / count).toFixed(1)),
        avgMonetary: Math.round(sumM / count),
        totalRevenue: Math.round(sumM),
        color: SEGMENT_COLORS[segment] || '#6366F1',
        recommendedStrategy: sampleAction,
      };
    }
  );

  // Sort summaries by revenue contribution descending
  segmentSummaries.sort((a, b) => b.totalRevenue - a.totalRevenue);

  const overallAvgRecency = Math.round(
    recencies.reduce((s, v) => s + v, 0) / n
  );
  const overallAvgFrequency = Number(
    (frequencies.reduce((s, v) => s + v, 0) / n).toFixed(1)
  );
  const overallAvgMonetary = Math.round(
    monetaries.reduce((s, v) => s + v, 0) / n
  );

  return {
    scoredCustomers,
    segmentSummaries,
    overallAvgRecency,
    overallAvgFrequency,
    overallAvgMonetary,
  };
}
