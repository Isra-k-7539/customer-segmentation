import type { DatasetMetadata } from '../utils/datasets.ts';
import type { ClusterResult } from '../utils/mlAlgorithms.ts';
import type { CustomerRFMOutput, RFMSegmentSummary } from '../utils/rfmAnalysis.ts';
import type { CustomerChurnProfile, ChurnAggregateMetrics } from '../utils/churnPrediction.ts';
import type { BrandProductCycle } from '../utils/seasonalCycleAnalysis.ts';

export type ActiveTab =
  | 'landing'
  | 'dashboard'
  | 'data-management'
  | 'segmentation'
  | 'personas'
  | 'rfm'
  | 'churn'
  | 'seasonal-trends'
  | 'campaigns'
  | 'what-if'
  | 'ai-intelligence'
  | 'reports';

export interface AppState {
  activeTab: ActiveTab;
  currentDatasetId: string;
  datasets: { id: string; name: string; rowCount: number; isDemo: boolean }[];
  currentDataset: DatasetMetadata | null;
  currency: 'INR' | 'USD';
  // Clustering state
  algorithm: 'kmeans' | 'hierarchical' | 'dbscan' | 'gmm';
  selectedFeatures: string[];
  kClusters: number;
  clusters: ClusterResult[];
  pcaCoordinates: any[];
  silhouetteScore: number;
  daviesBouldinIndex: number;
  calinskiHarabaszScore: number;
  inertia?: number;
  elbowCurve: { k: number; inertia: number; silhouette: number }[];
  // RFM state
  rfmCustomers: CustomerRFMOutput[];
  rfmSummaries: RFMSegmentSummary[];
  // Churn state
  churnProfiles: CustomerChurnProfile[];
  churnMetrics: ChurnAggregateMetrics | null;
  // Product cycles
  productCycles: Record<string, BrandProductCycle[]>;
  // Auth state
  user: { name: string; email: string; role: string } | null;
  isLoggedIn: boolean;
  // UI state
  isLoading: boolean;
  notification: string | null;
}
