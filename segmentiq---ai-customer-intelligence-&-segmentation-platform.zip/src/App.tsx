import React, { useState, useEffect, useCallback } from 'react';
import type { AppState, ActiveTab } from './types/index.ts';
import { Header } from './components/Header.tsx';
import { Sidebar } from './components/Sidebar.tsx';
import { LandingPage } from './components/LandingPage.tsx';
import { DashboardOverview } from './components/DashboardOverview.tsx';
import { DataManagementView } from './components/DataManagementView.tsx';
import { SegmentationEngineView } from './components/SegmentationEngineView.tsx';
import { CustomerPersonasView } from './components/CustomerPersonasView.tsx';
import { RFMAnalysisView } from './components/RFMAnalysisView.tsx';
import { ChurnRetentionView } from './components/ChurnRetentionView.tsx';
import { SeasonalTrendsView } from './components/SeasonalTrendsView.tsx';
import { CampaignAutomationView } from './components/CampaignAutomationView.tsx';
import { WhatIfSimulatorView } from './components/WhatIfSimulatorView.tsx';
import { AIIntelligenceView } from './components/AIIntelligenceView.tsx';
import { ReportsExportView } from './components/ReportsExportView.tsx';
import {
  generateMallCustomersData,
  generateEcommerceDataset,
  inspectDataset,
} from './utils/datasets.ts';
import {
  runKMeans,
  standardScale,
  calculateSilhouetteScore,
  calculateDaviesBouldinIndex,
  calculateCalinskiHarabaszScore,
  calculatePCA,
  calculateElbowCurve,
} from './utils/mlAlgorithms.ts';
import { runRFMAnalysis } from './utils/rfmAnalysis.ts';
import { runChurnAnalysis } from './utils/churnPrediction.ts';
import { BRAND_PRODUCT_CYCLES } from './utils/seasonalCycleAnalysis.ts';

export default function App() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // Check URL params for ?autostart=1
  const queryParams = typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : null;
  const autostart = queryParams?.get('autostart') === '1';

  // Master App State
  const [state, setState] = useState<AppState>(() => {
    // Initial benchmark data fallback in case API is bootstrapping
    const initialMall = generateMallCustomersData();
    const initialMeta = inspectDataset('Mall Customers Benchmark (Demographics & Spending)', initialMall, true);
    const initialEcom = generateEcommerceDataset();

    // Run initial local K-Means so charts are instantly rendered
    const matrix = initialMall.map((r) => [r['Annual Income (k$)'], r['Spending Score (1-100)'], r.Age]);
    const { scaled } = standardScale(matrix);
    const km = runKMeans(scaled, 4, 50);
    const sil = calculateSilhouetteScore(scaled, km.assignments);
    const dbi = calculateDaviesBouldinIndex(scaled, km.assignments);
    const ch = calculateCalinskiHarabaszScore(scaled, km.assignments);
    const pca = calculatePCA(scaled, 3);
    const elbow = calculateElbowCurve(matrix, 7);

    // Initial clusters
    const initialClusters = [0, 1, 2, 3].map((cId) => {
      const memberIndices = km.assignments.map((a, i) => (a === cId ? i : -1)).filter((i) => i >= 0);
      const memberCount = memberIndices.length;
      const count = memberCount || 1;
      const avgInc = Math.round(memberIndices.reduce((s, idx) => s + matrix[idx][0], 0) / count);
      const avgSp = Math.round(memberIndices.reduce((s, idx) => s + matrix[idx][1], 0) / count);
      const avgAge = Math.round(memberIndices.reduce((s, idx) => s + matrix[idx][2], 0) / count);

      let label = `Segment ${cId + 1}`;
      if (avgSp > 70 && avgInc > 60) label = 'VIP Champions / High Spenders';
      else if (avgInc > 70 && avgSp <= 45) label = 'Affluent / High-Income Conservative';
      else if (avgSp > 60 && avgInc <= 45) label = 'Careless / Trendsetters';
      else label = 'Budget / Price-Sensitive Shoppers';

      return {
        clusterId: cId,
        label,
        centroid: [avgInc, avgSp, avgAge],
        memberCount,
        percentage: Number(((memberCount / initialMall.length) * 100).toFixed(1)),
        memberIndices,
        featureAverages: [avgInc, avgSp, avgAge],
      };
    });

    // Initial RFM
    const rfmRes = runRFMAnalysis(
      initialEcom.map((row) => ({
        customerId: row.CustomerID,
        customerName: row.CustomerName,
        recencyDays: row.RecencyDays,
        orderFrequency: row.OrderFrequency,
        totalMonetary: row.TotalSpend,
        favoriteCategory: row.FavoriteCategory,
      }))
    );

    // Initial Churn
    const churnRes = runChurnAnalysis(
      initialEcom.map((row) => ({
        customerId: row.CustomerID,
        customerName: row.CustomerName,
        recencyDays: row.RecencyDays,
        orderFrequency: row.OrderFrequency,
        totalSpend: row.TotalSpend,
        supportTickets: row.SupportTickets,
        engagementScore: row.EngagementScore,
      }))
    );

    return {
      activeTab: autostart ? 'dashboard' : 'landing',
      currentDatasetId: 'mall-benchmark',
      datasets: [
        { id: 'mall-benchmark', name: 'Mall Customers Benchmark (Demographics & Spending)', rowCount: 200, isDemo: true },
        { id: 'ecom-omnichannel', name: 'E-Commerce Omnichannel (Transactions & Product Cycles)', rowCount: 150, isDemo: true },
      ],
      currentDataset: initialMeta,
      currency: 'INR',
      algorithm: 'kmeans',
      selectedFeatures: ['Annual Income (k$)', 'Spending Score (1-100)', 'Age'],
      kClusters: 4,
      clusters: initialClusters,
      pcaCoordinates: pca.map((coords, idx) => ({
        x: coords[0] ?? 0,
        y: coords[1] ?? 0,
        z: coords[2] ?? 0,
        cluster: km.assignments[idx],
        id: initialMall[idx].CustomerID,
        metadata: initialMall[idx],
      })),
      silhouetteScore: sil,
      daviesBouldinIndex: dbi,
      calinskiHarabaszScore: ch,
      inertia: Math.round(km.inertia * 10) / 10,
      elbowCurve: elbow,
      rfmCustomers: rfmRes.scoredCustomers,
      rfmSummaries: rfmRes.segmentSummaries,
      churnProfiles: churnRes.profiles,
      churnMetrics: churnRes.metrics,
      productCycles: BRAND_PRODUCT_CYCLES,
      user: { name: 'Growth Strategist', email: 'director@segmentiq.ai', role: 'Principal Growth Analyst' },
      isLoggedIn: true,
      isLoading: false,
      notification: null,
    };
  });

  // Fetch live datasets from backend server
  const loadDataset = useCallback(async (datasetId: string) => {
    setState((s) => ({ ...s, isLoading: true }));
    try {
      const res = await fetch(`/api/datasets/${datasetId}`);
      if (res.ok) {
        const data = await res.json();
        const meta = data.dataset;
        setState((s) => ({
          ...s,
          currentDatasetId: datasetId,
          currentDataset: meta,
          selectedFeatures: meta.suggestedClusteringFeatures.slice(0, 3),
        }));

        // Execute clustering for this dataset
        executeClustering({
          datasetId,
          algorithm: state.algorithm,
          features: meta.suggestedClusteringFeatures.slice(0, 3),
          k: state.kClusters,
          maxIterations: 100,
          linkage: 'average',
          eps: 0.8,
          minSamples: 4,
        });

        // Execute RFM & Churn
        fetchRFM(datasetId);
        fetchChurn(datasetId);
      }
    } catch (e) {
      console.warn('Backend dataset fetch error, using local state:', e);
    } finally {
      setState((s) => ({ ...s, isLoading: false }));
    }
  }, [state.algorithm, state.kClusters]);

  // Execute clustering via API
  const executeClustering = async (params: {
    datasetId?: string;
    algorithm?: string;
    features?: string[];
    k?: number;
    maxIterations?: number;
    linkage?: string;
    eps?: number;
    minSamples?: number;
  }) => {
    setState((s) => ({ ...s, isLoading: true }));
    try {
      const res = await fetch('/api/segmentation/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          datasetId: params.datasetId || state.currentDatasetId,
          algorithm: params.algorithm || state.algorithm,
          features: params.features || state.selectedFeatures,
          k: params.k || state.kClusters,
          maxIterations: params.maxIterations || 100,
          linkage: params.linkage || 'average',
          eps: params.eps || 0.8,
          minSamples: params.minSamples || 4,
        }),
      });

      if (res.ok) {
        const result = await res.json();
        setState((s) => ({
          ...s,
          algorithm: result.algorithm,
          clusters: result.clusters,
          silhouetteScore: result.silhouetteScore,
          daviesBouldinIndex: result.daviesBouldinIndex,
          calinskiHarabaszScore: result.calinskiHarabaszScore,
          inertia: result.inertia,
          elbowCurve: result.elbowCurve || s.elbowCurve,
          pcaCoordinates: result.pcaCoordinates || s.pcaCoordinates,
          selectedFeatures: result.featureNames || s.selectedFeatures,
          kClusters: params.k || s.kClusters,
        }));
      }
    } catch (e) {
      console.warn('API clustering error:', e);
    } finally {
      setState((s) => ({ ...s, isLoading: false }));
    }
  };

  const fetchRFM = async (datasetId: string) => {
    try {
      const res = await fetch('/api/rfm/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ datasetId }),
      });
      if (res.ok) {
        const data = await res.json();
        setState((s) => ({
          ...s,
          rfmCustomers: data.scoredCustomers,
          rfmSummaries: data.segmentSummaries,
        }));
      }
    } catch (e) {
      console.warn('RFM API fetch error:', e);
    }
  };

  const fetchChurn = async (datasetId: string) => {
    try {
      const res = await fetch('/api/churn/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ datasetId }),
      });
      if (res.ok) {
        const data = await res.json();
        setState((s) => ({
          ...s,
          churnProfiles: data.profiles,
          churnMetrics: data.metrics,
        }));
      }
    } catch (e) {
      console.warn('Churn API fetch error:', e);
    }
  };

  const handleUploadDataset = async (name: string, rawText: string) => {
    setState((s) => ({ ...s, isLoading: true }));
    try {
      const res = await fetch('/api/datasets/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, rawText }),
      });
      if (res.ok) {
        const data = await res.json();
        const newMeta = data.metadata;
        const newId = data.datasetId;
        setState((s) => ({
          ...s,
          datasets: [{ id: newId, name: newMeta.name, rowCount: newMeta.rowCount, isDemo: false }, ...s.datasets],
          currentDatasetId: newId,
          currentDataset: newMeta,
          selectedFeatures: newMeta.suggestedClusteringFeatures.slice(0, 3),
        }));
        executeClustering({ datasetId: newId, features: newMeta.suggestedClusteringFeatures.slice(0, 3) });
        fetchRFM(newId);
        fetchChurn(newId);
      }
    } catch (e) {
      console.warn('Upload error:', e);
    } finally {
      setState((s) => ({ ...s, isLoading: false }));
    }
  };

  return (
    <div className="flex h-screen w-screen flex-col bg-[#0B1020] text-[#F8FAFC] overflow-hidden select-none">
      {/* Top Header */}
      <Header
        state={state}
        onTabChange={(tab) => setState((s) => ({ ...s, activeTab: tab }))}
        onDatasetSelect={(id) => loadDataset(id)}
        onCurrencyChange={(c) => setState((s) => ({ ...s, currency: c }))}
        onLogout={() => setState((s) => ({ ...s, activeTab: 'landing' }))}
        onOpenAI={() => setState((s) => ({ ...s, activeTab: 'ai-intelligence' }))}
      />

      {/* Main Container */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar Navigation */}
        <Sidebar
          activeTab={state.activeTab}
          onTabChange={(tab) => setState((s) => ({ ...s, activeTab: tab }))}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        />

        {/* Viewport Content */}
        <main className="flex-1 overflow-y-auto bg-[#0B1020] relative">
          {state.activeTab === 'landing' && (
            <LandingPage
              onExplore={() => setState((s) => ({ ...s, activeTab: 'dashboard' }))}
              onViewDemo={() => {
                loadDataset('mall-benchmark');
                setState((s) => ({ ...s, activeTab: 'dashboard' }));
              }}
              onTabChange={(tab) => setState((s) => ({ ...s, activeTab: tab }))}
            />
          )}

          {state.activeTab === 'dashboard' && (
            <DashboardOverview
              state={state}
              onTabChange={(tab) => setState((s) => ({ ...s, activeTab: tab }))}
              onExport={() => setState((s) => ({ ...s, activeTab: 'reports' }))}
            />
          )}

          {state.activeTab === 'data-management' && (
            <DataManagementView
              state={state}
              onTabChange={(tab) => setState((s) => ({ ...s, activeTab: tab }))}
              onUploadDataset={handleUploadDataset}
              onSwitchDataset={(id) => loadDataset(id)}
            />
          )}

          {state.activeTab === 'segmentation' && (
            <SegmentationEngineView
              state={state}
              onTabChange={(tab) => setState((s) => ({ ...s, activeTab: tab }))}
              onRunClustering={(params) => executeClustering(params)}
            />
          )}

          {state.activeTab === 'personas' && (
            <CustomerPersonasView
              state={state}
              onTabChange={(tab) => setState((s) => ({ ...s, activeTab: tab }))}
            />
          )}

          {state.activeTab === 'rfm' && (
            <RFMAnalysisView
              state={state}
              onTabChange={(tab) => setState((s) => ({ ...s, activeTab: tab }))}
            />
          )}

          {state.activeTab === 'churn' && (
            <ChurnRetentionView
              state={state}
              onTabChange={(tab) => setState((s) => ({ ...s, activeTab: tab }))}
            />
          )}

          {state.activeTab === 'seasonal-trends' && (
            <SeasonalTrendsView
              state={state}
              onTabChange={(tab) => setState((s) => ({ ...s, activeTab: tab }))}
            />
          )}

          {state.activeTab === 'campaigns' && (
            <CampaignAutomationView
              state={state}
              onTabChange={(tab) => setState((s) => ({ ...s, activeTab: tab }))}
            />
          )}

          {state.activeTab === 'what-if' && (
            <WhatIfSimulatorView
              state={state}
              onTabChange={(tab) => setState((s) => ({ ...s, activeTab: tab }))}
            />
          )}

          {state.activeTab === 'ai-intelligence' && (
            <AIIntelligenceView
              state={state}
              onTabChange={(tab) => setState((s) => ({ ...s, activeTab: tab }))}
            />
          )}

          {state.activeTab === 'reports' && (
            <ReportsExportView
              state={state}
              onTabChange={(tab) => setState((s) => ({ ...s, activeTab: tab }))}
            />
          )}
        </main>
      </div>
    </div>
  );
}
