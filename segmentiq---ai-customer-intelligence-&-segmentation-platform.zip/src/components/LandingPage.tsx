import React from 'react';
import {
  Sparkles,
  ArrowRight,
  Network,
  BarChart3,
  Flame,
  Calendar,
  Layers,
  ShieldCheck,
  CheckCircle2,
  Cpu,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import type { ActiveTab } from '../types/index.ts';

interface LandingPageProps {
  onExplore: () => void;
  onViewDemo: () => void;
  onTabChange: (tab: ActiveTab) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onExplore,
  onViewDemo,
  onTabChange,
}) => {
  return (
    <div className="relative min-h-[calc(100vh-4rem)] overflow-y-auto px-4 py-8 md:px-12 md:py-16">
      {/* Background glow effects */}
      <div className="pointer-events-none absolute left-1/2 top-10 -translate-x-1/2 w-[700px] h-[350px] bg-gradient-to-tr from-indigo-600/20 via-cyan-500/10 to-transparent blur-3xl -z-10 rounded-full" />

      {/* Hero Section */}
      <div className="mx-auto max-w-5xl text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 rounded-full border border-indigo-500/30 bg-indigo-500/10 px-3.5 py-1 text-xs font-semibold text-indigo-300 backdrop-blur-md mb-6">
          <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
          <span>Next-Gen Enterprise Customer Intelligence &amp; Retention</span>
        </div>

        {/* Main Heading */}
        <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-6xl md:text-7xl">
          Turn Customer Data Into <br className="hidden sm:inline" />
          <span className="bg-gradient-to-r from-indigo-400 via-cyan-300 to-indigo-200 bg-clip-text text-transparent">
            Growth Opportunities
          </span>
        </h1>

        {/* Subtitle */}
        <p className="mx-auto mt-6 max-w-2xl text-base sm:text-lg text-slate-300 leading-relaxed">
          Discover customer segments, understand purchasing behavior, and build smarter marketing strategies with AI-powered analytics. Uncover high-value champions, predict churn risk, and trigger dynamic seasonal upgrade campaigns.
        </p>

        {/* Primary CTAs */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
          <button
            onClick={onExplore}
            className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-500 px-6 py-3.5 text-sm font-bold text-white shadow-xl shadow-indigo-600/30 transition-all hover:scale-105 hover:shadow-indigo-600/50"
          >
            <span>Explore Dashboard</span>
            <ArrowRight className="h-4 w-4" />
          </button>

          <button
            onClick={onViewDemo}
            className="flex items-center gap-2 rounded-xl border border-white/15 bg-slate-900/80 px-6 py-3.5 text-sm font-semibold text-slate-200 backdrop-blur-md transition-all hover:border-indigo-400 hover:bg-slate-800 hover:text-white"
          >
            <span>View Demo Benchmark</span>
            <Sparkles className="h-4 w-4 text-cyan-400" />
          </button>
        </div>

        {/* Key Metrics Highlight Pill */}
        <div className="mt-12 grid grid-cols-2 gap-3 sm:grid-cols-4 max-w-3xl mx-auto">
          <div className="rounded-2xl border border-white/5 bg-slate-900/60 p-4 text-center backdrop-blur-md">
            <div className="text-2xl font-black text-indigo-400">4+</div>
            <div className="text-xs text-slate-400 font-medium mt-1">Clustering Models (K-Means, GMM, DBSCAN)</div>
          </div>
          <div className="rounded-2xl border border-white/5 bg-slate-900/60 p-4 text-center backdrop-blur-md">
            <div className="text-2xl font-black text-cyan-400">RFM</div>
            <div className="text-xs text-slate-400 font-medium mt-1">11 Behavioral Segments &amp; Scoring</div>
          </div>
          <div className="rounded-2xl border border-white/5 bg-slate-900/60 p-4 text-center backdrop-blur-md">
            <div className="text-2xl font-black text-emerald-400">&lt;24m</div>
            <div className="text-xs text-slate-400 font-medium mt-1">Brand Cycle &amp; Upgrade Tracking</div>
          </div>
          <div className="rounded-2xl border border-white/5 bg-slate-900/60 p-4 text-center backdrop-blur-md">
            <div className="text-2xl font-black text-amber-400">Gemini 4</div>
            <div className="text-xs text-slate-400 font-medium mt-1">High Thinking Strategic AI</div>
          </div>
        </div>
      </div>

      {/* Feature Capabilities Grid */}
      <div className="mx-auto mt-20 max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="text-xs font-bold uppercase tracking-wider text-cyan-400">
            Comprehensive Customer Intelligence Stack
          </h2>
          <p className="mt-2 text-2xl font-bold tracking-tight text-white sm:text-3xl">
            Everything Required to Segment, Predict &amp; Retain
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Unsupervised ML */}
          <div className="group rounded-2xl border border-white/10 bg-slate-900/70 p-6 backdrop-blur-xl transition-all hover:border-indigo-500/40 hover:bg-slate-800/80">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 mb-4 group-hover:scale-110 transition-transform">
              <Network className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-bold text-white">Unsupervised ML Clustering</h3>
            <p className="mt-2 text-xs text-slate-400 leading-relaxed">
              Run real K-Means, Agglomerative Hierarchical, DBSCAN for density outliers, and Gaussian Mixture Models with interactive Elbow Method and PCA 2D/3D projections.
            </p>
            <div className="mt-4 flex flex-wrap gap-1.5 text-[10px] text-indigo-300">
              <span className="rounded bg-indigo-500/10 px-2 py-0.5 border border-indigo-500/20">Silhouette</span>
              <span className="rounded bg-indigo-500/10 px-2 py-0.5 border border-indigo-500/20">Davies-Bouldin</span>
              <span className="rounded bg-indigo-500/10 px-2 py-0.5 border border-indigo-500/20">Calinski-Harabasz</span>
            </div>
          </div>

          {/* Card 2: RFM & Personas */}
          <div className="group rounded-2xl border border-white/10 bg-slate-900/70 p-6 backdrop-blur-xl transition-all hover:border-cyan-500/40 hover:bg-slate-800/80">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 mb-4 group-hover:scale-110 transition-transform">
              <BarChart3 className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-bold text-white">RFM &amp; Customer Personas</h3>
            <p className="mt-2 text-xs text-slate-400 leading-relaxed">
              Calculate Recency, Frequency, and Monetary scores. Generate visual personas: Champions, Loyal High-Earners, Potential Loyalists, and At-Risk Accounts.
            </p>
            <div className="mt-4 flex flex-wrap gap-1.5 text-[10px] text-cyan-300">
              <span className="rounded bg-cyan-500/10 px-2 py-0.5 border border-cyan-500/20">Quintile Scoring</span>
              <span className="rounded bg-cyan-500/10 px-2 py-0.5 border border-cyan-500/20">RFM Grid Heatmap</span>
              <span className="rounded bg-cyan-500/10 px-2 py-0.5 border border-cyan-500/20">Persona Dossiers</span>
            </div>
          </div>

          {/* Card 3: Predictive Churn & Cycles */}
          <div className="group rounded-2xl border border-white/10 bg-slate-900/70 p-6 backdrop-blur-xl transition-all hover:border-rose-500/40 hover:bg-slate-800/80">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20 mb-4 group-hover:scale-110 transition-transform">
              <Flame className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-bold text-white">Predictive Churn &amp; Product Cycles</h3>
            <p className="mt-2 text-xs text-slate-400 leading-relaxed">
              Sigmoid-calibrated churn modeling detects lapsed buyers before they churn. Track seasonal brand cadences like Samsung Galaxy flagship releases for dynamic pricing.
            </p>
            <div className="mt-4 flex flex-wrap gap-1.5 text-[10px] text-rose-300">
              <span className="rounded bg-rose-500/10 px-2 py-0.5 border border-rose-500/20">Churn Probability</span>
              <span className="rounded bg-rose-500/10 px-2 py-0.5 border border-rose-500/20">18-24m Upgrade Window</span>
              <span className="rounded bg-rose-500/10 px-2 py-0.5 border border-rose-500/20">Dynamic Pricing</span>
            </div>
          </div>
        </div>
      </div>

      {/* Demo Testimonials Section (Clearly labeled) */}
      <div className="mx-auto mt-20 max-w-4xl rounded-3xl border border-white/10 bg-slate-900/50 p-8 backdrop-blur-xl">
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center gap-2">
            <span className="rounded bg-amber-500/20 px-2 py-0.5 text-[11px] font-bold text-amber-300 border border-amber-500/30">
              DEMO CASE STUDIES &amp; SIMULATED TESTIMONIALS
            </span>
            <span className="text-xs text-slate-400">Industry Validation</span>
          </div>
          <span className="text-xs text-slate-500">Retail &bull; E-Commerce &bull; Electronics</span>
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
          <div className="rounded-xl border border-white/5 bg-slate-900 p-4">
            <p className="text-xs text-slate-300 italic leading-relaxed">
              &ldquo;SegmentIQ enabled us to map 18-month device upgrade windows for Samsung flagship buyers and automate dynamic trade-in vouchers. Retention recovered by 21%.&rdquo;
            </p>
            <div className="mt-3 flex items-center gap-2">
              <div className="h-7 w-7 rounded-full bg-indigo-600/40 text-indigo-300 flex items-center justify-center font-bold text-xs">
                A
              </div>
              <div>
                <div className="text-xs font-semibold text-white">Ananya Mehta</div>
                <div className="text-[10px] text-slate-400">VP Marketing, Consumer Electronics (Simulated Demo)</div>
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-white/5 bg-slate-900 p-4">
            <p className="text-xs text-slate-300 italic leading-relaxed">
              &ldquo;The K-Means and RFM engine segmented our customer base without manual guesswork. The AI Strategic Advisor gave us immediate executive revenue roadmaps.&rdquo;
            </p>
            <div className="mt-3 flex items-center gap-2">
              <div className="h-7 w-7 rounded-full bg-cyan-600/40 text-cyan-300 flex items-center justify-center font-bold text-xs">
                R
              </div>
              <div>
                <div className="text-xs font-semibold text-white">Rajesh Verma</div>
                <div className="text-[10px] text-slate-400">Head of Data Science, Omnichannel Retail (Simulated Demo)</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="mx-auto mt-20 max-w-6xl border-t border-white/10 pt-8 pb-4 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
        <div className="flex items-center gap-2">
          <span className="font-bold text-slate-300">SegmentIQ</span>
          <span>&bull; Understand Your Customers. Discover Opportunities. Drive Growth.</span>
        </div>
        <div>
          Data Science &amp; Full-Stack Customer Intelligence Platform &bull; Built with React, TypeScript &amp; Gemini 4
        </div>
      </footer>
    </div>
  );
};
