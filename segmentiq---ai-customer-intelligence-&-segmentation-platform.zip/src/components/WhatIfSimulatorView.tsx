import React, { useState, useMemo } from 'react';
import {
  SlidersHorizontal,
  Sparkles,
  Layers,
  Flame,
  ShieldCheck,
  Send,
  RefreshCw,
  TrendingUp,
  Cpu,
  ArrowRight,
} from 'lucide-react';
import type { AppState, ActiveTab } from '../types/index.ts';
import { predictCustomerChurn } from '../utils/churnPrediction.ts';
import { classifyRFMSegment } from '../utils/rfmAnalysis.ts';
import { evaluateProductCycleStatus } from '../utils/seasonalCycleAnalysis.ts';

interface WhatIfSimulatorViewProps {
  state: AppState;
  onTabChange: (tab: ActiveTab) => void;
}

export const WhatIfSimulatorView: React.FC<WhatIfSimulatorViewProps> = ({
  state,
  onTabChange,
}) => {
  const currencySymbol = state.currency === 'INR' ? '₹' : '$';
  const currencyRate = state.currency === 'INR' ? 1 : 0.012;

  // Simulator Sliders State
  const [income, setIncome] = useState<number>(65000);
  const [spendingScore, setSpendingScore] = useState<number>(60);
  const [orderFrequency, setOrderFrequency] = useState<number>(8);
  const [recencyDays, setRecencyDays] = useState<number>(25);
  const [supportTickets, setSupportTickets] = useState<number>(1);
  const [deviceAgeMonths, setDeviceAgeMonths] = useState<number>(19);
  const [brandAffinity, setBrandAffinity] = useState<string>('Samsung');

  // Real-time recalculation of what-if scenario
  const simulation = useMemo(() => {
    // 1. Churn prediction
    const churn = predictCustomerChurn(
      recencyDays,
      orderFrequency,
      income * 0.4,
      supportTickets,
      Math.max(10, 100 - recencyDays * 0.5)
    );

    // 2. RFM Quintiles (approximate mapping)
    const rScore = recencyDays <= 15 ? 5 : recencyDays <= 35 ? 4 : recencyDays <= 60 ? 3 : recencyDays <= 90 ? 2 : 1;
    const fScore = orderFrequency >= 18 ? 5 : orderFrequency >= 10 ? 4 : orderFrequency >= 5 ? 3 : orderFrequency >= 2 ? 2 : 1;
    const mScore = spendingScore >= 80 ? 5 : spendingScore >= 60 ? 4 : spendingScore >= 40 ? 3 : spendingScore >= 20 ? 2 : 1;
    const rfm = classifyRFMSegment(rScore, fScore, mScore);

    // 3. Brand product cycle & dynamic pricing
    const cycle = evaluateProductCycleStatus(brandAffinity, deviceAgeMonths, income * 0.5, spendingScore);

    // 4. Cluster mapping
    let projectedCluster = 'Standard Customer Segment';
    if (spendingScore > 70 && income > 60000) projectedCluster = 'VIP Champions / High Spenders';
    else if (income > 75000 && spendingScore <= 50) projectedCluster = 'Affluent / High-Income Conservative';
    else if (spendingScore > 65 && income <= 45000) projectedCluster = 'Trendsetters / Enthusiast Spenders';
    else if (income <= 40000 && spendingScore <= 40) projectedCluster = 'Budget / Price-Sensitive Shoppers';

    return {
      churn,
      rfmScore: `${rScore}${fScore}${mScore}`,
      rfmSegment: rfm.segment,
      rfmAction: rfm.suggestedAction,
      cycle,
      projectedCluster,
    };
  }, [income, spendingScore, orderFrequency, recencyDays, supportTickets, deviceAgeMonths, brandAffinity]);

  return (
    <div className="space-y-6 p-4 md:p-8 overflow-y-auto max-h-[calc(100vh-4rem)]">
      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
              What-If Machine Learning Simulator
            </h1>
            <span className="rounded-full border border-cyan-500/30 bg-cyan-500/10 px-2.5 py-0.5 text-[10px] font-bold text-cyan-300">
              Interactive Inference
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Dynamically adjust customer behaviors to project cluster movement, churn probability shifts, and dynamic pricing reactions.
          </p>
        </div>

        <button
          onClick={() => {
            setIncome(85000);
            setSpendingScore(88);
            setOrderFrequency(22);
            setRecencyDays(8);
            setSupportTickets(0);
            setDeviceAgeMonths(21);
          }}
          className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-slate-900 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:bg-slate-800 hover:text-white"
        >
          <Sparkles className="h-3.5 w-3.5 text-amber-300" />
          <span>Preset: High-Value VIP</span>
        </button>
      </div>

      {/* Simulator Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left: Interactive Input Sliders */}
        <div className="glass-panel rounded-2xl p-6 space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <SlidersHorizontal className="h-4 w-4 text-cyan-400" />
              Simulated Customer Parameters
            </h3>
            <span className="text-[10px] text-slate-400">Adjust in real-time</span>
          </div>

          {/* Slider 1: Annual Income */}
          <div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Annual Income</span>
              <span className="font-mono text-cyan-400 font-bold">
                {currencySymbol}{Math.round(income * currencyRate).toLocaleString()}
              </span>
            </div>
            <input
              type="range"
              min={15000}
              max={150000}
              step={2000}
              value={income}
              onChange={(e) => setIncome(Number(e.target.value))}
              className="mt-2 w-full accent-cyan-500 cursor-pointer"
              aria-label="Annual income"
            />
          </div>

          {/* Slider 2: Spending Score */}
          <div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Spending Score (1-100)</span>
              <span className="font-mono text-indigo-400 font-bold">{spendingScore} / 100</span>
            </div>
            <input
              type="range"
              min={1}
              max={100}
              value={spendingScore}
              onChange={(e) => setSpendingScore(Number(e.target.value))}
              className="mt-2 w-full accent-indigo-500 cursor-pointer"
              aria-label="Spending score"
            />
          </div>

          {/* Slider 3: Recency Days */}
          <div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Recency (Days Since Last Order)</span>
              <span className={`font-mono font-bold ${recencyDays > 60 ? 'text-rose-400' : 'text-emerald-400'}`}>
                {recencyDays} Days
              </span>
            </div>
            <input
              type="range"
              min={1}
              max={180}
              value={recencyDays}
              onChange={(e) => setRecencyDays(Number(e.target.value))}
              className="mt-2 w-full accent-rose-500 cursor-pointer"
              aria-label="Recency days"
            />
          </div>

          {/* Slider 4: Order Frequency */}
          <div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Lifetime Order Frequency</span>
              <span className="font-mono text-cyan-400 font-bold">{orderFrequency} Orders</span>
            </div>
            <input
              type="range"
              min={1}
              max={40}
              value={orderFrequency}
              onChange={(e) => setOrderFrequency(Number(e.target.value))}
              className="mt-2 w-full accent-cyan-500 cursor-pointer"
              aria-label="Order frequency"
            />
          </div>

          {/* Slider 5: Support Tickets */}
          <div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Support Tickets / Complaints</span>
              <span className="font-mono text-amber-400 font-bold">{supportTickets} logged</span>
            </div>
            <input
              type="range"
              min={0}
              max={6}
              value={supportTickets}
              onChange={(e) => setSupportTickets(Number(e.target.value))}
              className="mt-2 w-full accent-amber-500 cursor-pointer"
              aria-label="Support tickets"
            />
          </div>

          {/* Slider 6: Device Age & Brand */}
          <div className="pt-2 border-t border-white/5 space-y-3">
            <div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Device Age (Samsung / Tech)</span>
                <span className="font-mono text-indigo-300 font-bold">{deviceAgeMonths} Months</span>
              </div>
              <input
                type="range"
                min={2}
                max={36}
                value={deviceAgeMonths}
                onChange={(e) => setDeviceAgeMonths(Number(e.target.value))}
                className="mt-2 w-full accent-indigo-500 cursor-pointer"
                aria-label="Device age months"
              />
            </div>
          </div>
        </div>

        {/* Right: Live Real-Time Projection Outputs */}
        <div className="space-y-4">
          {/* Projected Cluster */}
          <div className="glass-panel rounded-2xl p-5 border border-indigo-500/30">
            <div className="flex items-center justify-between pb-2 border-b border-indigo-500/20">
              <span className="text-[10px] uppercase font-bold text-indigo-400 tracking-wider">
                Unsupervised Cluster Classification
              </span>
              <Cpu className="h-4 w-4 text-indigo-400" />
            </div>
            <div className="mt-2 text-lg font-bold text-white">{simulation.projectedCluster}</div>
            <p className="mt-1 text-xs text-slate-400">
              Assigned based on proximity to learned K-Means &amp; GMM centroids.
            </p>
          </div>

          {/* Predicted Churn Risk Box */}
          <div className="glass-panel rounded-2xl p-5 border border-rose-500/30">
            <div className="flex items-center justify-between pb-2 border-b border-rose-500/20">
              <span className="text-[10px] uppercase font-bold text-rose-400 tracking-wider">
                Predictive Churn Risk Probability
              </span>
              <span className="rounded-full bg-rose-500/20 px-2 py-0.5 text-xs font-bold text-rose-300 border border-rose-500/30">
                {simulation.churn.riskTier}
              </span>
            </div>
            <div className="mt-2 flex items-baseline gap-3">
              <span className="text-3xl font-black text-rose-400">
                {simulation.churn.churnProbability}%
              </span>
              <span className="text-xs text-slate-400">Probability of Customer Churn</span>
            </div>
            <div className="mt-2 text-xs text-slate-300">
              <strong>Retention Strategy:</strong> {simulation.churn.recommendedPlaybook}
            </div>
          </div>

          {/* RFM Classification Box */}
          <div className="glass-panel rounded-2xl p-5 border border-cyan-500/30">
            <div className="flex items-center justify-between pb-2 border-b border-cyan-500/20">
              <span className="text-[10px] uppercase font-bold text-cyan-400 tracking-wider">
                RFM Quintile Segment
              </span>
              <span className="font-mono text-xs font-bold text-cyan-300 bg-cyan-500/10 px-2 py-0.5 rounded">
                Score: {simulation.rfmScore}
              </span>
            </div>
            <div className="mt-2 text-lg font-bold text-white">{simulation.rfmSegment}</div>
            <p className="mt-1 text-xs text-slate-400">{simulation.rfmAction}</p>
          </div>

          {/* Dynamic Pricing Reaction */}
          <div className="glass-panel rounded-2xl p-5 border border-amber-500/30">
            <div className="flex items-center justify-between pb-2 border-b border-amber-500/20">
              <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
                Seasonal Brand Cycle &amp; Dynamic Pricing
              </span>
              <span className="text-xs text-amber-300 font-semibold">{simulation.cycle.lifecycleStatus}</span>
            </div>
            <div className="mt-2 text-xs text-slate-200">
              <strong>Dynamic Incentive:</strong> {simulation.cycle.dynamicPriceOffer}
            </div>
            <p className="mt-1 text-[11px] text-slate-400">{simulation.cycle.campaignTrigger}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
