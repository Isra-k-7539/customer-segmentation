import React, { useState } from 'react';
import {
  Bell,
  Search,
  Sparkles,
  Database,
  User,
  ShieldCheck,
  CheckCircle,
  ExternalLink,
  ChevronDown,
} from 'lucide-react';
import type { AppState, ActiveTab } from '../types/index.ts';

interface HeaderProps {
  state: AppState;
  onTabChange: (tab: ActiveTab) => void;
  onDatasetSelect: (id: string) => void;
  onCurrencyChange: (c: 'INR' | 'USD') => void;
  onLogout: () => void;
  onOpenAI: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  state,
  onTabChange,
  onDatasetSelect,
  onCurrencyChange,
  onLogout,
  onOpenAI,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showDatasetMenu, setShowDatasetMenu] = useState(false);

  const notifications = [
    {
      id: 1,
      title: 'Optimal Upgrade Cycle Window',
      desc: '34 Samsung device owners have crossed 18 months device age. Dynamic upgrade campaign triggered.',
      time: '10m ago',
      type: 'promo',
    },
    {
      id: 2,
      title: 'High Churn Alert',
      desc: '12 high-value customers flagged with >60 days inactivity. Reactivation sequence primed.',
      time: '1h ago',
      type: 'warning',
    },
    {
      id: 3,
      title: 'Model Optimization Complete',
      desc: 'K-Means clustering converged with Silhouette Score 0.68 across 4 customer segments.',
      time: '3h ago',
      type: 'success',
    },
  ];

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-white/10 bg-[#0B1020]/90 px-4 md:px-6 backdrop-blur-md">
      {/* Left: Brand Identity & Active Page Context */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => onTabChange('landing')}
          className="flex items-center gap-2.5 transition-transform hover:scale-105"
          aria-label="SegmentIQ Home"
        >
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-cyan-400 font-black text-white shadow-lg shadow-indigo-500/25">
            S
          </div>
          <div className="flex flex-col text-left">
            <span className="text-base font-bold tracking-tight text-white flex items-center gap-1.5">
              SegmentIQ
              <span className="rounded-md bg-indigo-500/20 px-1.5 py-0.5 text-[10px] font-semibold tracking-wider text-indigo-300 border border-indigo-500/30">
                PRO
              </span>
            </span>
            <span className="text-[11px] text-slate-400 hidden sm:inline">
              Customer Intelligence
            </span>
          </div>
        </button>

        {/* Dataset Selector Dropdown */}
        <div className="relative ml-2 sm:ml-4">
          <button
            onClick={() => setShowDatasetMenu(!showDatasetMenu)}
            className="flex items-center gap-2 rounded-lg border border-white/10 bg-slate-900/80 px-2.5 py-1.5 text-xs font-medium text-slate-200 transition-colors hover:border-indigo-500/50 hover:bg-slate-800"
            aria-label="Select Dataset"
          >
            <Database className="h-3.5 w-3.5 text-cyan-400" />
            <span className="max-w-[140px] truncate sm:max-w-[200px]">
              {state.currentDataset?.name || 'Select Dataset'}
            </span>
            {state.currentDataset?.isDemo && (
              <span className="rounded bg-amber-500/20 px-1.5 py-0.2 text-[9px] font-semibold text-amber-300 border border-amber-500/30">
                DEMO
              </span>
            )}
            <ChevronDown className="h-3 w-3 text-slate-400" />
          </button>

          {showDatasetMenu && (
            <div className="absolute left-0 mt-2 w-72 rounded-xl border border-white/10 bg-slate-900/95 p-2 shadow-2xl backdrop-blur-xl z-50">
              <div className="px-2 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                Available Datasets
              </div>
              {state.datasets.map((d) => (
                <button
                  key={d.id}
                  onClick={() => {
                    onDatasetSelect(d.id);
                    setShowDatasetMenu(false);
                  }}
                  className={`flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-left text-xs transition-colors ${
                    state.currentDatasetId === d.id
                      ? 'bg-indigo-600/20 text-indigo-300 font-medium'
                      : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex flex-col truncate pr-2">
                    <span className="truncate">{d.name}</span>
                    <span className="text-[10px] text-slate-400">{d.rowCount} records</span>
                  </div>
                  {d.isDemo && (
                    <span className="rounded bg-amber-500/10 px-1 py-0.5 text-[9px] text-amber-400">
                      Sample
                    </span>
                  )}
                </button>
              ))}
              <div className="mt-1 border-t border-white/5 pt-1">
                <button
                  onClick={() => {
                    setShowDatasetMenu(false);
                    onTabChange('data-management');
                  }}
                  className="flex w-full items-center justify-center gap-1.5 rounded-lg py-1.5 text-xs font-medium text-cyan-400 hover:bg-cyan-500/10"
                >
                  <Database className="h-3.5 w-3.5" />
                  Upload Custom Dataset (CSV/XLSX)
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Right Controls: Currency toggle, AI Reasoning button, Notifications, Profile */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Currency Switcher */}
        <div className="flex rounded-lg border border-white/10 bg-slate-900/60 p-0.5 text-xs">
          <button
            onClick={() => onCurrencyChange('INR')}
            className={`rounded-md px-2 py-1 transition-colors font-medium ${
              state.currency === 'INR'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            ₹ INR
          </button>
          <button
            onClick={() => onCurrencyChange('USD')}
            className={`rounded-md px-2 py-1 transition-colors font-medium ${
              state.currency === 'USD'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            $ USD
          </button>
        </div>

        {/* AI High Thinking Deep Advisor CTA */}
        <button
          onClick={onOpenAI}
          className="relative flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-indigo-500 via-indigo-600 to-cyan-500 px-3 py-1.5 text-xs font-semibold text-white shadow-md shadow-indigo-500/25 transition-all hover:opacity-95 hover:shadow-indigo-500/40"
          aria-label="Open AI Deep Thinking Advisor"
        >
          <Sparkles className="h-3.5 w-3.5 animate-pulse text-amber-200" />
          <span className="hidden sm:inline">AI Strategic Intelligence</span>
          <span className="sm:hidden">AI</span>
          <span className="hidden md:inline rounded bg-white/20 px-1 py-0.2 text-[9px] uppercase tracking-wider">
            Gemini 4 Argon
          </span>
        </button>

        {/* Notifications Icon with Badge */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-slate-900/80 text-slate-300 hover:border-white/20 hover:text-white"
            aria-label="View Notifications"
          >
            <Bell className="h-4 w-4" />
            <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-cyan-500"></span>
            </span>
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 rounded-xl border border-white/10 bg-slate-900/95 p-3 shadow-2xl backdrop-blur-xl z-50">
              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <span className="text-xs font-bold text-white">Live Intelligence Alerts</span>
                <span className="rounded bg-indigo-500/20 px-1.5 py-0.5 text-[10px] text-indigo-300">
                  3 New
                </span>
              </div>
              <div className="divide-y divide-white/5 py-1">
                {notifications.map((n) => (
                  <div key={n.id} className="py-2.5 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-200">{n.title}</span>
                      <span className="text-[10px] text-slate-500">{n.time}</span>
                    </div>
                    <p className="mt-1 text-[11px] text-slate-400 leading-relaxed">{n.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* User Profile Menu */}
        <div className="relative">
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center gap-2 rounded-lg border border-white/10 bg-slate-900/80 p-1.5 text-xs text-slate-200 hover:border-white/20"
            aria-label="User profile"
          >
            <div className="flex h-6 w-6 items-center justify-center rounded-md bg-indigo-600/40 text-indigo-300 font-bold">
              {state.user?.name ? state.user.name.charAt(0) : 'U'}
            </div>
            <span className="hidden lg:inline font-medium text-xs max-w-[100px] truncate">
              {state.user?.name || 'Growth Strategist'}
            </span>
          </button>

          {showUserMenu && (
            <div className="absolute right-0 mt-2 w-56 rounded-xl border border-white/10 bg-slate-900/95 p-2 shadow-2xl backdrop-blur-xl z-50">
              <div className="px-3 py-2 border-b border-white/10">
                <div className="text-xs font-bold text-white">{state.user?.name || 'Growth Strategist'}</div>
                <div className="text-[10px] text-slate-400 truncate">{state.user?.email || 'director@segmentiq.ai'}</div>
                <div className="mt-1 inline-flex items-center gap-1 rounded bg-indigo-500/10 px-1.5 py-0.5 text-[10px] text-indigo-300">
                  <ShieldCheck className="h-3 w-3 text-indigo-400" />
                  {state.user?.role || 'Principal Analyst'}
                </div>
              </div>
              <div className="py-1">
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    onTabChange('dashboard');
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800"
                >
                  <CheckCircle className="h-3.5 w-3.5 text-emerald-400" />
                  Executive Dashboard
                </button>
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    onTabChange('reports');
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800"
                >
                  <ExternalLink className="h-3.5 w-3.5 text-cyan-400" />
                  Export PDF &amp; Insights
                </button>
              </div>
              <div className="border-t border-white/10 pt-1">
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    onLogout();
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-xs text-rose-400 hover:bg-rose-500/10"
                >
                  Sign Out
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
