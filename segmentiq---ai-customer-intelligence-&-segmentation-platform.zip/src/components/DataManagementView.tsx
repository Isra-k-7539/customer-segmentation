import React, { useState, useMemo } from 'react';
import {
  UploadCloud,
  FileText,
  Search,
  Filter,
  Download,
  AlertTriangle,
  CheckCircle,
  Copy,
  ChevronLeft,
  ChevronRight,
  Database,
  RefreshCw,
  Sparkles,
  Eye,
  X,
} from 'lucide-react';
import type { AppState, ActiveTab } from '../types/index.ts';
import { parseCSV, exportToCSV } from '../utils/datasets.ts';

interface DataManagementViewProps {
  state: AppState;
  onTabChange: (tab: ActiveTab) => void;
  onUploadDataset: (name: string, rawText: string) => void;
  onSwitchDataset: (id: string) => void;
}

export const DataManagementView: React.FC<DataManagementViewProps> = ({
  state,
  onTabChange,
  onUploadDataset,
  onSwitchDataset,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [selectedCustomer, setSelectedCustomer] = useState<Record<string, any> | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);

  const dataset = state.currentDataset;
  const rawData = dataset?.data || [];

  // Filtered rows
  const filteredData = useMemo(() => {
    if (!searchTerm.trim()) return rawData;
    const term = searchTerm.toLowerCase();
    return rawData.filter((row) =>
      Object.values(row).some((val) =>
        String(val).toLowerCase().includes(term)
      )
    );
  }, [rawData, searchTerm]);

  // Pagination
  const totalPages = Math.ceil(filteredData.length / pageSize) || 1;
  const paginatedRows = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredData.slice(start, start + pageSize);
  }, [filteredData, currentPage, pageSize]);

  // Handle Drag & Drop File Upload
  const handleFileUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      if (content) {
        onUploadDataset(file.name.replace(/\.[^/.]+$/, ''), content);
        setUploadStatus(`Uploaded ${file.name} successfully!`);
        setTimeout(() => setUploadStatus(null), 4000);
      }
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  // Download cleaned dataset
  const handleDownloadCleaned = () => {
    if (rawData.length === 0) return;
    const csv = exportToCSV(rawData);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${dataset?.name || 'dataset'}_cleaned.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const hygieneScore = dataset
    ? Math.max(70, Math.round(100 - (dataset.missingValueCount * 2 + dataset.duplicateCount * 5)))
    : 100;

  const columnHeaders = rawData.length > 0 ? Object.keys(rawData[0]) : [];

  return (
    <div className="space-y-6 p-4 md:p-8 overflow-y-auto max-h-[calc(100vh-4rem)]">
      {/* Top Title & Preset switcher */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
            Customer Data Management
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Upload CSV/Excel customer tables, detect missing attributes, inspect records, and select features for ML.
          </p>
        </div>

        {/* Dataset Switcher buttons */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-medium">Switch Benchmark:</span>
          <button
            onClick={() => onSwitchDataset('mall-benchmark')}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
              state.currentDatasetId === 'mall-benchmark'
                ? 'bg-indigo-600 text-white'
                : 'border border-white/10 bg-slate-900 text-slate-300 hover:bg-slate-800'
            }`}
          >
            Mall Customers (200)
          </button>
          <button
            onClick={() => onSwitchDataset('ecom-omnichannel')}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
              state.currentDatasetId === 'ecom-omnichannel'
                ? 'bg-indigo-600 text-white'
                : 'border border-white/10 bg-slate-900 text-slate-300 hover:bg-slate-800'
            }`}
          >
            E-Commerce Omnichannel (150)
          </button>
        </div>
      </div>

      {/* Upload Zone & Dataset Hygiene Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Drag & Drop Upload Zone */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={`glass-panel rounded-2xl p-6 text-center border-2 border-dashed transition-all ${
            isDragging ? 'border-cyan-400 bg-cyan-500/10' : 'border-white/15 hover:border-indigo-400'
          }`}
        >
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            <UploadCloud className="h-6 w-6" />
          </div>
          <h3 className="mt-3 text-sm font-bold text-white">Upload Customer Dataset</h3>
          <p className="mt-1 text-xs text-slate-400">
            Drag &amp; drop your CSV or Excel file here, or click to browse.
          </p>
          <div className="mt-4 flex items-center justify-center">
            <label className="cursor-pointer rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white transition-all hover:bg-indigo-500 shadow-md shadow-indigo-600/30">
              Browse CSV File
              <input
                type="file"
                accept=".csv,.txt"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileUpload(e.target.files[0]);
                  }
                }}
              />
            </label>
          </div>
          <div className="mt-3 text-[10px] text-slate-500">
            Supported formats: CSV, TSV &bull; Max file size: 25 MB
          </div>
          {uploadStatus && (
            <div className="mt-3 rounded-lg bg-emerald-500/20 p-2 text-xs text-emerald-300 font-medium border border-emerald-500/30">
              {uploadStatus}
            </div>
          )}
        </div>

        {/* Dataset Hygiene & Quality Assessment */}
        <div className="glass-panel rounded-2xl p-6 lg:col-span-2">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white">{dataset?.name || 'Dataset Metadata'}</h3>
                {dataset?.isDemo && (
                  <span className="rounded bg-amber-500/20 px-1.5 py-0.5 text-[9px] font-bold text-amber-300">
                    DEMO BENCHMARK
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400">{dataset?.description}</p>
            </div>
            <div className="text-right">
              <span className="text-[10px] uppercase font-bold text-slate-500">Data Hygiene Score</span>
              <div className="text-2xl font-black text-emerald-400">{hygieneScore}/100</div>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="rounded-xl border border-white/5 bg-slate-900/60 p-3">
              <span className="text-[10px] uppercase font-bold text-slate-400">Total Rows</span>
              <div className="text-xl font-bold text-white mt-1">{dataset?.rowCount || 0}</div>
            </div>
            <div className="rounded-xl border border-white/5 bg-slate-900/60 p-3">
              <span className="text-[10px] uppercase font-bold text-slate-400">Columns</span>
              <div className="text-xl font-bold text-cyan-400 mt-1">{dataset?.columnCount || 0}</div>
            </div>
            <div className="rounded-xl border border-white/5 bg-slate-900/60 p-3">
              <span className="text-[10px] uppercase font-bold text-slate-400">Missing Values</span>
              <div className={`text-xl font-bold mt-1 ${dataset?.missingValueCount === 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                {dataset?.missingValueCount || 0}
              </div>
            </div>
            <div className="rounded-xl border border-white/5 bg-slate-900/60 p-3">
              <span className="text-[10px] uppercase font-bold text-slate-400">Duplicates</span>
              <div className={`text-xl font-bold mt-1 ${dataset?.duplicateCount === 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {dataset?.duplicateCount || 0}
              </div>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-white/5">
            <div className="flex items-center gap-1.5 text-xs text-slate-300">
              <Sparkles className="h-3.5 w-3.5 text-indigo-400" />
              <span>Recommended ML Features:</span>
              <span className="font-mono text-cyan-300 font-semibold">
                {dataset?.suggestedClusteringFeatures.slice(0, 3).join(', ')}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleDownloadCleaned}
                className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:bg-slate-700"
              >
                <Download className="h-3.5 w-3.5" />
                Download Cleaned CSV
              </button>
              <button
                onClick={() => onTabChange('segmentation')}
                className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-indigo-500 shadow-md shadow-indigo-600/25"
              >
                Execute Segmentation &rarr;
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Searchable Data Table */}
      <div className="glass-panel rounded-2xl p-5">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Database className="h-4 w-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white">Customer Records Preview</h3>
            <span className="rounded bg-slate-800 px-2 py-0.5 text-xs font-mono text-slate-300">
              {filteredData.length} of {rawData.length} records
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Search Input */}
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder="Search by ID, name, city..."
                className="rounded-lg border border-white/10 bg-slate-900/90 pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 w-48 sm:w-64"
              />
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 font-semibold">
                {columnHeaders.map((col) => (
                  <th key={col} className="py-2.5 px-3 whitespace-nowrap">
                    {col}
                  </th>
                ))}
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-300">
              {paginatedRows.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-800/50 transition-colors">
                  {columnHeaders.map((col) => (
                    <td key={col} className="py-2.5 px-3 whitespace-nowrap">
                      {typeof row[col] === 'number'
                        ? col.toLowerCase().includes('spend') || col.toLowerCase().includes('income')
                          ? Number(row[col]).toLocaleString()
                          : row[col]
                        : String(row[col] ?? '')}
                    </td>
                  ))}
                  <td className="py-2.5 px-3 text-right">
                    <button
                      onClick={() => setSelectedCustomer(row)}
                      className="rounded-md border border-white/10 bg-slate-800/80 p-1.5 text-slate-300 hover:border-cyan-400 hover:text-cyan-400"
                      title="Inspect Customer"
                      aria-label="Inspect customer"
                    >
                      <Eye className="h-3.5 w-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div className="mt-4 flex items-center justify-between border-t border-white/5 pt-3 text-xs text-slate-400">
          <div>
            Showing {(currentPage - 1) * pageSize + 1} to {Math.min(currentPage * pageSize, filteredData.length)} of {filteredData.length} records
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="rounded-md border border-white/10 p-1.5 disabled:opacity-40 hover:bg-slate-800"
              aria-label="Previous page"
            >
              <ChevronLeft className="h-3.5 w-3.5" />
            </button>
            <span className="px-2 font-mono text-slate-300">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="rounded-md border border-white/10 p-1.5 disabled:opacity-40 hover:bg-slate-800"
              aria-label="Next page"
            >
              <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Customer Detail Inspection Modal */}
      {selectedCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="glass-panel w-full max-w-lg rounded-2xl p-6 shadow-2xl border border-white/15">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600/30 text-indigo-300 font-bold">
                  {selectedCustomer.CustomerName ? selectedCustomer.CustomerName.charAt(0) : 'C'}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">
                    {selectedCustomer.CustomerName || selectedCustomer.CustomerID || 'Customer Details'}
                  </h3>
                  <div className="text-[10px] text-slate-400">{selectedCustomer.Email || selectedCustomer.CustomerID}</div>
                </div>
              </div>
              <button
                onClick={() => setSelectedCustomer(null)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-800 hover:text-white"
                aria-label="Close modal"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
              {Object.entries(selectedCustomer).map(([key, value]) => (
                <div key={key} className="rounded-xl border border-white/5 bg-slate-900/60 p-2.5">
                  <span className="text-[10px] uppercase font-semibold text-slate-400">{key}</span>
                  <div className="text-slate-200 font-medium mt-0.5 truncate">{String(value)}</div>
                </div>
              ))}
            </div>

            <div className="mt-6 flex justify-end gap-2">
              <button
                onClick={() => setSelectedCustomer(null)}
                className="rounded-xl border border-white/10 bg-slate-800 px-4 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-700"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
