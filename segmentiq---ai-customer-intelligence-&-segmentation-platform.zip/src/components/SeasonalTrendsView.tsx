import React, { useState } from 'react';
import {
  Calendar,
  Sparkles,
  Smartphone,
  TrendingUp,
  Percent,
  Clock,
  Send,
  CheckCircle2,
  AlertCircle,
  Layers,
  ArrowRight,
} from 'lucide-react';
import type { AppState, ActiveTab } from '../types/index.ts';
import { BRAND_PRODUCT_CYCLES, evaluateProductCycleStatus } from '../utils/seasonalCycleAnalysis.ts';

interface SeasonalTrendsViewProps {
  state: AppState;
  onTabChange: (tab: ActiveTab) => void;
}

export const SeasonalTrendsView: React.FC<SeasonalTrendsViewProps> = ({
  state,
  onTabChange,
}) => {
  const [selectedBrand, setSelectedBrand] = useState<string>('Samsung');
  const [simulatedDeviceAge, setSimulatedDeviceAge] = useState<number>(20);

  const currencySymbol = state.currency === 'INR' ? '₹' : '$';
  const currencyRate = state.currency === 'INR' ? 1 : 0.012;

  const cycles = BRAND_PRODUCT_CYCLES[selectedBrand] || BRAND_PRODUCT_CYCLES['Samsung'];

  // Calculate simulated customer upgrade readiness
  const simEvaluation = evaluateProductCycleStatus(selectedBrand, simulatedDeviceAge, 60000, 80);

  return (
    <div className="space-y-6 p-4 md:p-8 overflow-y-auto max-h-[calc(100vh-4rem)]">
      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
              Brand Product Cycles &amp; Dynamic Pricing
            </h1>
            <span className="rounded-full border border-cyan-500/30 bg-cyan-500/10 px-2.5 py-0.5 text-[10px] font-bold text-cyan-300">
              Samsung &bull; Electronics Cadence Engine
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Map seasonal product launch cycles, track 18–24 month device refresh cadences, and deploy elasticity-based pricing adjustments.
          </p>
        </div>

        {/* Brand Switcher */}
        <div className="flex rounded-lg border border-white/10 bg-slate-900/60 p-0.5 text-xs">
          {['Samsung', 'Apple', 'GeneralElectronics'].map((b) => (
            <button
              key={b}
              onClick={() => setSelectedBrand(b)}
              className={`rounded-md px-3 py-1.5 font-semibold transition-colors ${
                selectedBrand === b
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {b === 'GeneralElectronics' ? 'Consumer Tech' : b}
            </button>
          ))}
        </div>
      </div>

      {/* Seasonal Launch Timeline Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {cycles.map((cycle, idx) => (
          <div
            key={idx}
            className="glass-panel rounded-2xl p-5 border border-white/10 transition-all hover:border-cyan-500/40"
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/5">
              <span className="rounded bg-cyan-500/20 px-2 py-0.5 text-[10px] font-bold text-cyan-300 border border-cyan-500/30">
                {cycle.launchQuarter} Window
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                {cycle.typicalCadenceMonths}m Refresh Cycle
              </span>
            </div>

            <h3 className="mt-3 text-base font-bold text-white">{cycle.series}</h3>
            <p className="mt-1 text-xs text-slate-400 leading-relaxed">{cycle.description}</p>

            <div className="mt-4 rounded-xl border border-white/5 bg-slate-900/60 p-3">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400 font-medium">Optimal Upgrade Window:</span>
                <span className="font-mono text-indigo-300 font-bold">
                  {cycle.optimalUpgradeWindowMonths[0]}–{cycle.optimalUpgradeWindowMonths[1]} months
                </span>
              </div>
              <div className="mt-2 flex justify-between text-xs">
                <span className="text-slate-400 font-medium">Cycle Phase:</span>
                <span className="text-emerald-400 font-semibold">{cycle.currentCyclePhase}</span>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-white/5">
              <div className="text-[10px] uppercase font-bold text-amber-300">
                Recommended Dynamic Price Adjustment
              </div>
              <p className="mt-1 text-xs text-slate-300 leading-relaxed font-medium">
                {cycle.recommendedPriceAdjustment}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Dynamic Upgrade Window Simulator */}
      <div className="glass-panel rounded-2xl p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-4 border-b border-white/10 gap-3">
          <div>
            <h3 className="text-base font-bold text-white">
              Device Lifecycle &amp; Dynamic Pricing Simulator
            </h3>
            <p className="text-xs text-slate-400">
              Simulate customer device age to inspect dynamic pricing incentive triggers and targeted upgrade playbooks.
            </p>
          </div>
          <span className="rounded bg-indigo-500/10 px-2.5 py-1 text-xs font-mono text-indigo-300 border border-indigo-500/30">
            Current Brand: {selectedBrand}
          </span>
        </div>

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Controls */}
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Customer Current Device Age</span>
                <span className="font-mono text-cyan-400 font-bold text-sm">
                  {simulatedDeviceAge} Months
                </span>
              </div>
              <input
                type="range"
                min={2}
                max={36}
                value={simulatedDeviceAge}
                onChange={(e) => setSimulatedDeviceAge(Number(e.target.value))}
                className="mt-2 w-full accent-cyan-500 cursor-pointer"
                aria-label="Simulate device age"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                <span>0m (New Purchase)</span>
                <span>18-24m (Optimal Upgrade Window)</span>
                <span>36m (Lapsed)</span>
              </div>
            </div>

            {/* Visual Lifecycle Progress Bar */}
            <div className="rounded-xl border border-white/5 bg-slate-900/60 p-3">
              <div className="flex justify-between text-xs text-slate-400 mb-1.5">
                <span>Upgrade Readiness Indicator:</span>
                <span className="font-mono font-bold text-white">{simEvaluation.upgradeReadinessScore}%</span>
              </div>
              <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 ${
                    simEvaluation.upgradeReadinessScore >= 80
                      ? 'bg-gradient-to-r from-indigo-500 to-cyan-400'
                      : 'bg-slate-600'
                  }`}
                  style={{ width: `${simEvaluation.upgradeReadinessScore}%` }}
                ></div>
              </div>
            </div>
          </div>

          {/* Triggered Playbook Card */}
          <div className="rounded-2xl border border-cyan-500/30 bg-cyan-500/5 p-5 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-cyan-500/20">
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">
                Triggered Pricing &amp; Offer Output
              </span>
              <span className="rounded bg-cyan-500/20 px-2 py-0.5 text-xs font-bold text-cyan-300">
                {simEvaluation.lifecycleStatus}
              </span>
            </div>

            <div>
              <span className="text-[11px] text-slate-400 uppercase font-semibold">
                Dynamic Pricing Incentive:
              </span>
              <div className="mt-1 text-sm font-bold text-white leading-snug">
                {simEvaluation.dynamicPriceOffer}
              </div>
            </div>

            <div className="pt-2">
              <span className="text-[11px] text-slate-400 uppercase font-semibold">
                Automated Campaign Action:
              </span>
              <p className="mt-1 text-xs text-slate-300 leading-relaxed">
                {simEvaluation.campaignTrigger}
              </p>
            </div>

            <div className="pt-2">
              <button
                onClick={() => onTabChange('campaigns')}
                className="flex items-center gap-2 rounded-xl bg-cyan-600 px-4 py-2 text-xs font-bold text-white hover:bg-cyan-500 shadow-md shadow-cyan-600/30 transition-all"
              >
                <span>Automate This Campaign</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
