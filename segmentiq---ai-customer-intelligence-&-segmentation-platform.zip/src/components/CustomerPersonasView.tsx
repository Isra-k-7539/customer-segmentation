import React, { useState } from 'react';
import {
  Users,
  Crown,
  Sparkles,
  TrendingUp,
  Target,
  DollarSign,
  HeartHandshake,
  ShieldCheck,
  ChevronRight,
  ArrowRightLeft,
  CheckCircle2,
} from 'lucide-react';
import type { AppState, ActiveTab } from '../types/index.ts';

interface CustomerPersonasViewProps {
  state: AppState;
  onTabChange: (tab: ActiveTab) => void;
}

export const CustomerPersonasView: React.FC<CustomerPersonasViewProps> = ({
  state,
  onTabChange,
}) => {
  const [compareSegmentA, setCompareSegmentA] = useState<number>(0);
  const [compareSegmentB, setCompareSegmentB] = useState<number>(1);
  const [activePersonaTab, setActivePersonaTab] = useState<'cards' | 'comparison'>('cards');

  const clusters = state.clusters;
  const currencySymbol = state.currency === 'INR' ? '₹' : '$';
  const currencyRate = state.currency === 'INR' ? 1 : 0.012;

  // Persona emoji & badge icons based on label
  const getPersonaVisual = (label: string, index: number) => {
    const l = label.toLowerCase();
    if (l.includes('champion') || l.includes('vip')) {
      return { emoji: '👑', color: 'from-amber-500/20 to-yellow-500/10', border: 'border-amber-500/30', text: 'text-amber-400' };
    } else if (l.includes('loyal') || l.includes('affluent')) {
      return { emoji: '💎', color: 'from-cyan-500/20 to-blue-500/10', border: 'border-cyan-500/30', text: 'text-cyan-400' };
    } else if (l.includes('budget') || l.includes('price')) {
      return { emoji: '🎯', color: 'from-emerald-500/20 to-teal-500/10', border: 'border-emerald-500/30', text: 'text-emerald-400' };
    } else if (l.includes('risk') || l.includes('outlier')) {
      return { emoji: '⚠️', color: 'from-rose-500/20 to-orange-500/10', border: 'border-rose-500/30', text: 'text-rose-400' };
    }
    const fallbacks = [
      { emoji: '🚀', color: 'from-indigo-500/20 to-purple-500/10', border: 'border-indigo-500/30', text: 'text-indigo-400' },
      { emoji: '🌟', color: 'from-purple-500/20 to-pink-500/10', border: 'border-purple-500/30', text: 'text-purple-400' },
      { emoji: '💡', color: 'from-teal-500/20 to-emerald-500/10', border: 'border-teal-500/30', text: 'text-teal-400' },
      { emoji: '⚡', color: 'from-blue-500/20 to-cyan-500/10', border: 'border-blue-500/30', text: 'text-blue-400' },
    ];
    return fallbacks[index % fallbacks.length];
  };

  const getPersonaStrategies = (label: string, averages: number[]) => {
    const l = label.toLowerCase();
    if (l.includes('champion') || l.includes('vip')) {
      return {
        traits: ['High brand loyalty & frequent purchases', 'Low price sensitivity', 'Enthusiastic about flagship early access'],
        strategy: 'VIP concierge loyalty rewards, exclusive flagship launch invitations, and priority customer care.',
        offer: 'Early-access VIP pre-order pass & 1-year complimentary device accidental damage cover',
      };
    } else if (l.includes('affluent') || l.includes('loyal')) {
      return {
        traits: ['Substantial disposable income', 'Consistent repeat purchase intervals', 'High basket size'],
        strategy: 'Membership tiers, personalized product cross-sells, and premium accessory bundle incentives.',
        offer: 'Tiered anniversary gift box and 15% bonus store credit on luxury upgrades',
      };
    } else if (l.includes('budget') || l.includes('price')) {
      return {
        traits: ['Strong coupon sensitivity', 'Long deliberation period', 'Seeks maximum functional value'],
        strategy: 'Value-oriented promotional bundles, clearance sales, and zero-interest EMI financing.',
        offer: 'Clearance bundle discount with free delivery and extended 6-month installment plan',
      };
    } else {
      return {
        traits: ['Moderate spending', 'Occasional brand exploration', 'Responsive to seasonal events'],
        strategy: 'Educational onboarding sequences, dynamic flash discounts, and product comparison guides.',
        offer: '10% limited-time incentive voucher on trending electronics',
      };
    }
  };

  return (
    <div className="space-y-6 p-4 md:p-8 overflow-y-auto max-h-[calc(100vh-4rem)]">
      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
            Customer Personas &amp; Segment Dossiers
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Rich behavioral profiles generated dynamically from measured mathematical cluster statistics.
          </p>
        </div>

        {/* View Switcher: Persona Cards vs Segment Comparison */}
        <div className="flex rounded-lg border border-white/10 bg-slate-900/60 p-0.5 text-xs">
          <button
            onClick={() => setActivePersonaTab('cards')}
            className={`rounded-md px-3 py-1.5 transition-colors font-semibold ${
              activePersonaTab === 'cards'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Persona Dossiers ({clusters.length})
          </button>
          <button
            onClick={() => setActivePersonaTab('comparison')}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 transition-colors font-semibold ${
              activePersonaTab === 'comparison'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ArrowRightLeft className="h-3.5 w-3.5" />
            Side-by-Side Comparison
          </button>
        </div>
      </div>

      {activePersonaTab === 'cards' ? (
        /* Persona Cards Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {clusters.map((cluster, idx) => {
            const visual = getPersonaVisual(cluster.label, idx);
            const strat = getPersonaStrategies(cluster.label, cluster.featureAverages);
            const estRevenue = Math.round(cluster.memberCount * (cluster.featureAverages[1] ? cluster.featureAverages[1] * 700 : 30000));

            return (
              <div
                key={cluster.clusterId}
                className={`glass-panel rounded-2xl p-6 relative overflow-hidden transition-all hover:scale-[1.01] hover:shadow-2xl border ${visual.border}`}
              >
                {/* Background ambient gradient */}
                <div
                  className={`pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-gradient-to-br ${visual.color} blur-2xl opacity-60`}
                />

                {/* Header */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-900/80 text-2xl border border-white/10 shadow-inner">
                      {visual.emoji}
                    </div>
                    <div>
                      <div className="text-[10px] uppercase font-bold text-slate-400">
                        Segment {cluster.clusterId + 1}
                      </div>
                      <h3 className={`text-base font-bold ${visual.text} truncate max-w-[180px]`}>
                        {cluster.label}
                      </h3>
                    </div>
                  </div>

                  <span className="rounded-full bg-slate-900/80 px-2.5 py-1 text-xs font-mono font-bold text-white border border-white/10">
                    {cluster.percentage}% Base
                  </span>
                </div>

                {/* Metrics Matrix */}
                <div className="mt-5 grid grid-cols-2 gap-2 text-xs">
                  <div className="rounded-xl border border-white/5 bg-slate-900/60 p-2.5">
                    <span className="text-[10px] uppercase text-slate-400 font-semibold">Customers</span>
                    <div className="text-base font-bold text-white mt-0.5">{cluster.memberCount}</div>
                  </div>
                  <div className="rounded-xl border border-white/5 bg-slate-900/60 p-2.5">
                    <span className="text-[10px] uppercase text-slate-400 font-semibold">Est. Gross Spend</span>
                    <div className="text-base font-bold text-cyan-400 mt-0.5">
                      {currencySymbol}{Math.round(estRevenue * currencyRate).toLocaleString()}
                    </div>
                  </div>
                </div>

                {/* Measured Feature Centroids */}
                <div className="mt-3 rounded-xl border border-white/5 bg-slate-900/40 p-3">
                  <div className="text-[10px] uppercase font-bold text-slate-400 mb-2">
                    Cluster Feature Centroids
                  </div>
                  <div className="space-y-1.5">
                    {state.selectedFeatures.slice(0, 3).map((feat, fIdx) => (
                      <div key={feat} className="flex justify-between text-[11px]">
                        <span className="text-slate-400 truncate max-w-[150px]">{feat}</span>
                        <span className="font-mono text-white font-semibold">
                          {cluster.featureAverages[fIdx] ?? 'N/A'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Key Behavioral Traits */}
                <div className="mt-4">
                  <div className="text-[10px] uppercase font-bold text-slate-400 mb-1.5">
                    Key Behavioral Characteristics
                  </div>
                  <ul className="space-y-1 text-xs text-slate-300">
                    {strat.traits.map((t, i) => (
                      <li key={i} className="flex items-center gap-1.5">
                        <CheckCircle2 className="h-3 w-3 text-emerald-400 shrink-0" />
                        <span className="truncate">{t}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Recommended Marketing Strategy */}
                <div className="mt-5 border-t border-white/10 pt-4">
                  <div className="text-[10px] uppercase font-bold text-cyan-400 mb-1">
                    Recommended Business Strategy
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">{strat.strategy}</p>

                  <div className="mt-3 flex items-center justify-between">
                    <span className="text-[10px] text-amber-300 font-mono truncate max-w-[160px]">
                      {strat.offer}
                    </span>
                    <button
                      onClick={() => onTabChange('campaigns')}
                      className="flex items-center gap-1 text-[11px] font-bold text-cyan-400 hover:text-cyan-300"
                    >
                      Build Campaign &rarr;
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Side-by-Side Comparison Module */
        <div className="glass-panel rounded-2xl p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-white/10">
            <div>
              <h3 className="text-sm font-bold text-white">Segment Comparison Analysis</h3>
              <p className="text-[11px] text-slate-400">
                Compare behavioral attributes, revenue output, and marketing affinity across any two segments.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 text-xs text-slate-300">
                <span>Segment A:</span>
                <select
                  value={compareSegmentA}
                  onChange={(e) => setCompareSegmentA(Number(e.target.value))}
                  className="rounded-lg border border-white/10 bg-slate-900 px-2 py-1 text-xs text-indigo-300"
                  aria-label="Select segment A"
                >
                  {clusters.map((c, i) => (
                    <option key={i} value={i}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </div>

              <span className="text-slate-500 font-bold">vs</span>

              <div className="flex items-center gap-1.5 text-xs text-slate-300">
                <span>Segment B:</span>
                <select
                  value={compareSegmentB}
                  onChange={(e) => setCompareSegmentB(Number(e.target.value))}
                  className="rounded-lg border border-white/10 bg-slate-900 px-2 py-1 text-xs text-cyan-300"
                  aria-label="Select segment B"
                >
                  {clusters.map((c, i) => (
                    <option key={i} value={i}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Comparison Table */}
          {clusters[compareSegmentA] && clusters[compareSegmentB] && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Segment A Card */}
              <div className="rounded-2xl border border-indigo-500/30 bg-indigo-500/5 p-5">
                <div className="flex items-center justify-between pb-3 border-b border-indigo-500/20">
                  <h4 className="text-base font-bold text-indigo-300">
                    {clusters[compareSegmentA].label}
                  </h4>
                  <span className="rounded bg-indigo-500/20 px-2 py-0.5 text-xs font-mono text-indigo-300">
                    {clusters[compareSegmentA].memberCount} Customers ({clusters[compareSegmentA].percentage}%)
                  </span>
                </div>
                <div className="mt-4 space-y-3 text-xs">
                  <div className="flex justify-between py-1.5 border-b border-white/5">
                    <span className="text-slate-400">Customer Share</span>
                    <span className="font-bold text-white">{clusters[compareSegmentA].percentage}%</span>
                  </div>
                  {state.selectedFeatures.map((feat, fIdx) => (
                    <div key={feat} className="flex justify-between py-1.5 border-b border-white/5">
                      <span className="text-slate-400">{feat}</span>
                      <span className="font-mono text-cyan-300 font-semibold">
                        {clusters[compareSegmentA].featureAverages[fIdx] ?? 'N/A'}
                      </span>
                    </div>
                  ))}
                  <div className="pt-2 text-slate-300 text-[11px] leading-relaxed">
                    <strong>Tailored Engagement:</strong>{' '}
                    {getPersonaStrategies(clusters[compareSegmentA].label, clusters[compareSegmentA].featureAverages).strategy}
                  </div>
                </div>
              </div>

              {/* Segment B Card */}
              <div className="rounded-2xl border border-cyan-500/30 bg-cyan-500/5 p-5">
                <div className="flex items-center justify-between pb-3 border-b border-cyan-500/20">
                  <h4 className="text-base font-bold text-cyan-300">
                    {clusters[compareSegmentB].label}
                  </h4>
                  <span className="rounded bg-cyan-500/20 px-2 py-0.5 text-xs font-mono text-cyan-300">
                    {clusters[compareSegmentB].memberCount} Customers ({clusters[compareSegmentB].percentage}%)
                  </span>
                </div>
                <div className="mt-4 space-y-3 text-xs">
                  <div className="flex justify-between py-1.5 border-b border-white/5">
                    <span className="text-slate-400">Customer Share</span>
                    <span className="font-bold text-white">{clusters[compareSegmentB].percentage}%</span>
                  </div>
                  {state.selectedFeatures.map((feat, fIdx) => (
                    <div key={feat} className="flex justify-between py-1.5 border-b border-white/5">
                      <span className="text-slate-400">{feat}</span>
                      <span className="font-mono text-cyan-300 font-semibold">
                        {clusters[compareSegmentB].featureAverages[fIdx] ?? 'N/A'}
                      </span>
                    </div>
                  ))}
                  <div className="pt-2 text-slate-300 text-[11px] leading-relaxed">
                    <strong>Tailored Engagement:</strong>{' '}
                    {getPersonaStrategies(clusters[compareSegmentB].label, clusters[compareSegmentB].featureAverages).strategy}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
