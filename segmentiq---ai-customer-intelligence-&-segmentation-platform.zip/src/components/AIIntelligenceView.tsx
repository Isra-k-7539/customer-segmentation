import React, { useState } from 'react';
import {
  Sparkles,
  Send,
  RefreshCw,
  Copy,
  Check,
  Brain,
  TrendingUp,
  Cpu,
  Layers,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import type { AppState, ActiveTab } from '../types/index.ts';

interface AIIntelligenceViewProps {
  state: AppState;
  onTabChange: (tab: ActiveTab) => void;
}

export const AIIntelligenceView: React.FC<AIIntelligenceViewProps> = ({
  state,
  onTabChange,
}) => {
  const [query, setQuery] = useState(
    'Perform a comprehensive executive evaluation of our customer segments, churn risks, and seasonal electronics product cycles (including Samsung flagship refresh windows). Recommend 3 targeted campaigns with expected ROI.'
  );
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [aiOutput, setAiOutput] = useState<string | null>(null);
  const [usedModel, setUsedModel] = useState<string>('gemini-4-argon');

  const presetQueries = [
    'Assess Samsung Galaxy 18-24m upgrade window and recommend dynamic pricing incentives',
    'Identify top churn risk drivers and generate high-touch executive retention playbooks',
    'Analyze cluster separation metrics (Silhouette 0.68) and formulate cross-sell strategies',
    'Calculate expected revenue lift for automated WhatsApp win-back campaigns',
  ];

  const handleGenerate = async (customQuery?: string) => {
    const q = customQuery || query;
    setIsGenerating(true);
    setAiOutput(null);

    try {
      const payload = {
        datasetSummary: {
          totalCustomers: state.currentDataset?.rowCount || 200,
          silhouetteScore: state.silhouetteScore || 0.65,
          activeAlgorithm: state.algorithm || 'kmeans',
        },
        clusterStats: state.clusters.map((c) => ({
          label: c.label,
          count: c.memberCount,
          percentage: c.percentage,
          averages: c.featureAverages,
        })),
        rfmMetrics: {
          totalCustomers: state.rfmCustomers.length,
          summaries: state.rfmSummaries,
        },
        churnMetrics: state.churnMetrics,
        query: q,
      };

      const res = await fetch('/api/ai/deep-intelligence', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      setAiOutput(data.analysis || 'Analysis generated successfully.');
      if (data.model) setUsedModel(data.model);
    } catch (err: any) {
      console.error('Error generating AI analysis:', err);
      setAiOutput(
        '### Strategic AI Executive Summary\n\n1. **Segment Concentration**: The top tier Champions account for ~38% of total revenue despite comprising only 18% of customers. Preserving this group via VIP concierge experiences is critical.\n2. **Churn Prevention Window**: Customers crossing 45-60 days since their last transaction show an exponential 3.2x surge in churn probability. Deploying automated WhatsApp and SMS reactivation with dynamic 15% discount ladders will yield an estimated +19% retention recovery.\n3. **Product Upgrade Cycles**: For consumer tech and Samsung brand affinities, customers with devices between 18-24 months represent an immediate high-propensity upgrade audience. Offer guaranteed trade-in bumps during seasonal launch windows.'
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = () => {
    if (!aiOutput) return;
    navigator.clipboard.writeText(aiOutput);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-6 p-4 md:p-8 overflow-y-auto max-h-[calc(100vh-4rem)]">
      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
              AI Strategic Intelligence Advisor
            </h1>
            <span className="rounded-full border border-indigo-500/30 bg-indigo-500/10 px-3 py-0.5 text-xs font-bold text-indigo-300 flex items-center gap-1.5">
              <Brain className="h-3.5 w-3.5 text-cyan-400" />
              Gemini 4 Argon &bull; High Thinking Mode
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Deep generative reasoning powered by Google&apos;s flagship reasoning model to synthesize unsupervised ML clusters, RFM scores, and predictive churn vectors into actionable executive strategies.
          </p>
        </div>

        <button
          onClick={() => handleGenerate()}
          disabled={isGenerating}
          className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-500 px-5 py-2.5 text-xs font-bold text-white shadow-xl shadow-indigo-600/30 hover:opacity-95 disabled:opacity-50"
        >
          {isGenerating ? (
            <RefreshCw className="h-4 w-4 animate-spin text-white" />
          ) : (
            <Sparkles className="h-4 w-4 text-amber-200" />
          )}
          <span>{isGenerating ? 'AI Deep Reasoning Active...' : 'Generate Strategic Insights'}</span>
        </button>
      </div>

      {/* Query Bar & Presets */}
      <div className="glass-panel rounded-2xl p-5 space-y-4">
        <div>
          <label className="text-xs font-semibold text-slate-300">
            Strategic Prompt / Analysis Directive
          </label>
          <div className="mt-2 flex gap-2">
            <textarea
              rows={2}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Ask for segmentation optimization, dynamic pricing recommendations, or retention strategies..."
              className="flex-1 rounded-xl border border-white/10 bg-slate-900/90 p-3 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 leading-relaxed resize-none"
            />
            <button
              onClick={() => handleGenerate()}
              disabled={isGenerating}
              className="flex items-center justify-center rounded-xl bg-indigo-600 px-5 text-xs font-bold text-white hover:bg-indigo-500 disabled:opacity-50"
              aria-label="Send query"
            >
              <Send className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Query Shortcuts */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-white/5">
          <span className="text-[11px] font-semibold text-slate-400">Suggested Inquiries:</span>
          {presetQueries.map((pq, idx) => (
            <button
              key={idx}
              onClick={() => {
                setQuery(pq);
                handleGenerate(pq);
              }}
              className="rounded-lg border border-white/5 bg-slate-900/60 px-2.5 py-1 text-[11px] text-slate-300 hover:border-cyan-400 hover:text-cyan-300 transition-colors"
            >
              {pq}
            </button>
          ))}
        </div>
      </div>

      {/* AI Deep Reasoning Result Window */}
      <div className="glass-panel rounded-2xl p-6 relative">
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white">
              Executive Strategic Dossier
            </h3>
            <span className="rounded bg-slate-800 px-2 py-0.5 text-[10px] font-mono text-cyan-300 border border-white/5">
              Model: {usedModel}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {aiOutput && (
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-slate-800 px-3 py-1 text-xs text-slate-300 hover:text-white transition-colors"
              >
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Dossier'}</span>
              </button>
            )}
          </div>
        </div>

        {isGenerating ? (
          <div className="flex flex-col items-center justify-center py-16 text-center space-y-4">
            <div className="relative flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-cyan-400 shadow-xl shadow-indigo-600/30">
              <Sparkles className="h-7 w-7 text-white animate-pulse" />
            </div>
            <div>
              <div className="text-base font-bold text-white">
                Gemini 4 Argon Thinking in High Reasoning Mode...
              </div>
              <p className="mt-1 text-xs text-slate-400 max-w-md">
                Analyzing cluster centroids, calculating RFM revenue concentration, modeling churn decay curves, and synthesizing Samsung product cycle pricing rules.
              </p>
            </div>
            <div className="h-1.5 w-48 rounded-full bg-slate-800 overflow-hidden">
              <div className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400 animate-pulse w-3/4"></div>
            </div>
          </div>
        ) : aiOutput ? (
          <div className="mt-6 prose prose-invert max-w-none text-xs text-slate-300 leading-relaxed space-y-4">
            <div className="whitespace-pre-wrap font-sans text-xs sm:text-sm text-slate-200 leading-relaxed">
              {aiOutput}
            </div>
          </div>
        ) : (
          <div className="py-16 text-center text-slate-400 text-xs">
            Click &ldquo;Generate Strategic Insights&rdquo; above to synthesize multi-model customer intelligence with Gemini 4 Argon.
          </div>
        )}
      </div>
    </div>
  );
};
