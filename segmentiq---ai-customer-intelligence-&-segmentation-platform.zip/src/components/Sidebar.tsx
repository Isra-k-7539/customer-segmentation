import React from 'react';
import {
  LayoutDashboard,
  Database,
  Network,
  Users,
  BarChart3,
  Flame,
  Calendar,
  Send,
  SlidersHorizontal,
  Sparkles,
  FileText,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  Cpu,
} from 'lucide-react';
import type { ActiveTab } from '../types/index.ts';

interface SidebarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onTabChange,
  collapsed,
  onToggleCollapse,
}) => {
  const navItems: {
    id: ActiveTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    category: 'core' | 'ml' | 'strategy';
    badge?: string;
  }[] = [
    { id: 'dashboard', label: 'Dashboard Overview', icon: LayoutDashboard, category: 'core' },
    { id: 'data-management', label: 'Customer Datasets', icon: Database, category: 'core' },
    { id: 'segmentation', label: 'Clustering Engine', icon: Network, category: 'ml', badge: 'ML' },
    { id: 'personas', label: 'Customer Personas', icon: Users, category: 'ml' },
    { id: 'rfm', label: 'RFM Analytics', icon: BarChart3, category: 'ml' },
    { id: 'churn', label: 'Predictive Churn', icon: Flame, category: 'ml', badge: 'Risk' },
    { id: 'seasonal-trends', label: 'Product & Brand Cycles', icon: Calendar, category: 'strategy', badge: 'Samsung' },
    { id: 'campaigns', label: 'Marketing Automation', icon: Send, category: 'strategy' },
    { id: 'what-if', label: 'What-If Simulator', icon: SlidersHorizontal, category: 'strategy' },
    { id: 'ai-intelligence', label: 'AI Deep Advisor', icon: Sparkles, category: 'strategy', badge: 'Gemini 4' },
    { id: 'reports', label: 'Reports & Export', icon: FileText, category: 'core' },
  ];

  return (
    <aside
      className={`relative flex flex-col border-r border-white/10 bg-[#111827] transition-all duration-300 z-20 ${
        collapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Sidebar toggle button */}
      <button
        onClick={onToggleCollapse}
        className="absolute -right-3 top-20 flex h-6 w-6 items-center justify-center rounded-full border border-white/20 bg-slate-900 text-slate-300 shadow-md hover:bg-slate-800 hover:text-white"
        aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
      >
        {collapsed ? <ChevronRight className="h-3.5 w-3.5" /> : <ChevronLeft className="h-3.5 w-3.5" />}
      </button>

      {/* Navigation List */}
      <div className="flex-1 overflow-y-auto px-2 py-4 space-y-6">
        {/* Core Analytics */}
        <div>
          {!collapsed && (
            <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">
              Overview &amp; Data
            </div>
          )}
          <div className="space-y-1">
            {navItems
              .filter((item) => item.category === 'core')
              .map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onTabChange(item.id)}
                    className={`group flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-medium transition-all ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                        : 'text-slate-400 hover:bg-slate-800/80 hover:text-slate-200'
                    }`}
                    title={collapsed ? item.label : undefined}
                  >
                    <Icon className={`h-4 w-4 shrink-0 transition-colors ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-cyan-400'}`} />
                    {!collapsed && <span className="truncate">{item.label}</span>}
                  </button>
                );
              })}
          </div>
        </div>

        {/* Machine Learning Engine */}
        <div>
          {!collapsed && (
            <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-500 flex items-center justify-between">
              <span>Machine Learning</span>
              <Cpu className="h-3 w-3 text-indigo-400" />
            </div>
          )}
          <div className="space-y-1">
            {navItems
              .filter((item) => item.category === 'ml')
              .map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onTabChange(item.id)}
                    className={`group flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-xs font-medium transition-all ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                        : 'text-slate-400 hover:bg-slate-800/80 hover:text-slate-200'
                    }`}
                    title={collapsed ? item.label : undefined}
                  >
                    <div className="flex items-center gap-3 truncate">
                      <Icon className={`h-4 w-4 shrink-0 transition-colors ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-cyan-400'}`} />
                      {!collapsed && <span className="truncate">{item.label}</span>}
                    </div>
                    {!collapsed && item.badge && (
                      <span className="rounded bg-indigo-500/20 px-1.5 py-0.5 text-[9px] font-semibold text-indigo-300 border border-indigo-500/30">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
          </div>
        </div>

        {/* Strategy & Automation */}
        <div>
          {!collapsed && (
            <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-500 flex items-center justify-between">
              <span>Strategy &amp; AI</span>
              <TrendingUp className="h-3 w-3 text-cyan-400" />
            </div>
          )}
          <div className="space-y-1">
            {navItems
              .filter((item) => item.category === 'strategy')
              .map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onTabChange(item.id)}
                    className={`group flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-xs font-medium transition-all ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                        : 'text-slate-400 hover:bg-slate-800/80 hover:text-slate-200'
                    }`}
                    title={collapsed ? item.label : undefined}
                  >
                    <div className="flex items-center gap-3 truncate">
                      <Icon className={`h-4 w-4 shrink-0 transition-colors ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-cyan-400'}`} />
                      {!collapsed && <span className="truncate">{item.label}</span>}
                    </div>
                    {!collapsed && item.badge && (
                      <span className="rounded bg-cyan-500/20 px-1.5 py-0.5 text-[9px] font-semibold text-cyan-300 border border-cyan-500/30">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
          </div>
        </div>
      </div>

      {/* Footer info in sidebar */}
      {!collapsed && (
        <div className="p-3 border-t border-white/5 bg-slate-900/50">
          <div className="rounded-xl border border-white/5 bg-slate-900 p-2.5 text-left">
            <div className="flex items-center gap-2 text-[11px] font-semibold text-slate-300">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
              ML Engine Active
            </div>
            <p className="mt-1 text-[10px] text-slate-500 leading-tight">
              K-Means &bull; GMM &bull; RFM &bull; Churn Sigmoid &bull; Gemini 4
            </p>
          </div>
        </div>
      )}
    </aside>
  );
};
