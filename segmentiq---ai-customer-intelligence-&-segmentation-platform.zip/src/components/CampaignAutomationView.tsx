import React, { useState } from 'react';
import {
  Send,
  MessageSquare,
  Mail,
  Smartphone,
  Sparkles,
  CheckCircle2,
  TrendingUp,
  Clock,
  Play,
  Layers,
  Percent,
  DollarSign,
  Plus,
  X,
} from 'lucide-react';
import type { AppState, ActiveTab } from '../types/index.ts';

interface CampaignAutomationViewProps {
  state: AppState;
  onTabChange: (tab: ActiveTab) => void;
}

interface CampaignCard {
  id: string;
  name: string;
  targetSegment: string;
  channel: 'WhatsApp' | 'Email' | 'Push Notification' | 'SMS' | 'VIP Concierge';
  objective: string;
  offer: string;
  expectedLift: string;
  estimatedROI: string;
  autoTrigger: string;
  status: 'Active Automated' | 'Paused' | 'Draft';
}

export const CampaignAutomationView: React.FC<CampaignAutomationViewProps> = ({
  state,
  onTabChange,
}) => {
  const [campaigns, setCampaigns] = useState<CampaignCard[]>([
    {
      id: 'c1',
      name: 'Samsung Flagship 18m Upgrade Pass',
      targetSegment: 'Champions & Tech Adopters',
      channel: 'WhatsApp',
      objective: 'Convert customers crossing 18-month device lifecycle during seasonal launch',
      offer: 'Guaranteed ₹8,000 Trade-in Bump + Complimentary Galaxy Buds bundle',
      expectedLift: '+22.4% Upgrade Conversion',
      estimatedROI: '4.8x Return on Ad Spend',
      autoTrigger: 'Trigger when deviceAge >= 18 months & recency <= 45 days',
      status: 'Active Automated',
    },
    {
      id: 'c2',
      name: 'High-Value Inactivity Reactivation',
      targetSegment: 'At-Risk VIPs',
      channel: 'VIP Concierge',
      objective: 'Prevent critical churn among accounts with >₹50,000 historical spend',
      offer: 'Personalized 20% Revival Pass & dedicated priority phone support',
      expectedLift: '+18.7% Retention Recovery',
      estimatedROI: '6.2x LTV Preservation',
      autoTrigger: 'Trigger when churnRisk > 70% & daysInactive > 50 days',
      status: 'Active Automated',
    },
    {
      id: 'c3',
      name: 'Affluent Cross-Sell Acceleration',
      targetSegment: 'Loyal High-Earners',
      channel: 'Email',
      objective: 'Increase average basket size by introducing ecosystem accessories',
      offer: '15% accessory voucher on purchases above ₹15,000',
      expectedLift: '+14.1% Basket Size Growth',
      estimatedROI: '3.9x Campaign ROI',
      autoTrigger: 'Trigger 14 days after completed smartphone purchase',
      status: 'Active Automated',
    },
    {
      id: 'c4',
      name: 'Budget Shopper Flash Bundle',
      targetSegment: 'Budget / Price-Sensitive',
      channel: 'Push Notification',
      objective: 'Clearance inventory velocity and seasonal flash discounts',
      offer: 'Zero-cost 6-month installment EMI + Free Shipping',
      expectedLift: '+11.5% Order Frequency',
      estimatedROI: '2.8x Campaign ROI',
      autoTrigger: 'Trigger during weekend flash sale windows',
      status: 'Active Automated',
    },
  ]);

  const [notification, setNotification] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newSegment, setNewSegment] = useState(state.clusters[0]?.label || 'Champions');
  const [newChannel, setNewChannel] = useState<'WhatsApp' | 'Email' | 'Push Notification' | 'SMS' | 'VIP Concierge'>('WhatsApp');
  const [newOffer, setNewOffer] = useState('');

  const handleToggleStatus = (id: string) => {
    setCampaigns((prev) =>
      prev.map((c) =>
        c.id === id
          ? { ...c, status: c.status === 'Active Automated' ? 'Paused' : 'Active Automated' }
          : c
      )
    );
  };

  const handleCreateCampaign = () => {
    if (!newTitle.trim()) return;
    const created: CampaignCard = {
      id: `c_${Date.now()}`,
      name: newTitle,
      targetSegment: newSegment,
      channel: newChannel,
      objective: 'Targeted customer segment activation',
      offer: newOffer || 'Personalized 15% discount code',
      expectedLift: '+16.5% Conversion Lift',
      estimatedROI: '4.2x Projected ROI',
      autoTrigger: 'Automated trigger based on selected segment criteria',
      status: 'Active Automated',
    };
    setCampaigns([created, ...campaigns]);
    setShowCreateModal(false);
    setNewTitle('');
    setNewOffer('');
    setNotification(`Campaign "${newTitle}" created and activated!`);
    setTimeout(() => setNotification(null), 4000);
  };

  return (
    <div className="space-y-6 p-4 md:p-8 overflow-y-auto max-h-[calc(100vh-4rem)]">
      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
              Marketing Intelligence &amp; Campaign Automation
            </h1>
            <span className="rounded-full border border-indigo-500/30 bg-indigo-500/10 px-2.5 py-0.5 text-[10px] font-bold text-indigo-300">
              Multi-Channel Omnichannel Delivery
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Deploy hyper-personalized campaign playbooks triggered automatically by customer cluster traits, RFM status, and seasonal brand cycles.
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-500 px-4 py-2 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 hover:opacity-95"
        >
          <Plus className="h-4 w-4" />
          <span>Create New Campaign</span>
        </button>
      </div>

      {notification && (
        <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3 text-xs text-emerald-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
            <span>{notification}</span>
          </div>
          <button onClick={() => setNotification(null)} className="text-slate-400 hover:text-white">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {/* Campaigns Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {campaigns.map((camp) => (
          <div
            key={camp.id}
            className="glass-panel rounded-2xl p-6 border border-white/10 transition-all hover:border-indigo-500/40"
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/5">
              <div className="flex items-center gap-2">
                <span className="rounded-md bg-indigo-500/20 px-2 py-0.5 text-[10px] font-bold text-indigo-300 border border-indigo-500/30">
                  {camp.channel}
                </span>
                <span className="text-xs font-semibold text-cyan-300">
                  Target: {camp.targetSegment}
                </span>
              </div>
              <button
                onClick={() => handleToggleStatus(camp.id)}
                className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold transition-colors ${
                  camp.status === 'Active Automated'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-slate-800 text-slate-400 border border-white/10'
                }`}
              >
                {camp.status}
              </button>
            </div>

            <h3 className="mt-3 text-base font-bold text-white">{camp.name}</h3>
            <p className="mt-1 text-xs text-slate-400 leading-relaxed">{camp.objective}</p>

            <div className="mt-4 rounded-xl border border-white/5 bg-slate-900/60 p-3 space-y-2 text-xs">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400">Personalized Offer:</span>
                <div className="text-amber-300 font-semibold mt-0.5">{camp.offer}</div>
              </div>
              <div className="flex justify-between pt-1 border-t border-white/5">
                <span className="text-slate-400">Expected Lift:</span>
                <span className="text-emerald-400 font-bold">{camp.expectedLift}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Projected Return:</span>
                <span className="text-cyan-400 font-bold">{camp.estimatedROI}</span>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                <Clock className="h-3 w-3 text-slate-500" />
                <span className="truncate max-w-[200px]">{camp.autoTrigger}</span>
              </div>
              <button
                onClick={() => {
                  setNotification(`Simulated real-time dispatch for "${camp.name}" to ${camp.channel}!`);
                  setTimeout(() => setNotification(null), 4000);
                }}
                className="flex items-center gap-1 text-[11px] font-bold text-cyan-400 hover:text-cyan-300"
              >
                <Play className="h-3 w-3 fill-cyan-400" />
                Dispatch Test
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Modal: Create Campaign */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="glass-panel w-full max-w-lg rounded-2xl p-6 border border-white/15 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-sm font-bold text-white">Create Automated Campaign</h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-800 hover:text-white"
                aria-label="Close modal"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="text-slate-300 font-semibold">Campaign Name</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. VIP Concierge Festival Early-Bird"
                  className="mt-1 w-full rounded-xl border border-white/10 bg-slate-900 px-3 py-2 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold">Target Customer Segment</label>
                <select
                  value={newSegment}
                  onChange={(e) => setNewSegment(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-white/10 bg-slate-900 px-3 py-2 text-xs text-slate-200 outline-none"
                  aria-label="Target segment"
                >
                  {state.clusters.map((c) => (
                    <option key={c.clusterId} value={c.label}>
                      {c.label} ({c.memberCount} customers)
                    </option>
                  ))}
                  <option value="At-Risk Accounts">At-Risk Accounts (Churn Risk &gt;60%)</option>
                  <option value="Samsung 18m Owners">Samsung 18-24m Device Owners</option>
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-semibold">Delivery Channel</label>
                <select
                  value={newChannel}
                  onChange={(e) => setNewChannel(e.target.value as any)}
                  className="mt-1 w-full rounded-xl border border-white/10 bg-slate-900 px-3 py-2 text-xs text-slate-200 outline-none"
                  aria-label="Delivery channel"
                >
                  <option value="WhatsApp">WhatsApp Interactive Message</option>
                  <option value="Email">Personalized Email Drip</option>
                  <option value="Push Notification">In-App Smart Push Notification</option>
                  <option value="SMS">Direct SMS with Dynamic Link</option>
                  <option value="VIP Concierge">VIP Concierge / Direct Executive Phone Outreach</option>
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-semibold">Incentive / Promotional Offer</label>
                <input
                  type="text"
                  value={newOffer}
                  onChange={(e) => setNewOffer(e.target.value)}
                  placeholder="e.g. Free 1-Year Extended Warranty + ₹4,000 Upgrade Voucher"
                  className="mt-1 w-full rounded-xl border border-white/10 bg-slate-900 px-3 py-2 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-2">
              <button
                onClick={() => setShowCreateModal(false)}
                className="rounded-xl border border-white/10 bg-slate-800 px-4 py-2 text-xs font-semibold text-slate-300 hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateCampaign}
                className="rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-500 px-4 py-2 text-xs font-bold text-white shadow-md shadow-indigo-600/30"
              >
                Launch Automated Campaign
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
