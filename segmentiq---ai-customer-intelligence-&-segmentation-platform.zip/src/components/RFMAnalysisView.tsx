import React, { useState, useMemo } from 'react';
import {
  BarChart3,
  Calendar,
  Layers,
  Search,
  ArrowUpRight,
  Sparkles,
  Crown,
  AlertTriangle,
  Send,
  Download,
  Info,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
  PieChart,
  Pie,
} from 'recharts';
import type { AppState, ActiveTab } from '../types/index.ts';
import { SEGMENT_COLORS } from '../utils/rfmAnalysis.ts';

interface RFMAnalysisViewProps {
  state: AppState;
  onTabChange: (tab: ActiveTab) => void;
}

export const RFMAnalysisView: React.FC<RFMAnalysisViewProps> = ({
  state,
  onTabChange,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSegmentFilter, setSelectedSegmentFilter] = useState('all');
  const [hoveredCell, setHoveredCell] = useState<{ r: number; f: number } | null>(null);

  const currencySymbol = state.currency === 'INR' ? '₹' : '$';
  const currencyRate = state.currency === 'INR' ? 1 : 0.012;

  const customers = state.rfmCustomers || [];
  const summaries = state.rfmSummaries || [];

  // Filtered customer list
  const filteredCustomers = useMemo(() => {
    return customers.filter((c) => {
      const matchesSearch =
        String(c.customerId).toLowerCase().includes(searchTerm.toLowerCase()) ||
        (c.customerName && c.customerName.toLowerCase().includes(searchTerm.toLowerCase()));
      const matchesSegment =
        selectedSegmentFilter === 'all' || c.segment === selectedSegmentFilter;
      return matchesSearch && matchesSegment;
    });
  }, [customers, searchTerm, selectedSegmentFilter]);

  // RFM 5x5 Matrix (Recency 1-5 vs Frequency 1-5 cell counts)
  const rfmMatrix = useMemo(() => {
    const matrix: number[][] = Array.from({ length: 5 }, () => new Array(5).fill(0));
    customers.forEach((c) => {
      const rIdx = c.rScore - 1;
      const fIdx = c.fScore - 1;
      if (rIdx >= 0 && rIdx < 5 && fIdx >= 0 && fIdx < 5) {
        matrix[rIdx][fIdx]++;
      }
    });
    return matrix;
  }, [customers]);

  // Overall RFM Revenue chart
  const rfmRevenueChartData = summaries.map((s) => ({
    name: s.segment,
    revenue: Math.round(s.totalRevenue * currencyRate),
    count: s.customerCount,
    color: s.color || '#6366F1',
  }));

  return (
    <div className="space-y-6 p-4 md:p-8 overflow-y-auto max-h-[calc(100vh-4rem)]">
      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
              RFM Segmentation &amp; Lifecycle Matrix
            </h1>
            <span className="rounded-full border border-cyan-500/30 bg-cyan-500/10 px-2.5 py-0.5 text-[10px] font-bold text-cyan-300">
              Recency &bull; Frequency &bull; Monetary
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Quintile-based behavioral scoring to pinpoint high-velocity Champions, decaying loyalty, and churn-risk accounts.
          </p>
        </div>

        <button
          onClick={() => onTabChange('campaigns')}
          className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-500 px-4 py-2 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 hover:opacity-95"
        >
          <Send className="h-3.5 w-3.5" />
          <span>Launch RFM Campaigns</span>
        </button>
      </div>

      {/* RFM KPI Metrics */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div className="glass-panel rounded-2xl p-4">
          <span className="text-[10px] uppercase font-bold text-slate-400">Champions &amp; Loyalists</span>
          <div className="text-2xl font-black text-indigo-400 mt-1">
            {customers.filter((c) => c.segment === 'Champions' || c.segment === 'Loyal Customers').length}
          </div>
          <span className="text-[10px] text-emerald-400 font-medium">Highest Lifetime Value</span>
        </div>

        <div className="glass-panel rounded-2xl p-4">
          <span className="text-[10px] uppercase font-bold text-slate-400">At-Risk Accounts</span>
          <div className="text-2xl font-black text-rose-400 mt-1">
            {customers.filter((c) => c.segment === 'At-Risk Customers' || c.segment === "Can't Lose Them").length}
          </div>
          <span className="text-[10px] text-rose-400 font-medium">Recency decay detected</span>
        </div>

        <div className="glass-panel rounded-2xl p-4">
          <span className="text-[10px] uppercase font-bold text-slate-400">Avg Recency Days</span>
          <div className="text-2xl font-black text-white mt-1">
            {customers.length > 0 ? Math.round(customers.reduce((s, c) => s + c.recencyDays, 0) / customers.length) : 45}d
          </div>
          <span className="text-[10px] text-slate-400">Days since last order</span>
        </div>

        <div className="glass-panel rounded-2xl p-4">
          <span className="text-[10px] uppercase font-bold text-slate-400">Avg Order Frequency</span>
          <div className="text-2xl font-black text-cyan-400 mt-1">
            {customers.length > 0 ? (customers.reduce((s, c) => s + c.orderFrequency, 0) / customers.length).toFixed(1) : 4.2}
          </div>
          <span className="text-[10px] text-slate-400">Transactions per customer</span>
        </div>
      </div>

      {/* RFM 5x5 Grid Heatmap & Segment Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* RFM 5x5 Heatmap Matrix */}
        <div className="glass-panel rounded-2xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-white/5">
            <div>
              <h3 className="text-sm font-bold text-white">RFM 5x5 Grid Matrix</h3>
              <p className="text-[11px] text-slate-400">
                Recency Score (Y-axis, 5=Most Recent) vs Frequency Score (X-axis, 5=Highest Orders)
              </p>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">Heatmap Distribution</span>
          </div>

          <div className="mt-4 flex flex-col items-center">
            {/* Grid Container */}
            <div className="w-full max-w-md">
              <div className="text-center text-[10px] uppercase font-bold text-cyan-400 mb-1">
                Frequency Score &rarr; (1 Low to 5 High)
              </div>
              <div className="space-y-1.5">
                {[5, 4, 3, 2, 1].map((rScore) => (
                  <div key={rScore} className="flex items-center gap-1.5">
                    <span className="w-6 text-right font-mono text-xs font-bold text-indigo-400">
                      R{rScore}
                    </span>
                    <div className="grid grid-cols-5 gap-1.5 flex-1">
                      {[1, 2, 3, 4, 5].map((fScore) => {
                        const count = rfmMatrix[rScore - 1][fScore - 1];
                        const isChampion = rScore >= 4 && fScore >= 4;
                        const isAtRisk = rScore <= 2 && fScore >= 3;
                        const isLost = rScore <= 2 && fScore <= 2;

                        let bgClass = 'bg-slate-900 border-white/5 text-slate-400';
                        if (isChampion) bgClass = 'bg-indigo-600/30 border-indigo-500/50 text-indigo-200 font-bold';
                        else if (isAtRisk) bgClass = 'bg-rose-500/30 border-rose-500/50 text-rose-200 font-bold';
                        else if (isLost) bgClass = 'bg-slate-800/80 border-slate-700 text-slate-400';
                        else if (count > 0) bgClass = 'bg-cyan-500/20 border-cyan-500/40 text-cyan-200 font-semibold';

                        return (
                          <div
                            key={fScore}
                            onMouseEnter={() => setHoveredCell({ r: rScore, f: fScore })}
                            onMouseLeave={() => setHoveredCell(null)}
                            className={`flex h-10 items-center justify-center rounded-lg border text-xs transition-all hover:scale-105 cursor-pointer ${bgClass}`}
                          >
                            {count}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>

              {/* Legend */}
              <div className="mt-4 flex flex-wrap items-center justify-center gap-3 text-[10px]">
                <div className="flex items-center gap-1.5">
                  <div className="h-3 w-3 rounded bg-indigo-600/40 border border-indigo-500"></div>
                  <span className="text-indigo-300">Champions (High R, High F)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="h-3 w-3 rounded bg-rose-500/40 border border-rose-500"></div>
                  <span className="text-rose-300">At-Risk (Low R, High F)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="h-3 w-3 rounded bg-cyan-500/30 border border-cyan-500"></div>
                  <span className="text-cyan-300">Active Mid-Tier</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Revenue by RFM Segment Bar Chart */}
        <div className="glass-panel rounded-2xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-white/5">
            <div>
              <h3 className="text-sm font-bold text-white">Revenue Contribution by RFM Segment</h3>
              <p className="text-[11px] text-slate-400">Total gross monetary value ({currencySymbol})</p>
            </div>
          </div>

          <div className="h-64 w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={rfmRevenueChartData} margin={{ top: 10, right: 10, left: 10, bottom: 25 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" vertical={false} />
                <XAxis dataKey="name" stroke="#94A3B8" fontSize={9} tickLine={false} interval={0} angle={-15} textAnchor="end" />
                <YAxis stroke="#94A3B8" fontSize={10} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#111827', borderColor: '#374151', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(val: any) => [`${currencySymbol}${Number(val).toLocaleString()}`, 'Revenue']}
                />
                <Bar dataKey="revenue" radius={[6, 6, 0, 0]}>
                  {rfmRevenueChartData.map((entry, index) => (
                    <Cell key={`rfm-bar-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Customer RFM Table */}
      <div className="glass-panel rounded-2xl p-5">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-white/10">
          <div>
            <h3 className="text-sm font-bold text-white">Individual Customer RFM Scores</h3>
            <p className="text-[11px] text-slate-400">
              Scored on 1-5 scale across Recency, Frequency, and Monetary dimensions
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* Filter by segment */}
            <select
              value={selectedSegmentFilter}
              onChange={(e) => setSelectedSegmentFilter(e.target.value)}
              className="rounded-lg border border-white/10 bg-slate-900 px-2.5 py-1.5 text-xs text-slate-200"
              aria-label="Filter RFM segment"
            >
              <option value="all">All RFM Segments</option>
              {summaries.map((s) => (
                <option key={s.segment} value={s.segment}>
                  {s.segment} ({s.customerCount})
                </option>
              ))}
            </select>

            {/* Search */}
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search customer ID or name..."
                className="rounded-lg border border-white/10 bg-slate-900 pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 outline-none w-48 sm:w-56"
              />
            </div>
          </div>
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 font-semibold">
                <th className="py-2.5 px-3">Customer</th>
                <th className="py-2.5 px-3">Recency (Days)</th>
                <th className="py-2.5 px-3">Frequency</th>
                <th className="py-2.5 px-3">Monetary</th>
                <th className="py-2.5 px-3">RFM Score</th>
                <th className="py-2.5 px-3">Assigned Segment</th>
                <th className="py-2.5 px-3 text-right">Recommended Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-300">
              {filteredCustomers.slice(0, 20).map((cust) => {
                const color = SEGMENT_COLORS[cust.segment] || '#6366F1';
                return (
                  <tr key={cust.customerId} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-3">
                      <div className="font-semibold text-white">{cust.customerName || cust.customerId}</div>
                      <div className="text-[10px] text-slate-500">{cust.customerId}</div>
                    </td>
                    <td className="py-2.5 px-3 font-mono">{cust.recencyDays} days</td>
                    <td className="py-2.5 px-3 font-mono">{cust.orderFrequency} orders</td>
                    <td className="py-2.5 px-3 font-mono">
                      {currencySymbol}{Math.round(cust.totalMonetary * currencyRate).toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="rounded bg-slate-800 px-2 py-0.5 font-mono text-cyan-300 font-bold border border-white/5">
                        {cust.rfmScore}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span
                        className="rounded-full px-2 py-0.5 text-[10px] font-semibold border"
                        style={{
                          backgroundColor: `${color}15`,
                          color,
                          borderColor: `${color}30`,
                        }}
                      >
                        {cust.segment}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right text-[11px] text-slate-400 truncate max-w-[220px]">
                      {cust.suggestedAction}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
