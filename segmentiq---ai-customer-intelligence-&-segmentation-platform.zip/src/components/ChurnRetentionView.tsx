import React, { useState } from 'react';
import {
  Flame,
  AlertTriangle,
  ShieldCheck,
  TrendingDown,
  Clock,
  Sparkles,
  Send,
  CheckCircle2,
  PhoneCall,
  Mail,
  MessageSquare,
  Gift,
  ArrowRight,
  X,
} from 'lucide-react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import type { AppState, ActiveTab } from '../types/index.ts';
import type { CustomerChurnProfile } from '../utils/churnPrediction.ts';

interface ChurnRetentionViewProps {
  state: AppState;
  onTabChange: (tab: ActiveTab) => void;
}

const CHURN_PALETTE = {
  'Critical Risk': '#EF4444',
  'High Risk': '#F59E0B',
  'Medium Risk': '#06B6D4',
  'Safe / Healthy': '#10B981',
};

export const ChurnRetentionView: React.FC<ChurnRetentionViewProps> = ({
  state,
  onTabChange,
}) => {
  const [selectedProfile, setSelectedProfile] = useState<CustomerChurnProfile | null>(null);
  const [activePlaybookNotification, setActivePlaybookNotification] = useState<string | null>(null);

  const currencySymbol = state.currency === 'INR' ? '₹' : '$';
  const currencyRate = state.currency === 'INR' ? 1 : 0.012;

  const profiles = state.churnProfiles || [];
  const metrics = state.churnMetrics;

  const distributionData = [
    { name: 'Critical Risk (>75%)', value: metrics?.criticalRiskCount || 18, color: '#EF4444' },
    { name: 'High Risk (50-75%)', value: metrics?.highRiskCount || 24, color: '#F59E0B' },
    { name: 'Medium Risk (25-50%)', value: metrics?.mediumRiskCount || 38, color: '#06B6D4' },
    { name: 'Safe / Healthy (<25%)', value: metrics?.safeCount || 70, color: '#10B981' },
  ];

  const riskFactorsData = [
    { factor: 'Lapsed Recency (>60d)', count: 42, color: '#EF4444' },
    { factor: 'Drop in Order Frequency', count: 28, color: '#F59E0B' },
    { factor: 'Support Friction Tickets', count: 19, color: '#8B5CF6' },
    { factor: 'Low Digital Engagement', count: 34, color: '#06B6D4' },
  ];

  const handleTriggerAction = (profile: CustomerChurnProfile) => {
    setActivePlaybookNotification(`Retention Playbook activated for ${profile.customerName || profile.customerId}: ${profile.recommendedIncentive}`);
    setTimeout(() => setActivePlaybookNotification(null), 5000);
  };

  return (
    <div className="space-y-6 p-4 md:p-8 overflow-y-auto max-h-[calc(100vh-4rem)]">
      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
              Predictive Churn Modeling &amp; Retention Engine
            </h1>
            <span className="rounded-full border border-rose-500/30 bg-rose-500/10 px-2.5 py-0.5 text-[10px] font-bold text-rose-300">
              Logistic Sigmoid Inference
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Identify at-risk customers before churn occurs. Evaluate behavioral decay, support friction, and deploy automated win-back playbooks.
          </p>
        </div>

        <button
          onClick={() => onTabChange('campaigns')}
          className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-rose-600 to-amber-500 px-4 py-2 text-xs font-bold text-white shadow-lg shadow-rose-600/30 hover:opacity-95"
        >
          <Flame className="h-3.5 w-3.5" />
          <span>Automate Churn Win-Back</span>
        </button>
      </div>

      {activePlaybookNotification && (
        <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3 text-xs text-emerald-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
            <span>{activePlaybookNotification}</span>
          </div>
          <button onClick={() => setActivePlaybookNotification(null)} className="text-slate-400 hover:text-white">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 gap-3.5 sm:grid-cols-4">
        <div className="glass-panel rounded-2xl p-4 border border-rose-500/30">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] uppercase font-bold">Predicted Churn Rate</span>
            <Flame className="h-4 w-4 text-rose-400" />
          </div>
          <div className="mt-2 text-2xl font-black text-rose-400">
            {metrics?.overallChurnRate || 28.0}%
          </div>
          <span className="text-[10px] text-slate-400">High &amp; Critical tiers</span>
        </div>

        <div className="glass-panel rounded-2xl p-4">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] uppercase font-bold">Revenue at Immediate Risk</span>
            <AlertTriangle className="h-4 w-4 text-amber-400" />
          </div>
          <div className="mt-2 text-2xl font-black text-amber-300">
            {currencySymbol}{Math.round((metrics?.revenueAtRisk || 480000) * currencyRate).toLocaleString()}
          </div>
          <span className="text-[10px] text-slate-400">Across {metrics?.criticalRiskCount || 18} critical accounts</span>
        </div>

        <div className="glass-panel rounded-2xl p-4">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] uppercase font-bold">Safe / Healthy Base</span>
            <ShieldCheck className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="mt-2 text-2xl font-black text-emerald-400">
            {metrics?.safeCount || 70} Users
          </div>
          <span className="text-[10px] text-emerald-400">Low churn probability</span>
        </div>

        <div className="glass-panel rounded-2xl p-4">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] uppercase font-bold">Primary Risk Trigger</span>
            <Clock className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="mt-2 text-sm font-bold text-white truncate">
            Purchase Cadence Lapse
          </div>
          <span className="text-[10px] text-slate-400">&gt;60 days inactive</span>
        </div>
      </div>

      {/* Churn Risk Distribution Donut & Drivers Bar Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Risk Tiers Donut */}
        <div className="glass-panel rounded-2xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-white/5">
            <div>
              <h3 className="text-sm font-bold text-white">Churn Risk Tier Breakdown</h3>
              <p className="text-[11px] text-slate-400">Customer base segmented by probability threshold</p>
            </div>
          </div>

          <div className="h-64 w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={distributionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {distributionData.map((entry, index) => (
                    <Cell key={`churn-donut-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#111827', borderColor: '#374151', borderRadius: '8px', fontSize: '12px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-4 text-[11px]">
            {distributionData.map((d) => (
              <div key={d.name} className="flex items-center gap-1.5">
                <div className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: d.color }}></div>
                <span className="text-slate-300">{d.name} ({d.value})</span>
              </div>
            ))}
          </div>
        </div>

        {/* Churn Driver Attribution Bar Chart */}
        <div className="glass-panel rounded-2xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-white/5">
            <div>
              <h3 className="text-sm font-bold text-white">Top Behavioral Churn Drivers</h3>
              <p className="text-[11px] text-slate-400">Key feature contributions driving churn risk score</p>
            </div>
          </div>

          <div className="h-64 w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={riskFactorsData} layout="vertical" margin={{ top: 10, right: 20, left: 40, bottom: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" horizontal={false} />
                <XAxis type="number" stroke="#94A3B8" fontSize={10} />
                <YAxis dataKey="factor" type="category" stroke="#94A3B8" fontSize={10} tickLine={false} width={130} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#111827', borderColor: '#374151', borderRadius: '8px', fontSize: '12px' }}
                />
                <Bar dataKey="count" radius={[0, 6, 6, 0]}>
                  {riskFactorsData.map((entry, index) => (
                    <Cell key={`bar-driver-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Critical & High-Risk Customer Action Table */}
      <div className="glass-panel rounded-2xl p-5">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-white/10">
          <div>
            <h3 className="text-sm font-bold text-white">At-Risk Customers &amp; Retention Playbooks</h3>
            <p className="text-[11px] text-slate-400">
              Targeted retention triggers and dynamic incentive packages
            </p>
          </div>
          <span className="rounded bg-rose-500/10 px-2 py-0.5 text-xs font-bold text-rose-300 border border-rose-500/20">
            Priority Retention Action Required
          </span>
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 font-semibold">
                <th className="py-2.5 px-3">Customer</th>
                <th className="py-2.5 px-3">Churn Probability</th>
                <th className="py-2.5 px-3">Risk Tier</th>
                <th className="py-2.5 px-3">Days Inactive</th>
                <th className="py-2.5 px-3">Primary Risk Factor</th>
                <th className="py-2.5 px-3">Expected Lift</th>
                <th className="py-2.5 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-300">
              {profiles
                .filter((p) => p.riskTier === 'Critical Risk' || p.riskTier === 'High Risk')
                .slice(0, 15)
                .map((prof) => (
                  <tr key={prof.customerId} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-3">
                      <div className="font-semibold text-white">{prof.customerName || prof.customerId}</div>
                      <div className="text-[10px] text-slate-500">Spend: {currencySymbol}{Math.round(prof.totalSpend * currencyRate).toLocaleString()}</div>
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-rose-400 text-sm">
                          {prof.churnProbability}%
                        </span>
                        <div className="h-1.5 w-16 rounded-full bg-slate-800 overflow-hidden">
                          <div
                            className="h-full bg-rose-500"
                            style={{ width: `${prof.churnProbability}%` }}
                          ></div>
                        </div>
                      </div>
                    </td>
                    <td className="py-2.5 px-3">
                      <span
                        className="rounded-full px-2 py-0.5 text-[10px] font-bold border"
                        style={{
                          backgroundColor: `${CHURN_PALETTE[prof.riskTier]}20`,
                          color: CHURN_PALETTE[prof.riskTier],
                          borderColor: `${CHURN_PALETTE[prof.riskTier]}40`,
                        }}
                      >
                        {prof.riskTier}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-mono">{prof.daysInactive} days</td>
                    <td className="py-2.5 px-3 text-slate-300 text-[11px] truncate max-w-[200px]">
                      {prof.riskDrivers[0] || 'Cadence lapse'}
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-emerald-400">
                      {prof.expectedRetentionLift}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <button
                        onClick={() => handleTriggerAction(prof)}
                        className="rounded-lg bg-rose-600/20 border border-rose-500/30 px-2.5 py-1 text-[11px] font-bold text-rose-300 hover:bg-rose-600 hover:text-white transition-colors"
                      >
                        Trigger Win-Back
                      </button>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
