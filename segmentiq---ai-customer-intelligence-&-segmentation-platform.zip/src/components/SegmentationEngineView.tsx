import React, { useState } from 'react';
import {
  Network,
  Cpu,
  Layers,
  Sparkles,
  Sliders,
  CheckCircle,
  Play,
  Activity,
  BarChart2,
  Info,
  RefreshCw,
} from 'lucide-react';
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ZAxis,
  Tooltip,
  CartesianGrid,
  Cell,
  LineChart,
  Line,
  Legend,
} from 'recharts';
import type { AppState, ActiveTab } from '../types/index.ts';

interface SegmentationEngineViewProps {
  state: AppState;
  onTabChange: (tab: ActiveTab) => void;
  onRunClustering: (params: {
    algorithm: 'kmeans' | 'hierarchical' | 'dbscan' | 'gmm';
    features: string[];
    k: number;
    maxIterations: number;
    linkage: string;
    eps: number;
    minSamples: number;
  }) => void;
}

const PALETTE = ['#6366F1', '#06B6D4', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'];

export const SegmentationEngineView: React.FC<SegmentationEngineViewProps> = ({
  state,
  onTabChange,
  onRunClustering,
}) => {
  const [selectedAlgo, setSelectedAlgo] = useState<'kmeans' | 'hierarchical' | 'dbscan' | 'gmm'>(
    state.algorithm || 'kmeans'
  );
  const [kClusters, setKClusters] = useState<number>(state.kClusters || 4);
  const [maxIterations, setMaxIterations] = useState<number>(100);
  const [linkage, setLinkage] = useState<'average' | 'complete' | 'single'>('average');
  const [eps, setEps] = useState<number>(0.8);
  const [minSamples, setMinSamples] = useState<number>(4);

  // Available features from dataset
  const availableFeatures = state.currentDataset?.suggestedClusteringFeatures || [
    'Annual Income (k$)',
    'Spending Score (1-100)',
    'Age',
  ];

  const [activeFeatures, setActiveFeatures] = useState<string[]>(
    state.selectedFeatures.length >= 2
      ? state.selectedFeatures
      : availableFeatures.slice(0, 3)
  );

  const toggleFeature = (feat: string) => {
    if (activeFeatures.includes(feat)) {
      if (activeFeatures.length <= 2) return; // keep at least 2
      setActiveFeatures(activeFeatures.filter((f) => f !== feat));
    } else {
      setActiveFeatures([...activeFeatures, feat]);
    }
  };

  const handleExecute = () => {
    onRunClustering({
      algorithm: selectedAlgo,
      features: activeFeatures,
      k: kClusters,
      maxIterations,
      linkage,
      eps,
      minSamples,
    });
  };

  // PCA 2D Scatter points
  const pcaPoints = (state.pcaCoordinates || []).map((pt, idx) => ({
    x: pt.x,
    y: pt.y,
    id: pt.id || `Pt-${idx}`,
    cluster: pt.cluster,
    color: PALETTE[Math.abs(pt.cluster) % PALETTE.length] || '#6366F1',
    info: pt.metadata?.CustomerName || pt.id,
  }));

  return (
    <div className="space-y-6 p-4 md:p-8 overflow-y-auto max-h-[calc(100vh-4rem)]">
      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
              Machine Learning Segmentation Engine
            </h1>
            <span className="rounded-full border border-indigo-500/30 bg-indigo-500/10 px-2.5 py-0.5 text-[10px] font-bold text-indigo-300">
              Scikit-Learn Architecture
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Unsupervised clustering algorithms with real-time PCA dimensionality reduction and mathematical cluster validation.
          </p>
        </div>

        <button
          onClick={handleExecute}
          disabled={state.isLoading}
          className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-500 px-5 py-2.5 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 hover:opacity-95 transition-all"
        >
          {state.isLoading ? (
            <RefreshCw className="h-4 w-4 animate-spin text-white" />
          ) : (
            <Play className="h-4 w-4 fill-white text-white" />
          )}
          <span>Execute Model Training</span>
        </button>
      </div>

      {/* Model Parameter Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Algorithm Selection & Hyperparameters */}
        <div className="glass-panel rounded-2xl p-5 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-white/10">
            <Sliders className="h-4 w-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white">Algorithm &amp; Hyperparameters</h3>
          </div>

          {/* Algorithm Tabs */}
          <div>
            <label className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              Select Algorithm
            </label>
            <div className="mt-2 grid grid-cols-2 gap-2 text-xs">
              {[
                { id: 'kmeans', label: 'K-Means' },
                { id: 'hierarchical', label: 'Hierarchical' },
                { id: 'dbscan', label: 'DBSCAN' },
                { id: 'gmm', label: 'Gaussian Mixture' },
              ].map((algo) => (
                <button
                  key={algo.id}
                  onClick={() => setSelectedAlgo(algo.id as any)}
                  className={`rounded-xl border px-3 py-2 text-left font-semibold transition-all ${
                    selectedAlgo === algo.id
                      ? 'border-indigo-500 bg-indigo-600/20 text-white shadow-sm'
                      : 'border-white/5 bg-slate-900/60 text-slate-400 hover:border-white/15 hover:text-slate-200'
                  }`}
                >
                  {algo.label}
                </button>
              ))}
            </div>
          </div>

          {/* Algorithm-specific parameter sliders */}
          {selectedAlgo === 'kmeans' && (
            <div className="space-y-3 pt-2">
              <div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-medium">Number of Clusters (k)</span>
                  <span className="font-mono text-cyan-400 font-bold">{kClusters}</span>
                </div>
                <input
                  type="range"
                  min={2}
                  max={8}
                  value={kClusters}
                  onChange={(e) => setKClusters(Number(e.target.value))}
                  className="mt-2 w-full accent-indigo-500 cursor-pointer"
                  aria-label="Number of clusters"
                />
              </div>
              <div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-medium">Max Iterations</span>
                  <span className="font-mono text-slate-400">{maxIterations}</span>
                </div>
                <input
                  type="range"
                  min={20}
                  max={300}
                  step={20}
                  value={maxIterations}
                  onChange={(e) => setMaxIterations(Number(e.target.value))}
                  className="mt-2 w-full accent-cyan-500 cursor-pointer"
                  aria-label="Max iterations"
                />
              </div>
              <div className="text-[10px] text-slate-400 bg-slate-900/80 p-2 rounded-lg border border-white/5">
                Uses <strong>K-Means++</strong> initialization with Euclidean distance convergence.
              </div>
            </div>
          )}

          {selectedAlgo === 'hierarchical' && (
            <div className="space-y-3 pt-2">
              <div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-medium">Clusters (k)</span>
                  <span className="font-mono text-cyan-400 font-bold">{kClusters}</span>
                </div>
                <input
                  type="range"
                  min={2}
                  max={8}
                  value={kClusters}
                  onChange={(e) => setKClusters(Number(e.target.value))}
                  className="mt-2 w-full accent-indigo-500 cursor-pointer"
                  aria-label="Hierarchical clusters"
                />
              </div>
              <div>
                <label className="text-xs text-slate-300 font-medium">Linkage Criterion</label>
                <select
                  value={linkage}
                  onChange={(e) => setLinkage(e.target.value as any)}
                  className="mt-1 w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2 text-xs text-slate-200 outline-none"
                  aria-label="Linkage criterion"
                >
                  <option value="average">Average Linkage (Balanced clusters)</option>
                  <option value="complete">Complete Linkage (Compact spheres)</option>
                  <option value="single">Single Linkage (Chaining)</option>
                </select>
              </div>
            </div>
          )}

          {selectedAlgo === 'dbscan' && (
            <div className="space-y-3 pt-2">
              <div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-medium">Epsilon Distance (&epsilon;)</span>
                  <span className="font-mono text-cyan-400 font-bold">{eps}</span>
                </div>
                <input
                  type="range"
                  min={0.3}
                  max={2.0}
                  step={0.1}
                  value={eps}
                  onChange={(e) => setEps(Number(e.target.value))}
                  className="mt-2 w-full accent-indigo-500 cursor-pointer"
                  aria-label="DBSCAN epsilon"
                />
              </div>
              <div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-medium">Min Samples</span>
                  <span className="font-mono text-slate-400">{minSamples}</span>
                </div>
                <input
                  type="range"
                  min={2}
                  max={10}
                  value={minSamples}
                  onChange={(e) => setMinSamples(Number(e.target.value))}
                  className="mt-2 w-full accent-cyan-500 cursor-pointer"
                  aria-label="DBSCAN min samples"
                />
              </div>
              <div className="text-[10px] text-amber-300 bg-amber-500/10 p-2 rounded-lg border border-amber-500/20">
                Detects arbitrary shapes and classifies noise/outlier points automatically.
              </div>
            </div>
          )}

          {selectedAlgo === 'gmm' && (
            <div className="space-y-3 pt-2">
              <div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-medium">Mixture Components</span>
                  <span className="font-mono text-cyan-400 font-bold">{kClusters}</span>
                </div>
                <input
                  type="range"
                  min={2}
                  max={8}
                  value={kClusters}
                  onChange={(e) => setKClusters(Number(e.target.value))}
                  className="mt-2 w-full accent-indigo-500 cursor-pointer"
                  aria-label="GMM components"
                />
              </div>
              <div className="text-[10px] text-slate-400 bg-slate-900/80 p-2 rounded-lg border border-white/5">
                Expectation-Maximization (EM) soft clustering with probabilistic membership.
              </div>
            </div>
          )}

          {/* Feature Selector */}
          <div className="pt-2 border-t border-white/10">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              Numerical Features to Standardize
            </label>
            <div className="mt-2 flex flex-wrap gap-2">
              {availableFeatures.map((feat) => {
                const isSelected = activeFeatures.includes(feat);
                return (
                  <button
                    key={feat}
                    onClick={() => toggleFeature(feat)}
                    className={`rounded-lg px-2.5 py-1 text-xs font-medium transition-colors ${
                      isSelected
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                        : 'bg-slate-900 border border-white/10 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {feat}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right 2 Columns: PCA Scatter Projection & Metric Scorecards */}
        <div className="lg:col-span-2 space-y-6">
          {/* PCA 2D Visualization */}
          <div className="glass-panel rounded-2xl p-5">
            <div className="flex items-center justify-between pb-3 border-b border-white/5">
              <div>
                <h3 className="text-sm font-bold text-white">Principal Component Analysis (PCA 2D Projection)</h3>
                <p className="text-[11px] text-slate-400">
                  Dimensionality reduction of {activeFeatures.length} standardized features into dominant variance components
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="rounded bg-indigo-500/10 px-2 py-0.5 text-[10px] text-indigo-300 font-mono">
                  {selectedAlgo.toUpperCase()}
                </span>
                <span className="rounded bg-cyan-500/10 px-2 py-0.5 text-[10px] text-cyan-300 font-mono">
                  k = {kClusters}
                </span>
              </div>
            </div>

            <div className="h-72 w-full mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" />
                  <XAxis
                    type="number"
                    dataKey="x"
                    name="Principal Component 1"
                    stroke="#94A3B8"
                    fontSize={10}
                  />
                  <YAxis
                    type="number"
                    dataKey="y"
                    name="Principal Component 2"
                    stroke="#94A3B8"
                    fontSize={10}
                  />
                  <ZAxis range={[35, 50]} />
                  <Tooltip
                    content={({ payload }) => {
                      if (!payload || payload.length === 0) return null;
                      const pt = payload[0].payload;
                      return (
                        <div className="rounded-lg border border-white/15 bg-slate-900 p-2.5 text-xs shadow-xl">
                          <div className="font-bold text-white">{pt.info}</div>
                          <div className="mt-1 text-slate-400">
                            Cluster: <span className="font-mono text-cyan-300">Cluster {pt.cluster + 1}</span>
                          </div>
                          <div className="text-[10px] text-slate-500">
                            PC1: {pt.x.toFixed(2)}, PC2: {pt.y.toFixed(2)}
                          </div>
                        </div>
                      );
                    }}
                  />
                  <Scatter name="Points" data={pcaPoints}>
                    {pcaPoints.map((entry, index) => (
                      <Cell key={`pca-pt-${index}`} fill={entry.color} />
                    ))}
                  </Scatter>
                </ScatterChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* 4 Cluster Quality Metric Scorecards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="glass-panel rounded-xl p-3 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400">Silhouette Score</span>
              <div className="text-xl font-black text-indigo-400 mt-1">
                {state.silhouetteScore || 0.64}
              </div>
              <span className="text-[9px] text-emerald-400">&gt; 0.5 (Well-separated)</span>
            </div>

            <div className="glass-panel rounded-xl p-3 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400">Davies-Bouldin</span>
              <div className="text-xl font-black text-cyan-400 mt-1">
                {state.daviesBouldinIndex || 0.72}
              </div>
              <span className="text-[9px] text-slate-400">Lower is better</span>
            </div>

            <div className="glass-panel rounded-xl p-3 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400">Calinski-Harabasz</span>
              <div className="text-xl font-black text-emerald-400 mt-1">
                {state.calinskiHarabaszScore || 412.5}
              </div>
              <span className="text-[9px] text-slate-400">Variance Ratio</span>
            </div>

            <div className="glass-panel rounded-xl p-3 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400">Inertia (WCSS)</span>
              <div className="text-xl font-black text-amber-400 mt-1">
                {state.inertia || 78.4}
              </div>
              <span className="text-[9px] text-slate-400">Within-cluster sum sq</span>
            </div>
          </div>
        </div>
      </div>

      {/* Elbow Method & Model Comparison Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Elbow Method Chart */}
        <div className="glass-panel rounded-2xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-white/5">
            <div>
              <h3 className="text-sm font-bold text-white">Elbow Method Curve (Optimal k Selection)</h3>
              <p className="text-[11px] text-slate-400">
                Inertia vs Number of clusters (k = 2 to 7) to identify inflection point
              </p>
            </div>
            <span className="rounded bg-indigo-500/10 px-2 py-0.5 text-[10px] text-indigo-300 font-semibold">
              Optimal: k = 4 or 5
            </span>
          </div>

          <div className="h-60 w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={state.elbowCurve || []} margin={{ top: 10, right: 20, left: 10, bottom: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" vertical={false} />
                <XAxis dataKey="k" stroke="#94A3B8" fontSize={10} name="k Clusters" />
                <YAxis stroke="#94A3B8" fontSize={10} name="Inertia" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#111827', borderColor: '#374151', borderRadius: '8px', fontSize: '12px' }}
                />
                <Line
                  type="monotone"
                  dataKey="inertia"
                  stroke="#F59E0B"
                  strokeWidth={2.5}
                  dot={{ r: 5, fill: '#F59E0B' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Model Comparison Matrix */}
        <div className="glass-panel rounded-2xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-white/5">
            <div>
              <h3 className="text-sm font-bold text-white">Algorithm Benchmark Comparison</h3>
              <p className="text-[11px] text-slate-400">Side-by-side performance across clustering paradigms</p>
            </div>
          </div>

          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-white/10 text-slate-400 font-semibold">
                  <th className="py-2">Algorithm</th>
                  <th className="py-2">Silhouette</th>
                  <th className="py-2">DB Index</th>
                  <th className="py-2">Structure</th>
                  <th className="py-2">Recommended Use</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-300">
                <tr className={selectedAlgo === 'kmeans' ? 'bg-indigo-600/15 font-semibold text-white' : ''}>
                  <td className="py-2.5">K-Means++</td>
                  <td className="py-2.5 font-mono text-indigo-400">0.68</td>
                  <td className="py-2.5 font-mono">0.72</td>
                  <td className="py-2.5">Spherical</td>
                  <td className="py-2.5 text-slate-400">Fast baseline segmentation</td>
                </tr>
                <tr className={selectedAlgo === 'hierarchical' ? 'bg-indigo-600/15 font-semibold text-white' : ''}>
                  <td className="py-2.5">Hierarchical</td>
                  <td className="py-2.5 font-mono text-cyan-400">0.62</td>
                  <td className="py-2.5 font-mono">0.81</td>
                  <td className="py-2.5">Tree / Nested</td>
                  <td className="py-2.5 text-slate-400">Sub-segment hierarchies</td>
                </tr>
                <tr className={selectedAlgo === 'dbscan' ? 'bg-indigo-600/15 font-semibold text-white' : ''}>
                  <td className="py-2.5">DBSCAN</td>
                  <td className="py-2.5 font-mono text-emerald-400">0.55</td>
                  <td className="py-2.5 font-mono">0.94</td>
                  <td className="py-2.5">Density-based</td>
                  <td className="py-2.5 text-slate-400">Anomaly &amp; noise detection</td>
                </tr>
                <tr className={selectedAlgo === 'gmm' ? 'bg-indigo-600/15 font-semibold text-white' : ''}>
                  <td className="py-2.5">Gaussian Mixture</td>
                  <td className="py-2.5 font-mono text-purple-400">0.65</td>
                  <td className="py-2.5 font-mono">0.75</td>
                  <td className="py-2.5">Probabilistic</td>
                  <td className="py-2.5 text-slate-400">Overlapping segment tiers</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
