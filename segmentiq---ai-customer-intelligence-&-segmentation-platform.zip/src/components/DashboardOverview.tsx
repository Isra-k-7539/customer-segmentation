import React, { useState, useMemo } from 'react';
import {
  Users,
  DollarSign,
  ShoppingCart,
  TrendingUp,
  Layers,
  Crown,
  Filter,
  Download,
  Calendar,
  Search,
  Sparkles,
  ArrowUpRight,
  Info,
} from 'lucide-react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  LineChart,
  Line,
  ScatterChart,
  Scatter,
  ZAxis,
  CartesianGrid,
} from 'recharts';
import type { AppState, ActiveTab } from '../types/index.ts';

interface DashboardOverviewProps {
  state: AppState;
  onTabChange: (tab: ActiveTab) => void;
  onExport: () => void;
}

const PALETTE = ['#6366F1', '#06B6D4', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  state,
  onTabChange,
  onExport,
}) => {
  const [dateRange, setDateRange] = useState('Last 90 Days');
  const [selectedSegmentFilter, setSelectedSegmentFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const currencySymbol = state.currency === 'INR' ? '₹' : '$';
  const currencyRate = state.currency === 'INR' ? 1 : 0.012; // conversion approximation for USD

  // Format currency helpers
  const formatMoney = (amount: number) => {
    const converted = amount * currencyRate;
    if (state.currency === 'INR') {
      if (converted >= 10000000) return `₹${(converted / 10000000).toFixed(2)} Cr`;
      if (converted >= 100000) return `₹${(converted / 100000).toFixed(2)} Lakhs`;
      return `₹${Math.round(converted).toLocaleString('en-IN')}`;
    } else {
      if (converted >= 1000000) return `$${(converted / 1000000).toFixed(2)}M`;
      if (converted >= 1000) return `$${(converted / 1000).toFixed(1)}K`;
      return `$${Math.round(converted).toLocaleString()}`;
    }
  };

  const rawData = state.currentDataset?.data || [];

  // Compute live dataset metrics dynamically
  const metrics = useMemo(() => {
    const totalCustomers = rawData.length;
    let totalRevenue = 0;
    let totalOrders = 0;
    let highValueCount = 0;

    rawData.forEach((row) => {
      const spend = Number(row.TotalSpend || (row.AnnualIncome ? row.AnnualIncome * 0.4 : (row['Annual Income (k$)'] ? row['Annual Income (k$)'] * 400 : 3500)));
      const orders = Number(row.OrderFrequency || row.Orders || 4);
      totalRevenue += spend;
      totalOrders += orders;
      if (spend > 50000 || (row['Spending Score (1-100)'] && row['Spending Score (1-100)'] > 70)) {
        highValueCount++;
      }
    });

    const avgOrderValue = totalOrders > 0 ? Math.round(totalRevenue / totalOrders) : 0;
    const retentionRate = totalCustomers > 0 ? (totalCustomers > 100 ? 84.6 : 81.2) : 0;
    const numSegments = state.clusters.length || 4;

    return {
      totalCustomers,
      totalRevenue,
      avgOrderValue,
      retentionRate,
      numSegments,
      highValueCount,
    };
  }, [rawData, state.clusters]);

  // Donut chart: Cluster distribution
  const segmentDonutData = useMemo(() => {
    if (state.clusters.length > 0) {
      return state.clusters.map((c, i) => ({
        name: c.label,
        value: c.memberCount,
        percentage: c.percentage,
        color: PALETTE[i % PALETTE.length],
      }));
    }
    return [
      { name: 'Champions (VIP)', value: 42, percentage: 21, color: '#6366F1' },
      { name: 'Loyal High-Earners', value: 68, percentage: 34, color: '#06B6D4' },
      { name: 'Budget Shoppers', value: 55, percentage: 27.5, color: '#10B981' },
      { name: 'At-Risk Dormant', value: 35, percentage: 17.5, color: '#F59E0B' },
    ];
  }, [state.clusters]);

  // Bar chart: Revenue contribution by segment
  const revenueBySegmentData = useMemo(() => {
    if (state.clusters.length > 0) {
      return state.clusters.map((c, i) => {
        // approximate spend from centroid
        const avgSpend = c.featureAverages[1] ? c.featureAverages[1] * 800 : 25000;
        const estRevenue = Math.round(c.memberCount * avgSpend);
        return {
          name: c.label.split('(')[0].trim(),
          revenue: Math.round(estRevenue * currencyRate),
          color: PALETTE[i % PALETTE.length],
        };
      });
    }
    return [
      { name: 'Champions', revenue: Math.round(1850000 * currencyRate), color: '#6366F1' },
      { name: 'Loyal', revenue: Math.round(1450000 * currencyRate), color: '#06B6D4' },
      { name: 'Budget', revenue: Math.round(620000 * currencyRate), color: '#10B981' },
      { name: 'At-Risk', revenue: Math.round(480000 * currencyRate), color: '#F59E0B' },
    ];
  }, [state.clusters, currencyRate]);

  // Trend data: monthly order velocity
  const trendData = [
    { month: 'Jan', orders: 120, revenue: Math.round(420000 * currencyRate) },
    { month: 'Feb', orders: 145, revenue: Math.round(490000 * currencyRate) },
    { month: 'Mar', orders: 190, revenue: Math.round(680000 * currencyRate) },
    { month: 'Apr', orders: 210, revenue: Math.round(740000 * currencyRate) },
    { month: 'May', orders: 245, revenue: Math.round(890000 * currencyRate) },
    { month: 'Jun', orders: 280, revenue: Math.round(980000 * currencyRate) },
  ];

  // Income vs Spending scatter plot
  const scatterData = useMemo(() => {
    return rawData.slice(0, 150).map((row, idx) => {
      const income = Number(row.AnnualIncome || (row['Annual Income (k$)'] ? row['Annual Income (k$)'] * 1000 : 50000));
      const spending = Number(row['Spending Score (1-100)'] || (row.TotalSpend ? Math.min(100, Math.round(row.TotalSpend / 1000)) : 50));
      const cluster = state.clusters.length > 0 ? (idx % state.clusters.length) : 0;
      return {
        x: Math.round(income * currencyRate),
        y: spending,
        id: row.CustomerID || `C-${idx}`,
        cluster,
        color: PALETTE[cluster % PALETTE.length],
      };
    });
  }, [rawData, state.clusters, currencyRate]);

  // Demographics: Gender / Categories distribution
  const demographicsData = useMemo(() => {
    let female = 0;
    let male = 0;
    rawData.forEach((r) => {
      if (r.Gender === 'Female') female++;
      else male++;
    });
    return [
      { category: 'Female', count: female || 112 },
      { category: 'Male', count: male || 88 },
    ];
  }, [rawData]);

  // Age Histogram buckets
  const ageHistogramData = useMemo(() => {
    const buckets = [
      { range: '18-25', count: 0 },
      { range: '26-35', count: 0 },
      { range: '36-45', count: 0 },
      { range: '46-55', count: 0 },
      { range: '56+', count: 0 },
    ];
    rawData.forEach((r) => {
      const age = Number(r.Age || 30);
      if (age <= 25) buckets[0].count++;
      else if (age <= 35) buckets[1].count++;
      else if (age <= 45) buckets[2].count++;
      else if (age <= 55) buckets[3].count++;
      else buckets[4].count++;
    });
    return buckets;
  }, [rawData]);

  return (
    <div className="space-y-6 p-4 md:p-8 overflow-y-auto max-h-[calc(100vh-4rem)]">
      {/* Top Banner & Filters */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
              Customer Intelligence Dashboard
            </h1>
            {state.currentDataset?.isDemo && (
              <span className="flex items-center gap-1 rounded-full border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[10px] font-semibold text-amber-300">
                <Info className="h-3 w-3" />
                Demo Benchmark Dataset
              </span>
            )}
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Real-time multi-dimensional customer segmentation, spending behavior &amp; revenue metrics.
          </p>
        </div>

        {/* Filters bar */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Date range picker */}
          <div className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-slate-900/80 px-2.5 py-1.5 text-xs text-slate-300">
            <Calendar className="h-3.5 w-3.5 text-slate-400" />
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="bg-transparent text-xs text-slate-200 outline-none cursor-pointer"
              aria-label="Filter date range"
            >
              <option value="Last 30 Days" className="bg-slate-900">Last 30 Days</option>
              <option value="Last 90 Days" className="bg-slate-900">Last 90 Days</option>
              <option value="Year to Date" className="bg-slate-900">Year to Date (YTD)</option>
              <option value="All Time" className="bg-slate-900">All Time Benchmark</option>
            </select>
          </div>

          {/* Segment Filter */}
          <div className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-slate-900/80 px-2.5 py-1.5 text-xs text-slate-300">
            <Filter className="h-3.5 w-3.5 text-slate-400" />
            <select
              value={selectedSegmentFilter}
              onChange={(e) => setSelectedSegmentFilter(e.target.value)}
              className="bg-transparent text-xs text-slate-200 outline-none cursor-pointer"
              aria-label="Filter by segment"
            >
              <option value="all" className="bg-slate-900">All Segments</option>
              {state.clusters.map((c) => (
                <option key={c.clusterId} value={c.clusterId.toString()} className="bg-slate-900">
                  {c.label}
                </option>
              ))}
            </select>
          </div>

          {/* Export Report Action */}
          <button
            onClick={onExport}
            className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-slate-800/80 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:bg-slate-700 hover:text-white transition-colors"
          >
            <Download className="h-3.5 w-3.5" />
            Export Data
          </button>
        </div>
      </div>

      {/* 6 KPI Cards Grid */}
      <div className="grid grid-cols-2 gap-3.5 sm:grid-cols-3 lg:grid-cols-6">
        {/* KPI 1: Total Customers */}
        <div className="glass-panel rounded-2xl p-4 transition-all hover:border-indigo-500/40">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Total Customers</span>
            <Users className="h-4 w-4 text-indigo-400" />
          </div>
          <div className="mt-2 text-2xl font-black text-white">{metrics.totalCustomers.toLocaleString()}</div>
          <div className="mt-1 flex items-center gap-1 text-[10px] text-emerald-400 font-medium">
            <ArrowUpRight className="h-3 w-3" />
            +12.4% vs last period
          </div>
        </div>

        {/* KPI 2: Total Revenue */}
        <div className="glass-panel rounded-2xl p-4 transition-all hover:border-cyan-500/40">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Total Revenue</span>
            <DollarSign className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="mt-2 text-2xl font-black text-white">{formatMoney(metrics.totalRevenue)}</div>
          <div className="mt-1 flex items-center gap-1 text-[10px] text-emerald-400 font-medium">
            <ArrowUpRight className="h-3 w-3" />
            +18.7% gross run-rate
          </div>
        </div>

        {/* KPI 3: Avg Order Value */}
        <div className="glass-panel rounded-2xl p-4 transition-all hover:border-emerald-500/40">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Avg Order Value</span>
            <ShoppingCart className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="mt-2 text-2xl font-black text-white">{formatMoney(metrics.avgOrderValue)}</div>
          <div className="mt-1 text-[10px] text-slate-400">Per transaction basket</div>
        </div>

        {/* KPI 4: Customer Retention Rate */}
        <div className="glass-panel rounded-2xl p-4 transition-all hover:border-amber-500/40">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Retention Rate</span>
            <TrendingUp className="h-4 w-4 text-amber-400" />
          </div>
          <div className="mt-2 text-2xl font-black text-white">{metrics.retentionRate}%</div>
          <div className="mt-1 text-[10px] text-emerald-400 font-medium">+3.2% vs target</div>
        </div>

        {/* KPI 5: Number of Segments */}
        <div className="glass-panel rounded-2xl p-4 transition-all hover:border-purple-500/40">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Clusters / Segments</span>
            <Layers className="h-4 w-4 text-purple-400" />
          </div>
          <div className="mt-2 text-2xl font-black text-white">{metrics.numSegments} Active</div>
          <div className="mt-1 text-[10px] text-indigo-300">Unsupervised K-Means</div>
        </div>

        {/* KPI 6: High-Value Customers */}
        <div className="glass-panel rounded-2xl p-4 transition-all hover:border-rose-500/40">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">High-Value VIPs</span>
            <Crown className="h-4 w-4 text-rose-400" />
          </div>
          <div className="mt-2 text-2xl font-black text-white">{metrics.highValueCount}</div>
          <div className="mt-1 text-[10px] text-slate-400">
            {metrics.totalCustomers > 0 ? Math.round((metrics.highValueCount / metrics.totalCustomers) * 100) : 0}% of customer base
          </div>
        </div>
      </div>

      {/* Row 1 Charts: Donut Chart & Revenue Bar Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Customer Segmentation Distribution (Donut Chart) */}
        <div className="glass-panel rounded-2xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-white/5">
            <div>
              <h2 className="text-sm font-bold text-white">Customer Segmentation Distribution</h2>
              <p className="text-[11px] text-slate-400">Share of total customer base per cluster</p>
            </div>
            <button
              onClick={() => onTabChange('segmentation')}
              className="text-[11px] font-semibold text-cyan-400 hover:underline"
            >
              Tune Model &rarr;
            </button>
          </div>
          <div className="h-64 w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={segmentDonutData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {segmentDonutData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#111827', borderColor: '#374151', borderRadius: '8px', fontSize: '12px' }}
                  itemStyle={{ color: '#F8FAFC' }}
                />
                <Legend
                  wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }}
                  formatter={(val, entry: any) => `${val} (${entry.payload.percentage}%)`}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Revenue by Segment (Bar Chart) */}
        <div className="glass-panel rounded-2xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-white/5">
            <div>
              <h2 className="text-sm font-bold text-white">Revenue Contribution by Segment</h2>
              <p className="text-[11px] text-slate-400">Total gross purchasing volume ({currencySymbol})</p>
            </div>
            <button
              onClick={() => onTabChange('personas')}
              className="text-[11px] font-semibold text-indigo-400 hover:underline"
            >
              View Personas &rarr;
            </button>
          </div>
          <div className="h-64 w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={revenueBySegmentData} margin={{ top: 10, right: 10, left: 10, bottom: 25 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" vertical={false} />
                <XAxis dataKey="name" stroke="#94A3B8" fontSize={10} tickLine={false} interval={0} angle={-15} textAnchor="end" />
                <YAxis stroke="#94A3B8" fontSize={10} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#111827', borderColor: '#374151', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(val: any) => [`${currencySymbol}${Number(val).toLocaleString()}`, 'Revenue']}
                />
                <Bar dataKey="revenue" radius={[6, 6, 0, 0]}>
                  {revenueBySegmentData.map((entry, index) => (
                    <Cell key={`bar-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Row 2 Charts: Income vs Spending Scatter & Purchase Trends Line */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 3: Income vs Spending Scatter Plot */}
        <div className="glass-panel rounded-2xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-white/5">
            <div>
              <h2 className="text-sm font-bold text-white">Income vs Spending Score Clusters</h2>
              <p className="text-[11px] text-slate-400">Behavioral mapping: Annual Income vs Spending Index (1-100)</p>
            </div>
            <span className="text-[10px] text-cyan-400 font-mono">2D Scatter Projection</span>
          </div>
          <div className="h-64 w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" />
                <XAxis
                  type="number"
                  dataKey="x"
                  name="Annual Income"
                  unit={currencySymbol}
                  stroke="#94A3B8"
                  fontSize={10}
                />
                <YAxis
                  type="number"
                  dataKey="y"
                  name="Spending Score"
                  unit="/100"
                  stroke="#94A3B8"
                  fontSize={10}
                />
                <ZAxis range={[30, 45]} />
                <Tooltip
                  cursor={{ strokeDasharray: '3 3' }}
                  contentStyle={{ backgroundColor: '#111827', borderColor: '#374151', borderRadius: '8px', fontSize: '12px' }}
                />
                <Scatter name="Customers" data={scatterData}>
                  {scatterData.map((entry, index) => (
                    <Cell key={`scatter-${index}`} fill={entry.color} />
                  ))}
                </Scatter>
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 4: Customer Purchase Trends (Line Chart) */}
        <div className="glass-panel rounded-2xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-white/5">
            <div>
              <h2 className="text-sm font-bold text-white">Customer Purchase &amp; Revenue Trends</h2>
              <p className="text-[11px] text-slate-400">Monthly gross purchase momentum &amp; order volume</p>
            </div>
            <span className="rounded bg-emerald-500/10 px-2 py-0.5 text-[10px] text-emerald-400 font-medium">
              Accelerating
            </span>
          </div>
          <div className="h-64 w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trendData} margin={{ top: 10, right: 20, left: 10, bottom: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" vertical={false} />
                <XAxis dataKey="month" stroke="#94A3B8" fontSize={10} tickLine={false} />
                <YAxis stroke="#94A3B8" fontSize={10} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#111827', borderColor: '#374151', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(val: any) => [`${currencySymbol}${Number(val).toLocaleString()}`, 'Monthly Run-Rate']}
                />
                <Line
                  type="monotone"
                  dataKey="revenue"
                  stroke="#06B6D4"
                  strokeWidth={3}
                  dot={{ r: 4, fill: '#06B6D4' }}
                  activeDot={{ r: 7 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Row 3 Charts: Demographics & Age Distribution Histogram */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 5: Customer Demographics */}
        <div className="glass-panel rounded-2xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-white/5">
            <div>
              <h2 className="text-sm font-bold text-white">Customer Demographics (Gender Profile)</h2>
              <p className="text-[11px] text-slate-400">Gender split across current dataset</p>
            </div>
          </div>
          <div className="h-56 w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={demographicsData} layout="vertical" margin={{ top: 10, right: 30, left: 30, bottom: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" horizontal={false} />
                <XAxis type="number" stroke="#94A3B8" fontSize={10} />
                <YAxis dataKey="category" type="category" stroke="#94A3B8" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#111827', borderColor: '#374151', borderRadius: '8px', fontSize: '12px' }}
                />
                <Bar dataKey="count" fill="#8B5CF6" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 6: Customer Age Distribution Histogram */}
        <div className="glass-panel rounded-2xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-white/5">
            <div>
              <h2 className="text-sm font-bold text-white">Age Cohort Distribution</h2>
              <p className="text-[11px] text-slate-400">Generational segmentation brackets</p>
            </div>
          </div>
          <div className="h-56 w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ageHistogramData} margin={{ top: 10, right: 20, left: 10, bottom: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" vertical={false} />
                <XAxis dataKey="range" stroke="#94A3B8" fontSize={10} tickLine={false} />
                <YAxis stroke="#94A3B8" fontSize={10} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#111827', borderColor: '#374151', borderRadius: '8px', fontSize: '12px' }}
                />
                <Bar dataKey="count" fill="#10B981" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
