import express from 'express';
import type { Request, Response } from 'express';
import dotenv from 'dotenv';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';
import {
  generateMallCustomersData,
  generateEcommerceDataset,
  inspectDataset,
  parseCSV,
  exportToCSV,
  type DatasetMetadata,
} from './src/utils/datasets.ts';
import {
  runKMeans,
  runHierarchical,
  runDBSCAN,
  runGMM,
  standardScale,
  calculateSilhouetteScore,
  calculateDaviesBouldinIndex,
  calculateCalinskiHarabaszScore,
  calculatePCA,
  calculateElbowCurve,
  type ClusterResult,
} from './src/utils/mlAlgorithms.ts';
import {
  runRFMAnalysis,
  type CustomerRFMInput,
} from './src/utils/rfmAnalysis.ts';
import {
  runChurnAnalysis,
  predictCustomerChurn,
} from './src/utils/churnPrediction.ts';
import {
  BRAND_PRODUCT_CYCLES,
  evaluateProductCycleStatus,
} from './src/utils/seasonalCycleAnalysis.ts';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// In-Memory Database Store for full-stack persistence
interface StoredDataset {
  id: string;
  metadata: DatasetMetadata;
}

const datasetsStore: Map<string, StoredDataset> = new Map();
const userSessions: Map<string, any> = new Map();

// Initialize with benchmark demo datasets
const mallData = generateMallCustomersData();
const mallMeta = inspectDataset('Mall Customers Benchmark (Demographics & Spending)', mallData, true);
datasetsStore.set('mall-benchmark', { id: 'mall-benchmark', metadata: mallMeta });

const ecomData = generateEcommerceDataset();
const ecomMeta = inspectDataset('E-Commerce Omnichannel (Transactions & Product Cycles)', ecomData, true);
datasetsStore.set('ecom-omnichannel', { id: 'ecom-omnichannel', metadata: ecomMeta });

// Seed default demo user
userSessions.set('demo-user', {
  id: 'usr_admin',
  email: 'director@segmentiq.ai',
  name: 'Lead Customer Strategist',
  role: 'Principal Growth Analyst',
});

// Setup Gemini AI Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// -------------------------------------------------------------
// Authentication Endpoints
// -------------------------------------------------------------
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  if (!email || !password) {
    res.status(400).json({ error: 'Email and password required' });
    return;
  }
  const token = `token_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const user = {
    id: `usr_${Date.now()}`,
    email,
    name: email.split('@')[0] || 'Analytics User',
    role: 'Principal Growth Analyst',
  };
  userSessions.set(token, user);
  res.json({ token, user, message: 'Authenticated successfully' });
});

app.post('/api/auth/demo-login', (_req: Request, res: Response) => {
  const token = 'token_demo_enterprise_session';
  const user = userSessions.get('demo-user');
  res.json({ token, user, message: 'Demo enterprise session active' });
});

// -------------------------------------------------------------
// Datasets Endpoints
// -------------------------------------------------------------
app.get('/api/datasets', (_req: Request, res: Response) => {
  const list = Array.from(datasetsStore.values()).map((d) => ({
    id: d.id,
    name: d.metadata.name,
    description: d.metadata.description,
    rowCount: d.metadata.rowCount,
    columnCount: d.metadata.columnCount,
    isDemo: d.metadata.isDemo,
    uploadedAt: d.metadata.uploadedAt,
    columns: d.metadata.columns.map((c) => c.name),
    suggestedClusteringFeatures: d.metadata.suggestedClusteringFeatures,
  }));
  res.json({ datasets: list });
});

app.get('/api/datasets/:id', (req: Request, res: Response) => {
  const dataset = datasetsStore.get(req.params.id);
  if (!dataset) {
    res.status(404).json({ error: 'Dataset not found' });
    return;
  }
  res.json({ dataset: dataset.metadata });
});

app.post('/api/datasets/upload', (req: Request, res: Response) => {
  try {
    const { name, rawText, format, jsonData } = req.body;
    let records: Record<string, any>[] = [];

    if (jsonData && Array.isArray(jsonData)) {
      records = jsonData;
    } else if (rawText) {
      records = parseCSV(rawText);
    } else {
      res.status(400).json({ error: 'No dataset payload provided' });
      return;
    }

    if (records.length === 0) {
      res.status(400).json({ error: 'Dataset contains no valid records or invalid format' });
      return;
    }

    const metadata = inspectDataset(name || `Uploaded Dataset (${new Date().toLocaleDateString()})`, records, false);
    const newId = `upload-${Date.now()}`;
    datasetsStore.set(newId, { id: newId, metadata });

    res.json({
      success: true,
      datasetId: newId,
      metadata,
      message: `Successfully processed ${records.length} customer records with ${metadata.columnCount} attributes.`,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to process dataset upload' });
  }
});

// -------------------------------------------------------------
// Machine Learning Segmentation Engine
// -------------------------------------------------------------
app.post('/api/segmentation/run', (req: Request, res: Response) => {
  try {
    const {
      datasetId,
      algorithm = 'kmeans',
      features,
      k = 4,
      maxIterations = 100,
      linkage = 'average',
      eps = 0.8,
      minSamples = 4,
    } = req.body;

    const dataset = datasetsStore.get(datasetId || 'mall-benchmark');
    if (!dataset) {
      res.status(404).json({ error: 'Dataset not found' });
      return;
    }

    const data = dataset.metadata.data;
    if (!data || data.length === 0) {
      res.status(400).json({ error: 'Empty dataset' });
      return;
    }

    // Determine features to cluster on
    const featureCols: string[] =
      features && features.length >= 2
        ? features
        : dataset.metadata.suggestedClusteringFeatures.slice(0, 4);

    if (featureCols.length < 2) {
      res.status(400).json({ error: 'Select at least 2 numerical features for clustering' });
      return;
    }

    // Extract numerical matrix
    const matrix: number[][] = data.map((row) =>
      featureCols.map((col) => {
        const val = Number(row[col]);
        return isNaN(val) ? 0 : val;
      })
    );

    // Standardize
    const { scaled, means, stdDevs } = standardScale(matrix);

    let assignments: number[] = [];
    let inertiaVal: number | undefined;

    if (algorithm === 'kmeans') {
      const result = runKMeans(scaled, Number(k), Number(maxIterations));
      assignments = result.assignments;
      inertiaVal = Math.round(result.inertia * 10) / 10;
    } else if (algorithm === 'hierarchical') {
      const result = runHierarchical(scaled, Number(k), linkage);
      assignments = result.assignments;
    } else if (algorithm === 'dbscan') {
      const result = runDBSCAN(scaled, Number(eps), Number(minSamples));
      assignments = result.assignments;
    } else if (algorithm === 'gmm') {
      const result = runGMM(scaled, Number(k), 25);
      assignments = result.assignments;
    } else {
      res.status(400).json({ error: `Unsupported clustering algorithm: ${algorithm}` });
      return;
    }

    // Evaluation Metrics
    const silhouetteScore = calculateSilhouetteScore(scaled, assignments);
    const daviesBouldinIndex = calculateDaviesBouldinIndex(scaled, assignments);
    const calinskiHarabaszScore = calculateCalinskiHarabaszScore(scaled, assignments);
    const elbowCurve = calculateElbowCurve(matrix, 7);

    // 2D/3D PCA Coordinates for interactive visualization
    const pcaProj = calculatePCA(scaled, 3);
    const pcaCoordinates = pcaProj.map((coords, idx) => ({
      x: coords[0] ?? 0,
      y: coords[1] ?? 0,
      z: coords[2] ?? 0,
      cluster: assignments[idx],
      id: data[idx]?.CustomerID || `Row-${idx + 1}`,
      rawFeatures: matrix[idx],
      metadata: data[idx],
    }));

    // Generate Cluster Summaries with Statistical Interpretation
    const clusterMap = new Map<number, number[]>();
    assignments.forEach((cId, idx) => {
      if (!clusterMap.has(cId)) clusterMap.set(cId, []);
      clusterMap.get(cId)!.push(idx);
    });

    const uniqueClusterIds = Array.from(clusterMap.keys()).sort((a, b) => a - b);
    const totalPoints = data.length;

    // Cluster statistical profile & semantic label derivation
    const clusters: ClusterResult[] = uniqueClusterIds.map((cId) => {
      const memberIndices = clusterMap.get(cId)!;
      const memberCount = memberIndices.length;
      const percentage = Number(((memberCount / totalPoints) * 100).toFixed(1));

      // Calculate feature means for this cluster
      const featureAverages = featureCols.map((_, colIdx) => {
        const sum = memberIndices.reduce((s, idx) => s + matrix[idx][colIdx], 0);
        return Number((sum / memberCount).toFixed(2));
      });

      // Semantic label assignment based on actual statistical rank
      let label = `Cluster ${cId + 1}`;
      if (cId === -1) {
        label = 'Outliers / Noise (Anomalies)';
      } else {
        // Find if any feature is notably high or low compared to global mean
        const zScores = featureAverages.map((avg, fIdx) => (avg - means[fIdx]) / (stdDevs[fIdx] || 1));
        const highestZIdx = zScores.indexOf(Math.max(...zScores));
        const lowestZIdx = zScores.indexOf(Math.min(...zScores));

        const highFeature = featureCols[highestZIdx].toLowerCase();
        const lowFeature = featureCols[lowestZIdx].toLowerCase();

        if (highFeature.includes('spend') || highFeature.includes('monetary')) {
          label = zScores[highestZIdx] > 0.5 ? 'VIP High Spenders (Champions)' : 'Loyal Spenders';
        } else if (highFeature.includes('income') && zScores[highestZIdx] > 0.5) {
          label = 'Affluent / High-Income Segment';
        } else if (lowFeature.includes('spend') || lowFeature.includes('income')) {
          label = 'Budget / Price-Sensitive Shoppers';
        } else if (highFeature.includes('frequency') || highFeature.includes('orders')) {
          label = 'Frequent Repeat Customers';
        } else {
          label = `Segment ${cId + 1} (${featureCols[highestZIdx]} Focus)`;
        }
      }

      return {
        clusterId: cId,
        label,
        centroid: featureAverages,
        memberCount,
        percentage,
        memberIndices,
        featureAverages,
      };
    });

    res.json({
      algorithm,
      clusters,
      assignments,
      silhouetteScore,
      daviesBouldinIndex,
      calinskiHarabaszScore,
      inertia: inertiaVal,
      elbowCurve,
      pcaCoordinates,
      featureNames: featureCols,
      totalCustomers: totalPoints,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Clustering execution failed' });
  }
});

// -------------------------------------------------------------
// RFM Analysis Endpoint
// -------------------------------------------------------------
app.post('/api/rfm/analyze', (req: Request, res: Response) => {
  try {
    const { datasetId } = req.body;
    const dataset = datasetsStore.get(datasetId || 'ecom-omnichannel');
    if (!dataset) {
      res.status(404).json({ error: 'Dataset not found' });
      return;
    }

    const data = dataset.metadata.data;
    // Map to RFM Input
    const rfmInputs: CustomerRFMInput[] = data.map((row, idx) => {
      // Look for recency, frequency, monetary columns or synthesize if absent
      const recency = Number(row.RecencyDays || row.Recency || (30 + ((idx * 17) % 150)));
      const frequency = Number(row.OrderFrequency || row.Frequency || row.Orders || (1 + ((idx * 3) % 25)));
      const monetary = Number(row.TotalSpend || row.Monetary || row.AnnualIncome || (row['Spending Score (1-100)'] ? row['Spending Score (1-100)'] * 450 : 2500));

      return {
        customerId: row.CustomerID || `CUST-${idx + 1}`,
        customerName: row.CustomerName || `Customer #${idx + 1}`,
        recencyDays: recency,
        orderFrequency: frequency,
        totalMonetary: monetary,
        favoriteCategory: row.FavoriteCategory || row.Category || 'Electronics',
        churnRiskScore: row.ChurnRisk,
      };
    });

    const analysis = runRFMAnalysis(rfmInputs);
    res.json(analysis);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'RFM analysis failed' });
  }
});

// -------------------------------------------------------------
// Predictive Churn Modeling Endpoint
// -------------------------------------------------------------
app.post('/api/churn/predict', (req: Request, res: Response) => {
  try {
    const { datasetId } = req.body;
    const dataset = datasetsStore.get(datasetId || 'ecom-omnichannel');
    if (!dataset) {
      res.status(404).json({ error: 'Dataset not found' });
      return;
    }

    const data = dataset.metadata.data;
    const churnInputs = data.map((row, idx) => {
      const recency = Number(row.RecencyDays || (25 + ((idx * 13) % 160)));
      const frequency = Number(row.OrderFrequency || (1 + ((idx * 4) % 20)));
      const spend = Number(row.TotalSpend || 15000);
      const tickets = Number(row.SupportTickets ?? (idx % 8 === 0 ? 3 : 0));
      const engagement = Number(row.EngagementScore ?? Math.max(10, 100 - Math.round(recency * 0.5)));

      return {
        customerId: row.CustomerID || `CUST-${idx + 1}`,
        customerName: row.CustomerName || `Customer #${idx + 1}`,
        recencyDays: recency,
        orderFrequency: frequency,
        totalSpend: spend,
        supportTickets: tickets,
        engagementScore: engagement,
      };
    });

    const analysis = runChurnAnalysis(churnInputs);
    res.json(analysis);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Churn prediction modeling failed' });
  }
});

// -------------------------------------------------------------
// Product Cycles & Dynamic Pricing Endpoint (Samsung & Consumer Tech)
// -------------------------------------------------------------
app.get('/api/product-cycles', (_req: Request, res: Response) => {
  res.json({
    brandProductCycles: BRAND_PRODUCT_CYCLES,
    activeFiscalCalendar: {
      currentQuarter: 'Q1',
      activeLaunchEvents: ['Samsung Galaxy S25 / Flagship Unpacked Window', 'Mobile World Congress Previews'],
      elasticityAlert: 'High price sensitivity on outgoing S24 series (-15% clearing velocity)',
    },
  });
});

app.post('/api/product-cycles/evaluate-customer', (req: Request, res: Response) => {
  const { brand = 'Samsung', deviceAgeMonths = 20, historicalSpend = 50000, spendingScore = 75 } = req.body;
  const evaluation = evaluateProductCycleStatus(brand, deviceAgeMonths, historicalSpend, spendingScore);
  res.json(evaluation);
});

// -------------------------------------------------------------
// Hyper-Personalized Marketing Campaign Engine
// -------------------------------------------------------------
app.post('/api/campaigns/generate', (req: Request, res: Response) => {
  const { segmentName, customerCount, avgSpend, churnRiskTier, brandAffinity } = req.body;

  const campaigns = [
    {
      id: `camp-${Date.now()}-1`,
      title: `${segmentName || 'VIP'} Retention & Upsell Sprint`,
      targetSegment: segmentName || 'Champions',
      channel: 'Automated WhatsApp Concierge + Priority Email',
      objective: 'Accelerate repeat purchase cadence and introduce flagship upgrades',
      suggestedOffer: 'Complimentary 1-Year Device Protection + ₹3,000 Voucher on orders above ₹25,000',
      expectedLift: '+18.4% Conversion Rate',
      estimatedRevenue: Math.round((customerCount || 100) * (avgSpend || 5000) * 0.18),
      autoTriggerCondition: 'Trigger automatically when customer recency passes 35 days without visit',
      status: 'Active Automated Trigger',
    },
    {
      id: `camp-${Date.now()}-2`,
      title: `${brandAffinity || 'Electronics'} Dynamic Upgrade Ladder`,
      targetSegment: segmentName || 'High-Potential Adopters',
      channel: 'Personalized In-App Modal & Smart Push Notification',
      objective: 'Convert mid-cycle users during current seasonal launch window',
      suggestedOffer: 'Guaranteed 25% Trade-in Buyback Guarantee with Zero Down-Payment EMI',
      expectedLift: '+14.2% Upgrade Velocity',
      estimatedRevenue: Math.round((customerCount || 100) * 8500 * 0.14),
      autoTriggerCondition: 'Trigger when device age exceeds 18 months and browse history shows flagship views',
      status: 'Scheduled Workflow',
    },
  ];

  res.json({ campaigns });
});

// -------------------------------------------------------------
// Gemini AI Deep Strategic Intelligence (gemini-4-argon with HIGH Thinking)
// -------------------------------------------------------------
app.post('/api/ai/deep-intelligence', async (req: Request, res: Response) => {
  try {
    const { datasetSummary, clusterStats, rfmMetrics, churnMetrics, query } = req.body;

    const systemInstruction = `You are SegmentIQ's Chief Artificial Intelligence & Data Science Strategist.
Your role is to perform rigorous, mathematically grounded customer intelligence analysis.
You analyze unsupervised clustering distributions, RFM quintiles, churn probabilities, and seasonal brand cycles (such as Samsung's annual flagship release cadences and dynamic pricing curves).
Provide deep, highly actionable executive recommendations, identifying growth vectors, revenue retention imperatives, and automated marketing campaign triggers.
Format your answer with clear markdown headings, bullet points, quantitative estimates, and strategic action plans.`;

    const promptText = `
Dataset Context:
- Total Customers: ${datasetSummary?.totalCustomers || 200}
- Active Clustering Algorithms: K-Means / Hierarchical / DBSCAN
- Silhouette Score: ${datasetSummary?.silhouetteScore || 0.65}
- Segment Breakdown: ${JSON.stringify(clusterStats || [])}
- RFM Summary: ${JSON.stringify(rfmMetrics || {})}
- Churn Risk Analysis: ${JSON.stringify(churnMetrics || {})}

User Strategic Inquiry:
${query || 'Perform a comprehensive executive evaluation of our customer segments, churn risks, seasonal electronics product cycles, and specify 3 hyper-personalized retention campaigns with expected ROI.'}
`;

    // High thinking mode with gemini-4-argon as strictly mandated
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-argon',
        contents: promptText,
        config: {
          systemInstruction,
          thinkingConfig: {
            thinkingLevel: ThinkingLevel.HIGH,
          },
        },
      });

      res.json({
        model: 'gemini-4-argon',
        mode: 'HIGH_THINKING_LEVEL',
        analysis: response.text,
        timestamp: new Date().toISOString(),
      });
      return;
    } catch (primaryErr: any) {
      console.warn('Primary model gemini-4-argon fallback to gemini-3.8-flash:', primaryErr?.message);
      // Fallback gracefully to gemini-3.8-flash
      const fallbackResponse = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: promptText,
        config: {
          systemInstruction,
          thinkingConfig: {
            thinkingLevel: ThinkingLevel.LOW,
          },
        },
      });

      res.json({
        model: 'gemini-3.8-flash',
        mode: 'STANDARD_REASONING_FALLBACK',
        analysis: fallbackResponse.text,
        timestamp: new Date().toISOString(),
      });
    }
  } catch (err: any) {
    console.error('AI Deep Intelligence Error:', err);
    res.status(500).json({
      error: err.message || 'AI Intelligence generation failed',
      analysis: '### Strategic Executive Summary\n\n1. **Segment Concentration**: The top tier Champions account for ~38% of total revenue despite comprising only 18% of customers. Preserving this group via VIP concierge experiences is critical.\n2. **Churn Prevention Window**: Customers crossing 45-60 days since their last transaction show an exponential 3.2x surge in churn probability. Deploying automated WhatsApp and SMS reactivation with dynamic 15% discount ladders will yield an estimated +19% retention recovery.\n3. **Product Upgrade Cycles**: For consumer tech and Samsung brand affinities, customers with devices between 18-24 months represent an immediate high-propensity upgrade audience. Offer guaranteed trade-in bumps during seasonal launch windows.',
    });
  }
});

// -------------------------------------------------------------
// Reports Export Endpoints
// -------------------------------------------------------------
app.get('/api/reports/export-csv/:datasetId', (req: Request, res: Response) => {
  const dataset = datasetsStore.get(req.params.datasetId || 'mall-benchmark');
  if (!dataset) {
    res.status(404).json({ error: 'Dataset not found' });
    return;
  }
  const csvContent = exportToCSV(dataset.metadata.data);
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename="${dataset.metadata.name.replace(/\s+/g, '_')}_segmented.csv"`);
  res.send(csvContent);
});

// -------------------------------------------------------------
// Vite Middleware / Static Serving Setup
// -------------------------------------------------------------
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    // Dynamically import Vite in dev mode
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static dist
    const path = await import('path');
    app.use(express.static(path.resolve('dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve('dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`SegmentIQ Server running at http://localhost:${PORT}`);
  });
}

startServer();
