# SegmentIQ: AI-Powered Customer Intelligence & Segmentation Platform

> **Tagline:** Understand Your Customers. Discover Opportunities. Drive Growth.

SegmentIQ is an enterprise-grade customer intelligence, unsupervised clustering, RFM segmentation, predictive churn modeling, and automated marketing campaign platform. It helps modern businesses, retailers, and consumer electronics brands (such as Samsung ecosystem partners) segment their customer base, identify high-value Champions, predict churn probabilities before customer defection, and automate dynamic pricing adjustments aligned with seasonal product upgrade cycles.

---

## 🏛️ Architecture Overview

```
                           SEGMENTIQ
                 Customer Intelligence Platform
                               │
            ┌──────────────────┴──────────────────┐
            ▼                                     ▼
     FRONTEND SPA                           FULL-STACK ENGINE
 React 19 + TypeScript                        Express & Node.js
   Tailwind CSS v4                                   │
      Recharts                                ┌──────┴──────┐
    Lucide Icons                              ▼             ▼
                                         ML PIPELINE   AI STRATEGIC ADVISOR
                                         - K-Means++   Gemini 4 Argon
                                         - DBSCAN      High Thinking Level
                                         - GMM (EM)
                                         - RFM Scoring
                                         - Sigmoid Churn
                                         - PCA 2D/3D
```

---

## 🚀 Key Modules & Capabilities

1. **Dashboard Overview (Module 1)**:
   - 6 KPI Cards: Total Customers, Total Revenue, Average Order Value, Retention Rate, Number of Segments, High-Value VIP count.
   - 6 Interactive Charts:
     - Customer Segmentation Distribution (Donut Chart)
     - Revenue by Segment (Bar Chart)
     - Customer Purchase & Revenue Trends (Line Chart)
     - Income vs Spending (Scatter Plot with cluster coloring)
     - Customer Demographics (Gender Profile)
     - Age Cohort Distribution (Histogram)
   - Date range filtering, segment filter, live dataset indicator (Demo vs Uploaded).

2. **Customer Data Management (Module 2)**:
   - Drag & drop CSV / Excel / TSV upload.
   - Built-in benchmark datasets:
     - **Mall Customers Benchmark** (200 records: Age, Income, Spending Score).
     - **E-Commerce Omnichannel** (150 records: Transactions, Recency, Frequency, Monetary, Brand Affinity, Support Tickets, Device Age).
   - Data hygiene quality assessment (Missing values, Duplicate detection, Health score).
   - Searchable, filterable customer records table with pagination and individual record inspector modal.
   - Cleaned CSV dataset download.

3. **Machine Learning Segmentation Engine (Module 3)**:
   - **K-Means Clustering** (with K-Means++ initialization, Lloyd's iterations, inertia tracking).
   - **Agglomerative Hierarchical Clustering** (Average, Complete, Single linkage).
   - **DBSCAN** (Density-based clustering with noise/outlier detection).
   - **Gaussian Mixture Model (GMM)** (Soft probabilistic clustering via Expectation-Maximization).
   - **Dimensionality Reduction**: Principal Component Analysis (PCA 2D/3D projection).
   - **Cluster Evaluation Metrics**:
     - Silhouette Score (Separation)
     - Davies-Bouldin Index (Compactness)
     - Calinski-Harabasz Score (Variance Ratio)
     - Inertia / WCSS
   - **Elbow Method Curve**: Plots inertia across $k=2$ to $7$ to select optimal cluster count.
   - **Model Comparison Table**: Side-by-side benchmark comparison.

4. **Customer Personas & Segment Analytics (Modules 4 & 6)**:
   - Dynamic semantic label generation based on cluster feature z-scores (Champions, Loyal High-Earners, Budget Shoppers, At-Risk Accounts).
   - Persona dossiers with customer counts, gross spend share, behavioral traits, and tailored business strategies.
   - Side-by-side segment comparison tool.

5. **RFM Analysis (Module 5)**:
   - Quantile scoring (1–5) for Recency, Frequency, and Monetary dimensions.
   - RFM 5x5 Heatmap Matrix (Recency vs Frequency grid).
   - Segment classification: Champions, Loyal Customers, Potential Loyalists, At-Risk, Can't Lose Them, Hibernating, Lost Customers.

6. **Predictive Churn Modeling & Retention Engine (Module 8)**:
   - Logistic sigmoid churn probability model ($0-100\%$).
   - Risk Tiers: Critical Risk ($>75\%$), High Risk ($50-75\%$), Medium Risk ($25-50\%$), Safe ($<25\%$).
   - Top churn risk drivers: Inactivity lapse ($>60$ days), frequency decay, support friction.
   - Revenue at immediate risk calculator.
   - 1-Click Retention Playbook dispatch (WhatsApp, SMS, VIP Concierge, discount ladders).

7. **Seasonal Trend & Brand Product Cycles (Module 9)**:
   - Samsung Galaxy S-Series, Z-Series Fold/Flip, and Apple product release calendar.
   - Optimal upgrade window tracking ($18-24$ months device age).
   - Dynamic pricing adjustments and trade-in elasticity simulator.

8. **Marketing Intelligence & Campaign Automation (Module 7)**:
   - Omnichannel campaign generator (WhatsApp, Email, In-App Push, SMS, VIP Concierge).
   - Automated trigger rules (e.g. `Trigger when deviceAge >= 18m & recency <= 45d`).
   - Projected conversion lift and ROI estimates.

9. **What-If Machine Learning Simulator**:
   - Real-time parameter sliders (Income, Spending Score, Recency, Frequency, Support Tickets, Brand).
   - Instant re-projection across clustering, churn probability, RFM segment, and pricing incentives.

10. **AI Strategic Intelligence Advisor (Module 10)**:
    - Powered by **Gemini 4 Argon** with **High Thinking Mode** (`thinkingLevel: ThinkingLevel.HIGH`).
    - Synthesizes cluster statistics, RFM quintiles, churn probabilities, and seasonal brand cycles into executive roadmaps.

11. **Reports & Data Export (Module 8)**:
    - Export segmented dataset as CSV.
    - Export mathematical cluster statistics as JSON.
    - Printable executive PDF dossier.
    - Copy executive summary to clipboard.

---

## 🛠️ Installation & Local Setup

### Prerequisites
- Node.js 20+ installed
- npm or pnpm

### 1. Clone & Install Dependencies
```bash
git clone https://github.com/your-username/segmentiq.git
cd segmentiq
npm install
```

### 2. Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Ensure your `GEMINI_API_KEY` is configured:
```env
GEMINI_API_KEY="your-gemini-api-key"
PORT=3000
```

### 3. Run Unit Tests (Logic First)
```bash
npx --yes tsx --test src/utils/engine.test.ts
```

### 4. Start Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### 5. Build for Production
```bash
npm run build
npm start
```
